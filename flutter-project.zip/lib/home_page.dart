// home_page.dart
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ─── PALET WARNA BIRU GELAP NEON ──────────────────────────────────────────
const String _font = "Rajdhani";
const Color _bg = Color(0xFF0A0E1A);
const Color _card = Color(0xFF111827);
const Color _cardAlt = Color(0xFF1A2332);
const Color _border = Color(0xFF1F2A40);
const Color _borderLight = Color(0xFF2D3B5A);
const Color _accent = Color(0xFF00E5FF);
const Color _accentGlow = Color(0xFF60A5FA);
const Color _accentDeep = Color(0xFF006064);
const Color _greenLive = Color(0xFF00E676);
const Color _yellowSoft = Color(0xFFEAB308);
const Color _textP = Color(0xFFFFFFFF);
const Color _textS = Color(0xFF94A3B8);
const Color _textM = Color(0xFF64748B);

class HomePage extends StatefulWidget {
  final bool isGroup;
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;

  const HomePage({
    super.key,
    required this.isGroup,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  // ── Controllers ──────────────────────────────────────────────────────────
  final targetController = TextEditingController();
  final linkController = TextEditingController();
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;

  // ── Animations ───────────────────────────────────────────────────────────
  late AnimationController _staggerCtrl;
  late Animation<double> _fade1, _fade2, _fade3, _fade4, _fade5, _fade6, _fade7;
  late Animation<Offset> _slide1, _slide2, _slide3, _slide4, _slide5, _slide6, _slide7;

  late AnimationController _pulseCtrl;
  late AnimationController _liveDotCtrl;

  // ── State ────────────────────────────────────────────────────────────────
  String selectedBugId = "";
  String _senderType = "private";
  bool _isSending = false;
  bool _isNomorMode = true;

  // Progress
  int _currentStep = 0;
  double _progress = 0.0;
  final List<String> _progressSteps = [
    "Loading modules...",
    "Connecting to cloud...",
    "Checking authorization...",
    "Preparing resources...",
    "Processing request...",
    "Ready."
  ];
  late AnimationController _progressCtrl;
  late Animation<double> _progressAnim;

  // ── Init ──────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _isNomorMode = !widget.isGroup;

    _videoController = VideoPlayerController.asset("assets/videos/landing.mp4")
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _videoInitialized = true);
          _videoController.setLooping(true);
          _videoController.setVolume(1.0);
          _videoController.play();
        }
      }).catchError((_) {});

    _staggerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    _staggerCtrl.forward();

    final interval = (double s, double e) =>
        CurvedAnimation(parent: _staggerCtrl, curve: Interval(s, e, curve: Curves.easeOut));
    final slide = (double s, double e) => Tween<Offset>(
      begin: const Offset(0, 0.2),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _staggerCtrl, curve: Interval(s, e, curve: Curves.easeOutCubic)));

    _fade1 = interval(0.00, 0.30); _slide1 = slide(0.00, 0.30);
    _fade2 = interval(0.08, 0.38); _slide2 = slide(0.08, 0.38);
    _fade3 = interval(0.16, 0.46); _slide3 = slide(0.16, 0.46);
    _fade4 = interval(0.24, 0.54); _slide4 = slide(0.24, 0.54);
    _fade5 = interval(0.32, 0.62); _slide5 = slide(0.32, 0.62);
    _fade6 = interval(0.40, 0.70); _slide6 = slide(0.40, 0.70);
    _fade7 = interval(0.50, 0.85); _slide7 = slide(0.50, 0.85);

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _liveDotCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))
      ..repeat(reverse: true);

    _progressCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _progressAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _progressCtrl, curve: Curves.easeInOut),
    );

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  @override
  void dispose() {
    _videoController.dispose();
    _staggerCtrl.dispose();
    _pulseCtrl.dispose();
    _liveDotCtrl.dispose();
    _progressCtrl.dispose();
    targetController.dispose();
    linkController.dispose();
    super.dispose();
  }

  // ── Progress updater ──────────────────────────────────────────────────────
  Future<void> _updateProgress(int step) async {
    setState(() {
      _currentStep = step;
      _progress = (step + 1) / _progressSteps.length;
    });
    _progressCtrl.reset();
    _progressCtrl.forward();
    await Future.delayed(const Duration(milliseconds: 500));
  }

  // ── Send Bug (Nomor) ─────────────────────────────────────────────────────
  Future<void> _sendBugNomor() async {
    final target = targetController.text.trim();
    if (target.isEmpty) {
      _showPopup("Error", "Nomor target tidak boleh kosong!", isError: true);
      return;
    }

    setState(() {
      _isSending = true;
      _currentStep = 0;
      _progress = 0.0;
    });

    try {
      await _updateProgress(0);
      await _updateProgress(1);
      await _updateProgress(2);
      await _updateProgress(3);

      final url = "http://publikserverpanzzid.sano.biz.id:11014/sendBug?key=${widget.sessionKey}&target=$target&bug=$selectedBugId&senderType=$_senderType";

      await _updateProgress(4);
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      bool isSuccess = false;
      String msg = "";

      if (data["cooldown"] == true) {
        msg = "Cooldown: Tunggu ${data['wait']} detik.";
      } else if (data["valid"] == false) {
        msg = "Sesi Invalid.";
      } else if (data["sended"] == false) {
        msg = "Gagal: Server Maintenance.";
      } else {
        isSuccess = true;
        msg = "Bug berhasil dikirim!";
        await _updateProgress(5);
      }

      await Future.delayed(const Duration(milliseconds: 500));

      if (isSuccess) {
        _showPopup("Success", msg, isError: false);
        targetController.clear();
      } else {
        _showPopup("Failed", msg, isError: true);
      }
    } catch (e) {
      _showPopup("Connection Error", "Gagal menghubungi server.", isError: true);
    } finally {
      setState(() {
        _isSending = false;
        _currentStep = 0;
        _progress = 0.0;
      });
    }
  }

  // ── Send Bug (Group) ─────────────────────────────────────────────────────
  Future<void> _sendBugGroup() async {
    final link = linkController.text.trim();
    if (link.isEmpty) {
      _showPopup("Error", "Link group tidak boleh kosong!", isError: true);
      return;
    }
    if (!link.contains("chat.whatsapp.com")) {
      _showPopup("Invalid Link", "Link Group tidak valid!", isError: true);
      return;
    }

    setState(() {
      _isSending = true;
      _currentStep = 0;
      _progress = 0.0;
    });

    try {
      await _updateProgress(0);
      await _updateProgress(1);
      await _updateProgress(2);
      await _updateProgress(3);

      final encodedLink = Uri.encodeComponent(link);
      final url = "http://publikserverpanzzid.sano.biz.id:11014/raidGroup?key=${widget.sessionKey}&link=$encodedLink&bug=$selectedBugId&senderType=$_senderType";

      await _updateProgress(4);
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      bool isSuccess = false;
      String msg = "";

      if (data["valid"] == false) {
        msg = "Session Invalid.";
      } else if (data["cooldown"] == true) {
        msg = "Cooldown: Tunggu ${data['wait']} detik.";
      } else if (data["sended"] == true) {
        isSuccess = true;
        msg = "Bug berhasil dikirim ke Group!";
        await _updateProgress(5);
      } else {
        msg = data["message"] ?? "Gagal mengirim bug.";
      }

      await Future.delayed(const Duration(milliseconds: 500));

      if (isSuccess) {
        _showPopup("Success", msg, isError: false);
        linkController.clear();
      } else {
        _showPopup("Failed", msg, isError: true);
      }
    } catch (e) {
      _showPopup("Connection Error", "Gagal menghubungi server.", isError: true);
    } finally {
      setState(() {
        _isSending = false;
        _currentStep = 0;
        _progress = 0.0;
      });
    }
  }

  // ── Popup ─────────────────────────────────────────────────────────────────
  void _showPopup(String title, String message, {bool isError = false}) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: _card.withOpacity(0.95),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: isError ? Colors.redAccent : _accent, width: 1.5),
          ),
          title: Row(
            children: [
              Icon(
                isError ? Icons.error_outline : Icons.check_circle_outline,
                color: isError ? Colors.redAccent : _greenLive,
              ),
              const SizedBox(width: 10),
              Text(title, style: const TextStyle(color: _textP, fontWeight: FontWeight.bold)),
            ],
          ),
          content: Text(message, style: const TextStyle(color: _textS)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK", style: TextStyle(color: _accent)),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BUILD ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          Positioned(top: -120, left: -120, child: _glow(280, _accent, 0.08)),
          Positioned(bottom: -100, right: -100, child: _glow(260, _accentGlow, 0.06)),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FadeTransition(opacity: _fade1, child: SlideTransition(position: _slide1, child: _buildTopBar())),
                  const SizedBox(height: 12),
                  FadeTransition(opacity: _fade2, child: SlideTransition(position: _slide2, child: _buildProfileCard())),
                  const SizedBox(height: 16),
                  FadeTransition(opacity: _fade3, child: SlideTransition(position: _slide3, child: _buildVideoBanner())),
                  const SizedBox(height: 16),
                  FadeTransition(opacity: _fade4, child: SlideTransition(position: _slide4, child: _buildModeButtons())),
                  const SizedBox(height: 16),
                  FadeTransition(opacity: _fade5, child: SlideTransition(position: _slide5, child: _buildInputArea())),
                  const SizedBox(height: 18),
                  FadeTransition(opacity: _fade6, child: SlideTransition(position: _slide6, child: _buildPayloadSelector())),
                  const SizedBox(height: 18),
                  FadeTransition(opacity: _fade7, child: SlideTransition(position: _slide7, child: _buildSenderTypeCard())),
                  if (_isSending) ...[
                    const SizedBox(height: 16),
                    FadeTransition(opacity: _fade7, child: SlideTransition(position: _slide7, child: _buildProgressIndicator())),
                  ],
                  const SizedBox(height: 24),
                  FadeTransition(opacity: _fade7, child: SlideTransition(position: _slide7, child: _buildSendButton())),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Glow helper ──────────────────────────────────────────────────────────
  Widget _glow(double size, Color color, double opacity) => IgnorePointer(
    child: Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(colors: [color.withOpacity(opacity), Colors.transparent]),
      ),
    ),
  );

  // ── Top Bar ──────────────────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: _card,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: _accent.withOpacity(0.45), width: 1.2),
                boxShadow: [BoxShadow(color: _accent.withOpacity(0.22), blurRadius: 12)],
              ),
              child: const Icon(Icons.shield_rounded, color: _accent, size: 20),
            ),
            const SizedBox(width: 11),
            const Text(
              "PNZX BUG",
              style: TextStyle(
                fontFamily: _font,
                color: _textP,
                fontWeight: FontWeight.w900,
                fontSize: 17,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_accent, _accentDeep],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(9),
            boxShadow: [BoxShadow(color: _accent.withOpacity(0.55), blurRadius: 12, offset: const Offset(0, 3))],
          ),
          child: const Text(
            "V1.0",
            style: TextStyle(
              fontFamily: _font,
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: 12,
              letterSpacing: 1.3,
            ),
          ),
        ),
      ],
    );
  }

  // ── Profile Card ─────────────────────────────────────────────────────────
  Widget _buildProfileCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 22, offset: const Offset(0, 12)),
          BoxShadow(color: _accent.withOpacity(0.08), blurRadius: 20, offset: const Offset(0, 6)),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(2.5),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _accent, width: 2),
              boxShadow: [BoxShadow(color: _accent.withOpacity(0.55), blurRadius: 14)],
            ),
            child: const CircleAvatar(radius: 26, backgroundImage: AssetImage('assets/images/icon.jpg'), backgroundColor: Colors.black),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: _font,
                    color: _textP,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.role.toUpperCase(),
                  style: TextStyle(
                    fontFamily: _font,
                    color: _accentGlow,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.10),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: _accent.withOpacity(0.40)),
              boxShadow: [BoxShadow(color: _accent.withOpacity(0.18), blurRadius: 8)],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.access_time_rounded, color: _accent, size: 13),
                const SizedBox(width: 5),
                Text(
                  widget.expiredDate,
                  style: const TextStyle(
                    fontFamily: _font,
                    color: _accent,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Video Banner (lebih lebar, height 200) ─────────────────────────────
  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 200, // <-- diperbesar dari 165 agar lebih lebar/tidak terlalu panjang
      decoration: BoxDecoration(
        color: _cardAlt,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 20, offset: const Offset(0, 10)),
          BoxShadow(color: _accent.withOpacity(0.10), blurRadius: 18, offset: const Offset(0, 4)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              )
            else
              Container(
                color: _cardAlt,
                child: const Center(
                  child: SizedBox(
                    width: 28, height: 28,
                    child: CircularProgressIndicator(color: _accent, strokeWidth: 2),
                  ),
                ),
              ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, Colors.black.withOpacity(0.45)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Mode Buttons ──────────────────────────────────────────────────────────
  Widget _buildModeButtons() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () => setState(() => _isNomorMode = true),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              height: 50,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                gradient: _isNomorMode
                    ? const LinearGradient(colors: [_accent, _accentDeep])
                    : null,
                color: _isNomorMode ? null : _cardAlt,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _isNomorMode ? _accent : _border,
                  width: 1.5,
                ),
                boxShadow: _isNomorMode
                    ? [BoxShadow(color: _accent.withOpacity(0.4), blurRadius: 12, spreadRadius: 1)]
                    : null,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.phone_android, color: _isNomorMode ? Colors.white : _textM, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    "BUG NOMOR",
                    style: TextStyle(
                      color: _isNomorMode ? Colors.white : _textM,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: GestureDetector(
            onTap: () => setState(() => _isNomorMode = false),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              height: 50,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                gradient: !_isNomorMode
                    ? const LinearGradient(colors: [_accent, _accentDeep])
                    : null,
                color: !_isNomorMode ? null : _cardAlt,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: !_isNomorMode ? _accent : _border,
                  width: 1.5,
                ),
                boxShadow: !_isNomorMode
                    ? [BoxShadow(color: _accent.withOpacity(0.4), blurRadius: 12, spreadRadius: 1)]
                    : null,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.group_add, color: !_isNomorMode ? Colors.white : _textM, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    "BUG GROUP",
                    style: TextStyle(
                      color: !_isNomorMode ? Colors.white : _textM,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Input Area ──────────────────────────────────────────────────────────
  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 20, offset: const Offset(0, 10)),
          BoxShadow(color: _accent.withOpacity(0.08), blurRadius: 16, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: _accent.withOpacity(0.40)),
                ),
                child: Icon(
                  _isNomorMode ? Icons.phone_rounded : Icons.link_rounded,
                  color: _accent,
                  size: 16,
                ),
              ),
              const SizedBox(width: 11),
              Text(
                _isNomorMode ? "Masukan Nomor" : "Masukan Link Group",
                style: const TextStyle(
                  fontFamily: _font,
                  color: _textP,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.0,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(
              color: _cardAlt,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: _accent.withOpacity(0.30), width: 1.2),
              boxShadow: [BoxShadow(color: _accent.withOpacity(0.10), blurRadius: 10)],
            ),
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
            child: TextField(
              controller: _isNomorMode ? targetController : linkController,
              style: const TextStyle(
                fontFamily: _font,
                color: _textP,
                fontSize: 15,
                letterSpacing: 0.4,
              ),
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                hintText: _isNomorMode ? "+62xxxxxx / 1xxxx ..." : "https://chat.whatsapp.com/...",
                hintStyle: TextStyle(
                  fontFamily: _font,
                  color: _textM.withOpacity(0.5),
                  fontSize: 13,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 14),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear, color: _textM, size: 20),
                  onPressed: () => _isNomorMode ? targetController.clear() : linkController.clear(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Payload Selector ─────────────────────────────────────────────────────
  Widget _buildPayloadSelector() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 20, offset: const Offset(0, 10)),
          BoxShadow(color: _accent.withOpacity(0.08), blurRadius: 16, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _greenLive.withOpacity(0.14),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: _greenLive.withOpacity(0.40)),
                ),
                child: const Icon(Icons.bug_report_rounded, color: _greenLive, size: 16),
              ),
              const SizedBox(width: 11),
              const Text(
                "Pilih Payload",
                style: TextStyle(
                  fontFamily: _font,
                  color: _textP,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.2,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _accent.withOpacity(0.14),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: _accent.withOpacity(0.40)),
                ),
                child: Text(
                  "${widget.listBug.length} Payload",
                  style: const TextStyle(
                    fontFamily: _font,
                    color: _accent,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 170,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
              itemCount: widget.listBug.length,
              itemBuilder: (context, index) {
                final bug = widget.listBug[index];
                final isSelected = selectedBugId == bug['bug_id'];
                final bugId = bug['bug_id']?.toString() ?? '';
                final bugName = bug['bug_name']?.toString() ?? '';

                return GestureDetector(
                  onTap: () => setState(() => selectedBugId = bug['bug_id']),
                  child: AnimatedScale(
                    scale: isSelected ? 1.05 : 1.0,
                    duration: const Duration(milliseconds: 280),
                    curve: Curves.easeOutCubic,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 280),
                      width: 180,
                      margin: const EdgeInsets.only(right: 14),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: isSelected
                            ? const LinearGradient(colors: [_accent, _accentDeep])
                            : null,
                        color: isSelected ? null : _cardAlt,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: isSelected ? _accentGlow : _border,
                          width: 1.4,
                        ),
                        boxShadow: isSelected
                            ? [BoxShadow(color: _accent.withOpacity(0.45), blurRadius: 18, spreadRadius: 1, offset: const Offset(0, 6))]
                            : [BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 8, offset: const Offset(0, 4))],
                      ),
                      child: Stack(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: 38, height: 38,
                                decoration: BoxDecoration(
                                  color: isSelected ? Colors.white.withOpacity(0.22) : _accent.withOpacity(0.12),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: isSelected ? Colors.white.withOpacity(0.55) : _accent.withOpacity(0.45), width: 1.2),
                                ),
                                child: Center(
                                  child: Icon(
                                    Icons.shield_rounded,
                                    color: isSelected ? Colors.white : _accent,
                                    size: 18,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                bugName.isEmpty ? bugId : bugName,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontFamily: _font,
                                  color: isSelected ? Colors.white : _textP.withOpacity(0.95),
                                  fontWeight: FontWeight.w900,
                                  fontSize: 14,
                                  letterSpacing: 0.3,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: isSelected ? Colors.white.withOpacity(0.18) : _accent.withOpacity(0.10),
                                  borderRadius: BorderRadius.circular(7),
                                  border: Border.all(color: isSelected ? Colors.white.withOpacity(0.40) : _accent.withOpacity(0.35)),
                                ),
                                child: Text(
                                  bugId,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: _font,
                                    color: isSelected ? Colors.white : _accentGlow,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Positioned(
                            top: 0, right: 0,
                            child: AnimatedBuilder(
                              animation: _liveDotCtrl,
                              builder: (ctx, _) {
                                final t = _liveDotCtrl.value;
                                return Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Container(
                                      width: 16 + (6 * t),
                                      height: 16 + (6 * t),
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: _greenLive.withOpacity(0.25 * (1 - t)),
                                      ),
                                    ),
                                    Container(
                                      width: 9, height: 9,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: _greenLive,
                                        boxShadow: [BoxShadow(color: _greenLive.withOpacity(0.75), blurRadius: 8)],
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          if (widget.listBug.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(widget.listBug.length, (index) {
                  final isSelected = selectedBugId == widget.listBug[index]['bug_id'];
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: isSelected ? 18 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: isSelected ? _accent : _textM.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  );
                }),
              ),
            ),
        ],
      ),
    );
  }

  // ── Sender Type Card (diperbesar) ──────────────────────────────────────
  Widget _buildSenderTypeCard() {
    final bool globalDisabled = widget.role != 'owner' && widget.role != 'vip' && widget.role != 'admin';
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 20, offset: const Offset(0, 10)),
          BoxShadow(color: _accent.withOpacity(0.08), blurRadius: 16, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: _accent.withOpacity(0.40)),
                ),
                child: const Icon(Icons.link_rounded, color: _accent, size: 16),
              ),
              const SizedBox(width: 11),
              const Text(
                "Pilih Sender",
                style: TextStyle(
                  fontFamily: _font,
                  color: _textP,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: _senderTypeButton(
                  label: "Private",
                  value: "private",
                  icon: Icons.lock_rounded,
                  active: _senderType == "private",
                  disabled: false,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: _senderTypeButton(
                  label: "Global",
                  value: "public",
                  icon: Icons.public_rounded,
                  active: _senderType == "public",
                  disabled: globalDisabled,
                  disabledText: "Owner/VIP Only",
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: _cardAlt,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _border),
            ),
            child: Row(
              children: [
                Container(width: 8, height: 8, decoration: BoxDecoration(color: _greenLive, shape: BoxShape.circle)),
                const SizedBox(width: 10),
                Text(
                  _senderType == "public" ? "Public sender aktif (Owner/VIP)" : "Private sender aktif",
                  style: const TextStyle(
                    color: _textS,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Sender Type Button (diperbesar) ────────────────────────────────────
  Widget _senderTypeButton({
    required String label,
    required String value,
    required IconData icon,
    required bool active,
    required bool disabled,
    String disabledText = "",
  }) {
    return GestureDetector(
      onTap: disabled ? null : () => setState(() => _senderType = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 14), // diperbesar
        decoration: BoxDecoration(
          gradient: active && !disabled
              ? const LinearGradient(colors: [_accent, _accentDeep])
              : null,
          color: active && !disabled ? null : _cardAlt,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: active && !disabled ? _accentGlow : (disabled ? Colors.redAccent.withOpacity(0.3) : _border),
            width: 2,
          ),
          boxShadow: active && !disabled
              ? [BoxShadow(color: _accent.withOpacity(0.5), blurRadius: 20, spreadRadius: 2, offset: const Offset(0, 8))]
              : [BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 10, offset: const Offset(0, 6))],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: disabled ? Colors.redAccent.withOpacity(0.7) : (active ? Colors.white : _accentGlow),
              size: 30, // diperbesar
            ),
            const SizedBox(height: 12),
            Text(
              label,
              style: TextStyle(
                fontFamily: _font,
                color: disabled ? Colors.white38 : (active ? Colors.white : _textS),
                fontSize: 16, // diperbesar
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
            ),
            if (disabled && disabledText.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                disabledText,
                style: const TextStyle(
                  fontFamily: _font,
                  color: Colors.redAccent,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ── Progress Indicator ──────────────────────────────────────────────────
  Widget _buildProgressIndicator() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border),
        boxShadow: [BoxShadow(color: _accent.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(_progressSteps.length, (index) {
              bool isActive = index <= _currentStep;
              bool isCurrent = index == _currentStep;
              return Expanded(
                child: Column(
                  children: [
                    Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isActive ? const LinearGradient(colors: [_accent, _accentDeep]) : null,
                        color: isActive ? null : _cardAlt,
                        border: Border.all(
                          color: isCurrent ? _accentGlow : _border,
                          width: isCurrent ? 2 : 1,
                        ),
                        boxShadow: isCurrent
                            ? [BoxShadow(color: _accent.withOpacity(0.5), blurRadius: 10, spreadRadius: 2)]
                            : null,
                      ),
                      child: Center(
                        child: isActive && index < _currentStep
                            ? const Icon(Icons.check, color: Colors.white, size: 16)
                            : Text(
                                '${index + 1}',
                                style: TextStyle(
                                  color: isActive ? Colors.white : _textM,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                      ),
                    ),
                    if (index < _progressSteps.length - 1)
                      Container(
                        margin: const EdgeInsets.only(top: 5),
                        height: 2,
                        color: isActive ? _accent : _border,
                      ),
                  ],
                ),
              );
            }),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Tahap ${_currentStep + 1} dari ${_progressSteps.length}",
                style: TextStyle(
                  color: _accentGlow,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                "${(_progress * 100).toInt()}%",
                style: const TextStyle(
                  color: _textP,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
            decoration: BoxDecoration(
              color: _cardAlt,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              _progressSteps[_currentStep],
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: _textS,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(height: 12),
          AnimatedBuilder(
            animation: _progressAnim,
            builder: (context, child) {
              return ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(
                  value: _progress * _progressAnim.value,
                  minHeight: 10,
                  backgroundColor: _cardAlt,
                  valueColor: AlwaysStoppedAnimation<Color>(_accent),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // ── Send Button ──────────────────────────────────────────────────────────
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (context, child) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: _accent.withOpacity(0.3 * _pulseCtrl.value),
                blurRadius: 20 * _pulseCtrl.value,
                spreadRadius: 2 * _pulseCtrl.value,
              ),
            ],
          ),
          child: child,
        );
      },
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: ElevatedButton(
          onPressed: _isSending ? null : (_isNomorMode ? _sendBugNomor : _sendBugGroup),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            padding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            elevation: 0,
          ),
          child: Ink(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_accent, _accentDeep],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Container(
              alignment: Alignment.center,
              child: _isSending
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
                        SizedBox(width: 15),
                        Text("SENDING...", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
                      ],
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.send_rounded, color: Colors.white),
                        const SizedBox(width: 10),
                        Text(
                          _isNomorMode ? "SEND BUG" : "SEND GROUP BUG",
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}