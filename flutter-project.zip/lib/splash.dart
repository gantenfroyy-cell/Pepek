// splash_screen.dart
import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _mainController;
  late AnimationController _familiController;
  late AnimationController _subTextController;
  late AnimationController _fadeController;
  bool _fadeOutStarted = false;
  bool _isNavigating = false;
  bool _showSubText = false;

  // ─── PALET WARNA ──────────────────────────────────────────────────────
  static const Color bgDark = Color(0xFF0A0E1A);    // hitam kebiruan
  static const Color textWhite = Color(0xFFFFFFFF);
  static const Color textNeon = Color(0xFF00E5FF);  // neon biru
  static const Color textSec = Color(0xFF94A3B8);   // abu-abu terang

  @override
  void initState() {
    super.initState();

    _mainController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();

    _familiController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    Timer(const Duration(milliseconds: 500), () {
      if (mounted) _familiController.forward();
    });

    _subTextController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _videoController = VideoPlayerController.asset('assets/videos/load.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController.setLooping(false);
        _videoController.play();

        _videoController.addListener(() {
          if (!mounted) return;
          final position = _videoController.value.position;
          final duration = _videoController.value.duration;

          if (position >= duration - const Duration(seconds: 1) &&
              !_fadeOutStarted) {
            _fadeOutStarted = true;
            _fadeController.forward();
          }

          if (position >= duration && !_isNavigating) {
            _navigateToDashboard();
          }
        });

        Timer(const Duration(seconds: 4), () {
          if (!mounted) return;
          setState(() => _showSubText = true);
          _subTextController.forward(from: 0.0);
        });
      }).catchError((_) {
        Timer(const Duration(seconds: 3), () {
          if (mounted && !_isNavigating) _navigateToDashboard();
        });
      });
  }

  void _navigateToDashboard() {
    if (_isNavigating) return;
    _isNavigating = true;
    _videoController.pause();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  void _skipAnimation() {
    if (_isNavigating) return;
    _navigateToDashboard();
  }

  @override
  void dispose() {
    _videoController.dispose();
    _mainController.dispose();
    _familiController.dispose();
    _subTextController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark, // background gelap
      body: Stack(
        alignment: Alignment.center,
        children: [
          // ── Video Background ──────────────────────────────────────────
          if (_videoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            const Center(
              child: CircularProgressIndicator(
                color: Color(0xFF00E5FF),
                strokeWidth: 2,
              ),
            ),

          // ── Overlay Gelap Tipis (agar teks terbaca) ─────────────────
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    bgDark.withOpacity(0.5),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  stops: const [0.6, 1.0],
                ),
              ),
            ),
          ),

          // ── Teks utama "PNZX BUG ENGINE" ────────────────────────────
          Positioned(
            bottom: 80,
            child: Column(
              children: [
                FadeTransition(
                  opacity: _mainController.drive(Tween(begin: 0.0, end: 1.0)),
                  child: const Text(
                    'PNZX BUG ENGINE',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 35,
                      fontWeight: FontWeight.w900,
                      color: textWhite,
                      letterSpacing: 4,
                      fontFamily: 'Orbitron',
                      fontFamilyFallback: ['sans-serif'],
                      shadows: [
                        Shadow(
                          color: Colors.black45,
                          blurRadius: 20,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                // ── Teks "PNZX FAMILY¹" ──────────────────────────────
                FadeTransition(
                  opacity: _familiController.drive(Tween(begin: 0.0, end: 1.0)),
                  child: Text(
                    'PNZX FAMILY¹',
                    style: TextStyle(
                      color: textNeon, // biru neon
                      fontSize: 12,
                      letterSpacing: 2,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ── Teks kedua di tengah ─────────────────────────────────────
          if (_showSubText)
            Positioned(
              top: MediaQuery.of(context).size.height * 0.4,
              child: FadeTransition(
                opacity: _subTextController.drive(Tween(begin: 0.0, end: 1.0)),
                child: const Text(
                  'DIRANCANG HANYA UNTUK BERSENANG SENANG',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: textWhite,
                    letterSpacing: 2,
                    fontFamilyFallback: ['sans-serif'],
                    shadows: [
                      Shadow(
                        color: Colors.black45,
                        blurRadius: 10,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // ── Tombol Skip ──────────────────────────────────────────────
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            right: 16,
            child: GestureDetector(
              onTap: _skipAnimation,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: Colors.white30),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Text(
                  'Skip',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ),

          // ── Fade Out Akhir (gelap, bukan putih) ─────────────────────
          if (_fadeOutStarted)
            FadeTransition(
              opacity: _fadeController.drive(Tween(begin: 1.0, end: 0.0)),
              child: Container(color: bgDark),
            ),
        ],
      ),
    );
  }
}