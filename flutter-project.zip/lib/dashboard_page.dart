import 'dart:convert';
import 'dart:async';
import 'dart:math' as dart_math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;

// Import halaman-halaman
import 'anime_home.dart';
import 'dracin_page.dart';
import 'change_password.dart';
import 'bug_sender.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'control_panel.dart';
import 'device_permission.dart';
import 'device_dashboard.dart';
import 'musik_page.dart';

// ─── PALET WARNA BIRU GELAP NEON ──────────────────────────────────────────
class AppColors {
  static const bg          = Color(0xFF0A0E1A);
  static const surface     = Color(0xFF111827);
  static const surface2    = Color(0xFF1A2332);
  static const border      = Color(0xFF1F2A40);
  static const borderLight = Color(0xFF2D3B5A);
  static const neon        = Color(0xFF00E5FF);
  static const neonBlue    = Color(0xFF2979FF);
  static const neonGreen   = Color(0xFF00E676);
  static const neonPink    = Color(0xFFE91E8C);
  static const neonOrange  = Color(0xFFFF6D00);
  static const textPrimary = Color(0xFFFFFFFF);
  static const textSec     = Color(0xFF94A3B8);
  static const textMuted   = Color(0xFF64748B);
  static const white       = Color(0xFFFFFFFF);
  static const highlight   = Color(0xFF00E5FF);
  static const fabBg       = Color(0xFF1A2332);
  static const red         = Color(0xFFEF4444);
  static const green       = Color(0xFF00E676);
  static const orange      = Color(0xFFFF6D00);
  static const purple      = Color(0xFF7C4DFF);
}

// ── FONT FAMILY ──────────────────────────────────────────────────────────
const String _fontFamily = 'Rajdhani';

// ── SPARKLE BACKGROUND ─────────────────────────────────────────────────────
class _SparkleBackground extends StatefulWidget {
  final Widget child;
  const _SparkleBackground({required this.child});
  @override State<_SparkleBackground> createState() => _SparkleBackgroundState();
}
class _SparkleBackgroundState extends State<_SparkleBackground> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  final _rng = dart_math.Random();
  final List<List<double>> _dots = [];
  @override
  void initState() {
    super.initState();
    for (int i = 0; i < 80; i++) {
      _dots.add([_rng.nextDouble(), _rng.nextDouble(), _rng.nextDouble() * 2.5 + 0.5, _rng.nextDouble() * 2 * dart_math.pi, _rng.nextDouble() * 0.8 + 0.2]);
    }
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 5))..repeat();
  }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => AnimatedBuilder(
    animation: _ctrl,
    builder: (_, child) => CustomPaint(painter: _SparklePainter(_dots, _ctrl.value), child: child),
    child: widget.child,
  );
}
class _SparklePainter extends CustomPainter {
  final List<List<double>> dots; final double t;
  _SparklePainter(this.dots, this.t);
  @override void paint(Canvas canvas, Size size) {
    final paint = Paint();
    for (final d in dots) {
      final alpha = (dart_math.sin(t * 2 * dart_math.pi * d[4] + d[3]) * 0.5 + 0.5);
      paint.color = AppColors.neon.withOpacity(alpha * 0.3);
      canvas.drawCircle(Offset(d[0] * size.width, d[1] * size.height), d[2], paint);
    }
  }
  @override bool shouldRepaint(_SparklePainter _) => true;
}

// ── HEXAGON PATTERN ────────────────────────────────────────────────────────
class _HexagonPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.neon.withOpacity(0.06)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    const double w = 72.0, h = 52.0;
    for (double row = -1; row * h < size.height + h * 2; row++) {
      for (double col = -1; col * w < size.width + w * 2; col++) {
        final double offsetX = (row.toInt() % 2 == 0) ? 0 : w * 0.5;
        final cx = col * w + offsetX;
        final cy = row * h;
        _drawDiamond(canvas, paint, Offset(cx, cy), w * 0.5, h * 0.5);
      }
    }
  }
  void _drawDiamond(Canvas canvas, Paint paint, Offset center, double hw, double hh) {
    final path = Path()
      ..moveTo(center.dx, center.dy - hh)
      ..lineTo(center.dx + hw, center.dy)
      ..lineTo(center.dx, center.dy + hh)
      ..lineTo(center.dx - hw, center.dy)
      ..close();
    canvas.drawPath(path, paint);
  }
  @override bool shouldRepaint(covariant CustomPainter _) => false;
}

// ── ANIMATED DOT ──────────────────────────────────────────────────────────
class _AnimatedDot extends StatefulWidget {
  final Color color; final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override State<_AnimatedDot> createState() => _AnimatedDotState();
}
class _AnimatedDotState extends State<_AnimatedDot> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl; late Animation<double> _anim;
  @override void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => FadeTransition(
    opacity: _anim,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: widget.color,
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
      ),
    ),
  );
}

// ── QUICK ACTION DATA ─────────────────────────────────────────────────────
class _QuickActionData {
  final IconData icon; final String title; final String subtitle; final List<Color> gradient; final VoidCallback onTap;
  const _QuickActionData({required this.icon, required this.title, required this.subtitle, required this.gradient, required this.onTap});
}

// ─── DASHBOARD PAGE ────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username; final String password; final String role; final String expiredDate; final String sessionKey;
  final List<Map<String, dynamic>> listBug; final List<Map<String, dynamic>> listDoos; final List<dynamic> news;
  const DashboardPage({
    super.key,
    required this.username, required this.password, required this.role, required this.expiredDate,
    required this.listBug, required this.listDoos, required this.sessionKey, required this.news,
  });
  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with TickerProviderStateMixin {
  // ── Controllers ──────────────────────────────────────────────────────────
  late AnimationController _fadeCtrl; late Animation<double> _fadeAnim;
  late AnimationController _fabCtrl; late Animation<double> _fabAnim;
  late WebSocketChannel channel;
  VideoPlayerController? _videoController;
  final AudioPlayer _audioPlayer = AudioPlayer();

  // ── Music State ──────────────────────────────────────────────────────────
  bool _musicPlaying = false; double _musicVolume = 0.7; int _currentTrack = 0;
  Duration _musicPos = Duration.zero; Duration _musicDur = Duration.zero;
  final List<Map<String, String>> _playlist = [
    {'title': 'Lo-Fi Chill', 'artist': 'BGM', 'url': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'},
    {'title': 'Dark Ambience', 'artist': 'BGM', 'url': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'},
    {'title': 'Night Drive', 'artist': 'BGM', 'url': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'},
  ];

  // ── Core State ──────────────────────────────────────────────────────────
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";
  int _bottomNavIndex = 0; bool _fabOpen = false; Widget _selectedPage = const Placeholder();

  // ── Stats & Carousel ────────────────────────────────────────────────────
  Timer? _statsTimer; int onlineUsers = 0; int activeConns = 0;
  late AnimationController _pulseCtrl; late Animation<double> _pulseAnim;
  late PageController _qaPageCtrl; double _currentQaPage = 0.0;

  // ─────────────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey; username = widget.username; password = widget.password;
    role = widget.role; expiredDate = widget.expiredDate;
    listBug = widget.listBug; listDoos = widget.listDoos; newsList = widget.news;

    _fadeCtrl = AnimationController(duration: const Duration(milliseconds: 600), vsync: this);
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _fabCtrl = AnimationController(duration: const Duration(milliseconds: 300), vsync: this);
    _fabAnim = CurvedAnimation(parent: _fabCtrl, curve: Curves.easeInOut);

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() { if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0); });

    _initializeVideo();
    _selectedPage = _buildDashboardHome();
    _initAndroidIdAndConnect();
    _initMusicListeners();
  }

  // ── Video ──────────────────────────────────────────────────────────────
  void _initializeVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _videoController?.setLooping(true);
        _videoController?.play();
        _videoController?.setVolume(1.0);
      }).catchError((_) {
        if (mounted) setState(() {});
      });
  }

  // ── Music ──────────────────────────────────────────────────────────────
  void _initMusicListeners() {
    _audioPlayer.onPlayerStateChanged.listen((s) { if (mounted) setState(() => _musicPlaying = s == PlayerState.playing); });
    _audioPlayer.onPositionChanged.listen((d) { if (mounted) setState(() => _musicPos = d); });
    _audioPlayer.onDurationChanged.listen((d) { if (mounted) setState(() => _musicDur = d); });
    _audioPlayer.onPlayerComplete.listen((_) => _nextTrack());
  }
  Future<void> _playTrack(int index) async {
    _currentTrack = index; await _audioPlayer.stop(); await _audioPlayer.setVolume(_musicVolume);
    await _audioPlayer.play(UrlSource(_playlist[index]['url']!));
    if (mounted) setState(() {});
  }
  void _toggleMusic() { if (_musicPlaying) _audioPlayer.pause(); else { if (_musicPos == Duration.zero) _playTrack(_currentTrack); else _audioPlayer.resume(); } }
  void _nextTrack() => _playTrack((_currentTrack + 1) % _playlist.length);
  void _prevTrack() => _playTrack((_currentTrack - 1 + _playlist.length) % _playlist.length);
  String _fmtDur(Duration d) { final m = d.inMinutes.remainder(60).toString().padLeft(2,'0'); final s = d.inSeconds.remainder(60).toString().padLeft(2,'0'); return '$m:$s'; }

  // ── WebSocket ──────────────────────────────────────────────────────────
  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }
  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://justinosuper.erlian.my.id:10047'));
    channel.sink.add(jsonEncode({"type": "validate", "key": sessionKey, "androidId": androidId}));
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) _handleInvalidSession("Session invalid, please re-login.");
      if (data['type'] == 'stats' && mounted) setState(() { onlineUsers = data['onlineUsers'] ?? 0; activeConns = data['activeConnections'] ?? 0; });
    });
    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) { try { channel.sink.add(jsonEncode({'type': 'stats'})); } catch (_) {} });
  }
  void _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance(); await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context, barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: AppColors.border)),
        title: Row(children: [
          const Icon(Icons.warning_rounded, color: AppColors.neon, size: 24),
          const SizedBox(width: 10),
          Text("Session Expired", style: const TextStyle(color: AppColors.textPrimary, fontFamily: _fontFamily)),
        ]),
        content: Text(message, style: const TextStyle(color: AppColors.textSec, fontFamily: _fontFamily)),
        actions: [TextButton(
          onPressed: () => Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (r) => false),
          child: const Text("OK", style: TextStyle(color: AppColors.neon, fontFamily: _fontFamily)),
        )],
      ),
    );
  }

  // ── FAB ────────────────────────────────────────────────────────────────
  void _toggleFab() { setState(() => _fabOpen = !_fabOpen); if (_fabOpen) _fabCtrl.forward(); else _fabCtrl.reverse(); }

  // ── Navigation ─────────────────────────────────────────────────────────
  void _onNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      switch (index) {
        case 0: _selectedPage = _buildDashboardHome(); break;
        case 1: _selectedPage = HomePage(isGroup: false, username: username, password: password, sessionKey: sessionKey, listBug: listBug, role: role, expiredDate: expiredDate); break;
        case 2: _selectedPage = HomePage(isGroup: true, username: username, password: password, sessionKey: sessionKey, listBug: listBug, role: role, expiredDate: expiredDate); break;
        case 3: _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos); break;
        case 4: _selectedPage = DeviceDashboardPage(username: username, role: role, sessionKey: sessionKey); break;
      }
    });
  }
  void _navigateToAdminPage() => Navigator.push(context, MaterialPageRoute(builder: (_) => AdminPage(sessionKey: sessionKey)));
  void _navigateToSellerPage() => Navigator.push(context, MaterialPageRoute(builder: (_) => SellerPage(keyToken: sessionKey)));

  // ─── DASHBOARD HOME ────────────────────────────────────────────────────
  Widget _buildDashboardHome() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildBannerVideo(),
            const SizedBox(height: 16),
            _buildWelcomeCard(),
            const SizedBox(height: 16),
            _buildQuickActionsCarousel(),
            const SizedBox(height: 16),
            _buildNewsSection(),
            const SizedBox(height: 16),
            const _WeatherCard(),
            const SizedBox(height: 16),
            _buildTelegramCard(),
            const SizedBox(height: 20),
            Center(
              child: Text(
                'GLITH PHANTOM',
                style: TextStyle(
                  color: AppColors.textMuted.withOpacity(0.3),
                  fontSize: 13,
                  letterSpacing: 4,
                  fontWeight: FontWeight.bold,
                  fontFamily: _fontFamily,
                ),
              ),
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  // ── Banner Video ──────────────────────────────────────────────────────
  Widget _buildBannerVideo() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        height: 180, width: double.infinity,
        color: AppColors.surface,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoController != null && _videoController!.value.isInitialized)
              FittedBox(fit: BoxFit.cover, child: SizedBox(width: _videoController!.value.size.width, height: _videoController!.value.size.height, child: VideoPlayer(_videoController!)))
            else
              Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [AppColors.bg, AppColors.surface2], begin: Alignment.topLeft, end: Alignment.bottomRight))),
            Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.black.withOpacity(0.5), Colors.transparent, Colors.black.withOpacity(0.2)], begin: Alignment.centerLeft, end: Alignment.centerRight))),
            const Positioned(
              left: 16, bottom: 14,
              child: Text(
                'GLITH PHANTOM',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                  fontFamily: _fontFamily,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Welcome Card ──────────────────────────────────────────────────────
  Widget _buildWelcomeCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border.withOpacity(0.6)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 24, offset: const Offset(0, 10))],
      ),
      child: Stack(
        children: [
          Positioned.fill(child: ClipRRect(borderRadius: BorderRadius.circular(18), child: CustomPaint(painter: _HexagonPatternPainter()))),
          Column(
            children: [
              Row(
                children: [
                  ScaleTransition(
                    scale: _pulseAnim,
                    child: Container(
                      width: 58, height: 58,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(colors: [AppColors.neon, AppColors.neonBlue]),
                        boxShadow: [BoxShadow(color: AppColors.neon.withOpacity(0.5), blurRadius: 16, spreadRadius: 2)],
                      ),
                      child: const Center(child: Icon(Icons.security_rounded, color: Colors.white, size: 28)),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Welcome Back,',
                          style: TextStyle(
                            color: AppColors.textMuted,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            fontFamily: _fontFamily,
                          ),
                        ),
                        Text(
                          username,
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                            fontFamily: _fontFamily,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: AppColors.neon.withOpacity(0.5)),
                            color: AppColors.neon.withOpacity(0.08),
                          ),
                          child: Text(
                            role.toUpperCase(),
                            style: TextStyle(
                              color: AppColors.neon,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                              fontFamily: _fontFamily,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.neonGreen.withOpacity(0.12),
                      border: Border.all(color: AppColors.neonGreen.withOpacity(0.3)),
                    ),
                    child: const Icon(Icons.timer_outlined, color: AppColors.neonGreen, size: 20),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: AppColors.neon.withOpacity(0.4)),
                  color: AppColors.neon.withOpacity(0.04),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _AnimatedDot(color: AppColors.neon),
                    const SizedBox(width: 10),
                    Text(
                      'GLIHT PHANTOM DASHBOARD',
                      style: TextStyle(
                        color: AppColors.neon,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                        fontFamily: _fontFamily,
                      ),
                    ),
                    const SizedBox(width: 10),
                    _AnimatedDot(color: AppColors.neon),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  _buildCircleStatItem(
                    icon: Icons.people_alt_rounded,
                    value: '$onlineUsers',
                    label: 'Online Users',
                    color: AppColors.neonGreen,
                  ),
                  _buildStatDivider(),
                  _buildCircleStatItem(
                    icon: Icons.link_rounded,
                    value: '$activeConns',
                    label: 'Active Connections',
                    color: AppColors.neon,
                  ),
                  _buildStatDivider(),
                  _buildCircleStatItem(
                    icon: Icons.calendar_month_rounded,
                    value: expiredDate.length > 10 ? expiredDate.substring(0, 10) : expiredDate,
                    label: 'Expiration',
                    color: AppColors.neonOrange,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerLeft,
                child: ScaleTransition(
                  scale: _pulseAnim,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.neonGreen.withOpacity(0.5)),
                      color: AppColors.neonGreen.withOpacity(0.08),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _AnimatedDot(color: AppColors.neonGreen),
                        const SizedBox(width: 6),
                        Text(
                          'LIVE',
                          style: TextStyle(
                            color: AppColors.neonGreen,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                            fontFamily: _fontFamily,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCircleStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 62, height: 62,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.18),
              border: Border.all(color: color.withOpacity(0.6), width: 2),
              boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 14, spreadRadius: 2)],
            ),
            child: Center(child: Icon(icon, color: color, size: 28)),
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.bold,
              fontSize: 13,
              letterSpacing: 0.5,
              fontFamily: _fontFamily,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: AppColors.textMuted,
              fontSize: 9,
              fontFamily: _fontFamily,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildStatDivider() => Container(width: 1, height: 60, color: AppColors.border.withOpacity(0.5));

  // ── Quick Actions Carousel ────────────────────────────────────────────
  Widget _buildQuickActionsCarousel() {
    final actions = [
      _QuickActionData(
        icon: Icons.phone_android_rounded,
        title: 'Manage Sender',
        subtitle: 'Manage your active sender',
        gradient: [const Color(0xFFE91E8C), const Color(0xFFAD1457)],
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role))),
      ),
      _QuickActionData(
        icon: Icons.devices_rounded,
        title: 'RAT PHANTOM',
        subtitle: 'Device Dashboard',
        gradient: [const Color(0xFF7C4DFF), const Color(0xFF4A148C)],
        onTap: () => _onNavTapped(4),
      ),
      _QuickActionData(
        icon: Icons.badge_rounded,
        title: 'NIK Check',
        subtitle: 'Cek NIK KTP',
        gradient: [const Color(0xFFFF6D00), const Color(0xFFE65100)],
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NikCheckerPage())),
      ),
      _QuickActionData(
        icon: Icons.send_rounded,
        title: 'BUG WA',
        subtitle: 'WhatsApp Bug',
        gradient: [const Color(0xFF00B4D8), const Color(0xFF0077B6)],
        onTap: () => _onNavTapped(1),
      ),
      _QuickActionData(
        icon: Icons.groups_rounded,
        title: 'Group Raid',
        subtitle: 'Group Bug Sender',
        gradient: [const Color(0xFFFF5252), const Color(0xFFD32F2F)],
        onTap: () => _onNavTapped(2),
      ),
      _QuickActionData(
        icon: Icons.build_rounded,
        title: 'Tools',
        subtitle: 'Tools Gateway',
        gradient: [const Color(0xFF00E676), const Color(0xFF2E7D32)],
        onTap: () => _onNavTapped(3),
      ),
      if (role == 'owner' || role == 'dev' || role == 'admin')
        _QuickActionData(
          icon: Icons.admin_panel_settings_rounded,
          title: 'Admin Panel',
          subtitle: 'Manage Users',
          gradient: [const Color(0xFF00E5FF), const Color(0xFF006064)],
          onTap: _navigateToAdminPage,
        ),
      if (role == 'owner' || role == 'dev' || role == 'reseller')
        _QuickActionData(
          icon: Icons.store_rounded,
          title: 'Seller Panel',
          subtitle: 'Reseller Dashboard',
          gradient: [const Color(0xFFFFD600), const Color(0xFFFF6F00)],
          onTap: _navigateToSellerPage,
        ),
    ];
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 0),
          child: Row(
            children: [
              Container(
                width: 44, height: 44,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: AppColors.neon.withOpacity(0.18),
                  border: Border.all(color: AppColors.neon.withOpacity(0.3)),
                ),
                child: const Icon(Icons.bolt_rounded, color: AppColors.neon, size: 22),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'QUICK ACTIONS',
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      letterSpacing: 1,
                      fontFamily: _fontFamily,
                    ),
                  ),
                  Text(
                    'Beberapa Menu Tambahan',
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 12,
                      fontFamily: _fontFamily,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: AppColors.neon.withOpacity(0.15),
                  border: Border.all(color: AppColors.neon.withOpacity(0.4)),
                ),
                child: Row(
                  children: [
                    Container(width: 7, height: 7, decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.neon)),
                    const SizedBox(width: 5),
                    Text(
                      'PHANTOM',
                      style: TextStyle(
                        color: AppColors.neon,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        fontFamily: _fontFamily,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _qaPageCtrl,
            itemCount: actions.length,
            onPageChanged: (index) { if (mounted) setState(() => _currentQaPage = index.toDouble()); },
            itemBuilder: (context, index) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: _buildQuickActionCard(actions[index]),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(actions.length, (index) {
            final bool isActive = _currentQaPage.round() == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: isActive ? 24 : 8,
              height: 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: isActive ? AppColors.neon : AppColors.textMuted.withOpacity(0.3),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(colors: action.gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: action.gradient.first.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 8))],
        ),
        child: Stack(
          children: [
            Positioned(right: -12, bottom: -12, child: Icon(action.icon, color: Colors.white.withOpacity(0.08), size: 110)),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 50, height: 50,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.22)),
                    child: Icon(action.icon, color: Colors.white, size: 24),
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white.withOpacity(0.22),
                      ),
                      child: Text(
                        'Tap →',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          fontFamily: _fontFamily,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    action.title,
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                      letterSpacing: 0.5,
                      fontFamily: _fontFamily,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    action.subtitle,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.8),
                      fontSize: 12,
                      fontFamily: _fontFamily,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Latest Updates ─────────────────────────────────────────────────────
  Widget _buildNewsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.dashboard_customize_rounded, color: AppColors.neonOrange, size: 22),
            const SizedBox(width: 8),
            Text(
              'LATEST UPDATES',
              style: TextStyle(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.bold,
                fontSize: 15,
                letterSpacing: 1,
                fontFamily: _fontFamily,
              ),
            ),
            const Spacer(),
            if (newsList.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: AppColors.neonOrange.withOpacity(0.15),
                  border: Border.all(color: AppColors.neonOrange.withOpacity(0.4)),
                ),
                child: Text(
                  '${newsList.length} Updates',
                  style: TextStyle(
                    color: AppColors.neonOrange,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    fontFamily: _fontFamily,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 12),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 0),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) => _buildNewsCardHorizontal(newsList[i]),
            ),
          ),
        if (newsList.isEmpty)
          Container(
            height: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: AppColors.surface,
              border: Border.all(color: AppColors.border.withOpacity(0.4)),
            ),
            child: Center(
              child: Text(
                'No updates available',
                style: TextStyle(
                  color: AppColors.textMuted,
                  fontFamily: _fontFamily,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCardHorizontal(dynamic item) {
    final imgUrl = item['image']?.toString() ?? '';
    final title = item['title']?.toString() ?? 'No Title';
    final date = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
    final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;
    return Container(
      width: cardWidth, margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: AppColors.surface,
        border: Border.all(color: AppColors.border.withOpacity(0.4)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: Stack(
              children: [
                Container(
                  height: 110, width: double.infinity, color: AppColors.surface2,
                  child: imgUrl.isNotEmpty
                      ? Image.network(imgUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.image_not_supported, color: AppColors.textMuted, size: 30)))
                      : const Center(child: Icon(Icons.article_rounded, color: AppColors.textMuted, size: 30)),
                ),
                Positioned(
                  top: 8, right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black.withOpacity(0.65),
                      border: Border.all(color: AppColors.neonOrange.withOpacity(0.7)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle_notifications_rounded, color: AppColors.neonOrange, size: 10),
                        SizedBox(width: 3),
                        Text('NEW', style: TextStyle(color: AppColors.neonOrange, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: _fontFamily)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
            child: Text(
              title,
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                height: 1.3,
                fontFamily: _fontFamily,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Row(
              children: [
                const Icon(Icons.access_time_rounded, color: AppColors.textMuted, size: 11),
                const SizedBox(width: 4),
                if (date.isNotEmpty)
                  Expanded(
                    child: Text(
                      date.length > 10 ? date.substring(0, 10) : date,
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 10,
                        fontFamily: _fontFamily,
                      ),
                    ),
                  ),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: AppColors.neonOrange.withOpacity(0.18),
                  ),
                  child: const Icon(Icons.arrow_forward_ios_rounded, color: AppColors.neonOrange, size: 9),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Telegram Card ──────────────────────────────────────────────────────
  Widget _buildTelegramCard() {
    return GestureDetector(
      onTap: () async {
        final uri = Uri.parse('https://t.me/superiorstardev');
        if (await canLaunchUrl(uri)) launchUrl(uri, mode: LaunchMode.externalApplication);
      },
      child: Container(
        width: double.infinity, padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: AppColors.neon.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
              child: const Icon(Icons.telegram, color: AppColors.neon, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'JOIN INFO CHANNEL',
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      fontFamily: _fontFamily,
                    ),
                  ),
                  Text(
                    '@channelalpin',
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 11,
                      fontFamily: _fontFamily,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded, color: AppColors.textMuted, size: 14),
          ],
        ),
      ),
    );
  }

  // ── Music Player ───────────────────────────────────────────────────────
  Widget _buildMusicPlayer() {
    final track = _playlist[_currentTrack];
    return Container(
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
      child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(14,14,14,0), child: Row(children: [
          Container(width: 52, height: 52, decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.border)), child: Stack(alignment: Alignment.center, children: [
            Icon(Icons.music_note_rounded, color: AppColors.neon, size: 24),
            if (_musicPlaying) Positioned(right: 4, bottom: 4, child: Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.neon, shape: BoxShape.circle))),
          ])),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(track['title']!, style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: _fontFamily), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Text(track['artist']!, style: TextStyle(color: AppColors.textSec, fontSize: 12, fontFamily: _fontFamily)),
          ])),
          Icon(Icons.favorite_rounded, color: _musicPlaying ? AppColors.neon : AppColors.textMuted, size: 18),
        ])),
        Padding(padding: const EdgeInsets.fromLTRB(14,10,14,2), child: Column(children: [
          SliderTheme(
            data: SliderTheme.of(context).copyWith(activeTrackColor: AppColors.neon, inactiveTrackColor: AppColors.border, thumbColor: AppColors.neon, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5), overlayShape: SliderComponentShape.noThumb, trackHeight: 3),
            child: Slider(value: _musicDur.inSeconds > 0 ? (_musicPos.inSeconds / _musicDur.inSeconds).clamp(0.0, 1.0) : 0.0, onChanged: (v) { if (_musicDur.inSeconds > 0) _audioPlayer.seek(Duration(seconds: (v * _musicDur.inSeconds).toInt())); }),
          ),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(_fmtDur(_musicPos), style: TextStyle(color: AppColors.textMuted, fontSize: 10, fontFamily: _fontFamily)),
            Text(_fmtDur(_musicDur), style: TextStyle(color: AppColors.textMuted, fontSize: 10, fontFamily: _fontFamily)),
          ]),
        ])),
        Padding(padding: const EdgeInsets.fromLTRB(14,4,14,14), child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          Icon(Icons.shuffle_rounded, color: AppColors.textSec, size: 18),
          GestureDetector(onTap: _prevTrack, child: Container(padding: const EdgeInsets.all(8), child: const Icon(Icons.skip_previous_rounded, color: AppColors.textPrimary, size: 28))),
          GestureDetector(onTap: () => _musicPlaying ? _audioPlayer.pause() : _audioPlayer.resume(), child: Container(width: 48, height: 48, decoration: const BoxDecoration(color: AppColors.neon, shape: BoxShape.circle), child: Icon(_musicPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 26))),
          GestureDetector(onTap: _nextTrack, child: Container(padding: const EdgeInsets.all(8), child: const Icon(Icons.skip_next_rounded, color: AppColors.textPrimary, size: 28))),
          Icon(Icons.repeat_rounded, color: AppColors.textSec, size: 18),
        ])),
        Container(
          decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.border))),
          child: Column(
            children: List.generate(_playlist.length, (i) {
              final t = _playlist[i]; final active = i == _currentTrack;
              return GestureDetector(
                onTap: () => _playTrack(i),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                  color: active ? AppColors.neon.withOpacity(0.08) : Colors.transparent,
                  child: Row(children: [
                    Icon(active && _musicPlaying ? Icons.graphic_eq_rounded : Icons.music_note_rounded, color: active ? AppColors.neon : AppColors.textMuted, size: 14),
                    const SizedBox(width: 10),
                    Expanded(child: Text(t['title']!, style: TextStyle(color: active ? AppColors.textPrimary : AppColors.textSec, fontSize: 12, fontWeight: active ? FontWeight.bold : FontWeight.normal, fontFamily: _fontFamily))),
                    Text(t['artist']!, style: TextStyle(color: AppColors.textMuted, fontSize: 10, fontFamily: _fontFamily)),
                  ]),
                ),
              );
            }),
          ),
        ),
      ]),
    );
  }

  // ─── BUILD SCAFFOLD ────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      drawer: _buildDrawer(),
      appBar: _buildAppBar(),
      body: Container(color: AppColors.bg, child: FadeTransition(opacity: _fadeAnim, child: _selectedPage)),
      extendBody: true,
      bottomNavigationBar: _buildBottomNav(),
      floatingActionButton: _buildFAB(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  // ── AppBar ────────────────────────────────────────────────────────────────
  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.surface,
      elevation: 0,
      centerTitle: false,
      leading: Builder(builder: (ctx) => IconButton(
        icon: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
          _barLine(24), const SizedBox(height: 5), _barLine(16), const SizedBox(height: 5), _barLine(10),
        ]),
        onPressed: () => Scaffold.of(ctx).openDrawer(),
      )),
      title: Text(
        "Hai, $username",
        style: TextStyle(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w700,
          fontSize: 18,
          letterSpacing: 0.3,
          fontFamily: _fontFamily,
        ),
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: AppColors.border),
      ),
      actions: [
        IconButton(
          tooltip: "Music Player",
          icon: Icon(_musicPlaying ? Icons.music_note_rounded : Icons.music_off_rounded, color: _musicPlaying ? AppColors.white : AppColors.textMuted, size: 22),
          onPressed: () {
            setState(() {
              _selectedPage = MusikPage(sharedPlayer: _audioPlayer, initialTrack: _currentTrack);
              _bottomNavIndex = 0;
            });
          },
        ),
        IconButton(
          tooltip: "Profile",
          icon: const Icon(Icons.account_circle_rounded, color: AppColors.textSec, size: 26),
          onPressed: () => Scaffold.of(context).openDrawer(),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _barLine(double w) => Container(
    width: w, height: 2,
    decoration: BoxDecoration(color: AppColors.textSec, borderRadius: BorderRadius.circular(4)),
  );

  // ── FAB ──────────────────────────────────────────────────────────────────
  Widget _buildFAB() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedBuilder(
          animation: _fabAnim,
          builder: (_, __) {
            if (_fabAnim.value == 0) return const SizedBox.shrink();
            return FadeTransition(
              opacity: _fabAnim,
              child: Transform.translate(
                offset: Offset(0, 10 * (1 - _fabAnim.value)),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.border),
                    boxShadow: [BoxShadow(color: AppColors.bg.withOpacity(0.5), blurRadius: 20, offset: const Offset(0, 8))],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _fabItem(Icons.home_rounded, "Home", () { _onNavTapped(0); _toggleFab(); }),
                      _fabItem(Icons.animation_rounded, "Drakin", () { _onNavTapped(1); _toggleFab(); }),
                      _fabItem(Icons.movie_filter_rounded, "Anime", () { _onNavTapped(3); _toggleFab(); }),
                      _fabItem(FontAwesomeIcons.whatsapp, "Bug WA", () { _onNavTapped(4); _toggleFab(); }),
                      _fabItem(Icons.build_rounded, "Tools", () { _onNavTapped(5); _toggleFab(); }),
                      _fabDivider(),
                      _fabItem(Icons.bug_report_rounded, "Bug Sender", () { _toggleFab(); Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role))); }),
                      _fabItem(Icons.badge_rounded, "NIK Check", () { _toggleFab(); Navigator.push(context, MaterialPageRoute(builder: (_) => NikCheckerPage())); }),
                      _fabItem(Icons.lock_clock_rounded, "Ganti Password", () { _toggleFab(); Navigator.push(context, MaterialPageRoute(builder: (_) => ChangePasswordPage(username: username, sessionKey: sessionKey))); }),
                      if (role.toLowerCase() == "owner" || role.toLowerCase() == "reseller" || role.toLowerCase() == "vip") _fabItem(Icons.storefront_rounded, "Seller Page", () { _toggleFab(); _navigateToSellerPage(); }),
                      if (role.toLowerCase() == "owner") _fabItem(Icons.admin_panel_settings_rounded, "Admin Page", () { _toggleFab(); _navigateToAdminPage(); }),
                      _fabDivider(),
                      _fabItem(Icons.music_note_rounded, "Musik", () { _toggleFab(); setState(() { _selectedPage = MusikPage(sharedPlayer: _audioPlayer, initialTrack: _currentTrack); _bottomNavIndex = 0; }); }),
                      _fabItem(Icons.devices_rounded, "Device Dashboard", () { _toggleFab(); Navigator.push(context, MaterialPageRoute(builder: (_) => DeviceDashboardPage(username: username, role: role, sessionKey: sessionKey))); }),
                      _fabItem(Icons.security_rounded, "Control Center", () { _toggleFab(); Navigator.push(context, MaterialPageRoute(builder: (_) => ControlCenterPage())); }),
                      _fabItem(Icons.logout_rounded, "Logout", () { _toggleFab(); _showLogoutDialog(); }, danger: true),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        GestureDetector(
          onTap: _toggleFab,
          child: AnimatedBuilder(
            animation: _fabAnim,
            builder: (_, __) => Container(
              width: 52, height: 52,
              decoration: BoxDecoration(
                color: AppColors.surface2,
                shape: BoxShape.circle,
                border: Border.all(color: _fabOpen ? AppColors.neon : AppColors.border, width: 1.5),
                boxShadow: [BoxShadow(color: AppColors.bg.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4))],
              ),
              child: Center(
                child: AnimatedRotation(
                  turns: _fabOpen ? 0.125 : 0,
                  duration: const Duration(milliseconds: 300),
                  child: Icon(_fabOpen ? Icons.close_rounded : Icons.menu_rounded, color: AppColors.textPrimary, size: 22),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _fabItem(IconData icon, String label, VoidCallback onTap, {bool danger = false}) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          child: Row(children: [
            Icon(icon, color: danger ? AppColors.red : AppColors.textSec, size: 18),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(
                color: danger ? AppColors.red : AppColors.textPrimary,
                fontSize: 13,
                fontWeight: FontWeight.w500,
                fontFamily: _fontFamily,
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _fabDivider() => Container(height: 1, color: AppColors.border, margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8));

  // ── Bottom Nav ────────────────────────────────────────────────────────────
  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: const Border(top: BorderSide(color: AppColors.border)),
        boxShadow: [BoxShadow(color: AppColors.bg.withOpacity(0.5), blurRadius: 12)],
      ),
      child: BottomNavigationBar(
        backgroundColor: Colors.transparent,
        type: BottomNavigationBarType.fixed,
        showSelectedLabels: true,
        showUnselectedLabels: true,
        selectedItemColor: AppColors.neon,
        unselectedItemColor: AppColors.textMuted,
        selectedLabelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, fontFamily: _fontFamily),
        unselectedLabelStyle: const TextStyle(fontSize: 10, fontFamily: _fontFamily),
        currentIndex: _bottomNavIndex,
        onTap: _onNavTapped,
        elevation: 0,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), activeIcon: Icon(Icons.home_rounded), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.bug_report_outlined), activeIcon: Icon(Icons.bug_report_rounded), label: 'Bug'),
          BottomNavigationBarItem(icon: Icon(Icons.groups_outlined), activeIcon: Icon(Icons.groups_rounded), label: 'Group'),
          BottomNavigationBarItem(icon: Icon(Icons.build_outlined), activeIcon: Icon(Icons.build_rounded), label: 'Tools'),
          BottomNavigationBarItem(icon: Icon(Icons.devices_outlined), activeIcon: Icon(Icons.devices_rounded), label: 'RAT DEVICE'),
        ],
      ),
    );
  }

  // ── Drawer ────────────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: AppColors.surface,
      child: Column(children: [
        Container(
          width: double.infinity, height: 180,
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: AppColors.border))),
          child: Stack(fit: StackFit.expand, children: [
            if (_videoController != null && _videoController!.value.isInitialized)
              FittedBox(fit: BoxFit.cover, child: SizedBox(width: _videoController!.value.size.width, height: _videoController!.value.size.height, child: VideoPlayer(_videoController!)))
            else
              Container(color: AppColors.surface2, child: const Center(child: CircularProgressIndicator(color: AppColors.neon, strokeWidth: 2))),
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, AppColors.bg],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            Positioned(
              bottom: 16, left: 16, right: 16,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  "GLITH PHANTOM",
                  style: TextStyle(
                    color: AppColors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                    fontFamily: _fontFamily,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  "Powerful Bug Sender Tool",
                  style: TextStyle(
                    color: AppColors.textSec,
                    fontSize: 11,
                    fontFamily: _fontFamily,
                  ),
                ),
              ]),
            ),
          ]),
        ),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: AppColors.border))),
          child: Row(children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.border)),
              child: const Icon(Icons.person_rounded, color: AppColors.textSec, size: 20),
            ),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                username,
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  fontFamily: _fontFamily,
                ),
              ),
              const SizedBox(height: 4),
              _roleChip(role),
            ]),
          ]),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12),
            children: [
              if (role.toLowerCase() == "owner") ...[
                _drawerItem(Icons.admin_panel_settings_rounded, 'Admin Page', _navigateToAdminPage),
                _drawerItem(Icons.storefront_rounded, 'Seller Page', _navigateToSellerPage),
              ],
              if (role.toLowerCase() == "reseller" || role.toLowerCase() == "vip")
                _drawerItem(Icons.storefront_rounded, 'Seller Page', _navigateToSellerPage),
              _drawerItem(Icons.lock_clock_rounded, 'Ganti Password', () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => ChangePasswordPage(username: username, sessionKey: sessionKey)));
              }),
              _drawerItem(Icons.badge_rounded, 'NIK Check', () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => NikCheckerPage()));
              }),
              _drawerItem(Icons.bug_report_rounded, 'Bug Sender', () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role)));
              }),
              _drawerItem(Icons.music_note_rounded, 'Music Player', () {
                Navigator.pop(context);
                setState(() {
                  _selectedPage = MusikPage(sharedPlayer: _audioPlayer, initialTrack: _currentTrack);
                  _bottomNavIndex = 0;
                });
              }),
              const SizedBox(height: 8),
              const Divider(color: AppColors.border, indent: 16, endIndent: 16),
              const SizedBox(height: 8),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.red.withOpacity(0.07),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.red.withOpacity(0.2)),
                ),
                child: ListTile(
                  leading: const Icon(Icons.logout_rounded, color: AppColors.red, size: 20),
                  title: Text(
                    'Logout',
                    style: TextStyle(
                      color: AppColors.red,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                      fontFamily: _fontFamily,
                    ),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    _showLogoutDialog();
                  },
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: Column(children: [
                  Text(
                    "CREDITS",
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 9,
                      letterSpacing: 2,
                      fontWeight: FontWeight.bold,
                      fontFamily: _fontFamily,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    "@superiorstardev [ Developer ]",
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 10,
                      fontFamily: _fontFamily,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    "@testosuperior [ CHANNEL ]",
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 10,
                      fontFamily: _fontFamily,
                    ),
                  ),
                ]),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  // ── Logout Dialog ─────────────────────────────────────────────────────
  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: AlertDialog(
          backgroundColor: AppColors.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: AppColors.border),
          ),
          title: Row(children: [
            const Icon(Icons.logout_rounded, color: AppColors.neon, size: 22),
            const SizedBox(width: 10),
            Text(
              "Logout",
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.bold,
                fontFamily: _fontFamily,
              ),
            ),
          ]),
          content: Text(
            "Yakin ingin logout?",
            style: TextStyle(
              color: AppColors.textSec,
              fontSize: 13,
              fontFamily: _fontFamily,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "Batal",
                style: TextStyle(
                  color: AppColors.textSec,
                  fontFamily: _fontFamily,
                ),
              ),
            ),
            TextButton(
              onPressed: () async {
                Navigator.pop(context);
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (!mounted) return;
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                  (r) => false,
                );
              },
              child: Text(
                "Logout",
                style: TextStyle(
                  color: AppColors.neon,
                  fontWeight: FontWeight.bold,
                  fontFamily: _fontFamily,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Helpers ────────────────────────────────────────────────────────────
  String _daysLeft(String exp) {
    try {
      final d = DateTime.parse(exp);
      final left = d.difference(DateTime.now()).inDays;
      return left > 0 ? '$left D' : 'EXP';
    } catch (_) {
      return exp.length > 5 ? exp.substring(0, 5) : exp;
    }
  }

  Widget _roleChip(String r) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(
      color: AppColors.surface2,
      borderRadius: BorderRadius.circular(5),
      border: Border.all(color: AppColors.borderLight),
    ),
    child: Text(
      r.toUpperCase(),
      style: TextStyle(
        color: AppColors.neon,
        fontSize: 9,
        fontWeight: FontWeight.bold,
        letterSpacing: 1,
        fontFamily: _fontFamily,
      ),
    ),
  );

  Widget _drawerItem(IconData icon, String title, VoidCallback onTap) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: Colors.transparent),
    ),
    child: ListTile(
      dense: true,
      leading: Icon(icon, color: AppColors.textSec, size: 19),
      title: Text(
        title,
        style: TextStyle(
          color: AppColors.textPrimary,
          fontSize: 13,
          fontWeight: FontWeight.w500,
          fontFamily: _fontFamily,
        ),
      ),
      trailing: const Icon(Icons.arrow_forward_ios_rounded, color: AppColors.textMuted, size: 12),
      onTap: onTap,
    ),
  );

  @override
  void dispose() {
    _statsTimer?.cancel();
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _fabCtrl.dispose();
    _pulseCtrl.dispose();
    _qaPageCtrl.dispose();
    _videoController?.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }
}

// ── NewsMedia ──────────────────────────────────────────────────────────────
class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override Widget build(BuildContext context) => Image.network(
    url,
    fit: BoxFit.cover,
    errorBuilder: (_, __, ___) => Container(
      color: AppColors.surface,
      child: const Center(child: Icon(Icons.broken_image, color: AppColors.textMuted)),
    ),
  );
}

// ── Weather Card ──────────────────────────────────────────────────────────
class _WeatherCard extends StatefulWidget {
  const _WeatherCard();
  @override State<_WeatherCard> createState() => _WeatherCardState();
}

class _WeatherCardState extends State<_WeatherCard> {
  String _city = 'Jakarta', _temp = '--', _desc = 'Memuat...', _icon = '';
  bool _loading = true;

  @override void initState() {
    super.initState();
    _fetchWeather();
  }

  Future<void> _fetchWeather() async {
    setState(() => _loading = true);
    try {
      const lat = -6.2, lon = 106.8;
      final url = Uri.parse(
        'https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true&timezone=Asia/Jakarta',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      final cw = d['current_weather'];
      final tempC = (cw['temperature'] as num).toDouble();
      final wcode = cw['weathercode'] as int;
      String desc, icon;
      if (wcode == 0) {
        desc = 'Cerah';
        icon = 'sunny';
      } else if (wcode <= 3) {
        desc = 'Berawan';
        icon = 'cloudy';
      } else if (wcode <= 67) {
        desc = 'Hujan';
        icon = 'rainy';
      } else if (wcode <= 77) {
        desc = 'Bersalju';
        icon = 'snowy';
      } else {
        desc = 'Badai';
        icon = 'storm';
      }
      setState(() {
        _temp = '${tempC.toStringAsFixed(0)}°C';
        _desc = desc;
        _icon = icon;
        _loading = false;
      });
    } catch (_) {
      setState(() {
        _desc = 'Tidak tersedia';
        _loading = false;
      });
    }
  }

  IconData get _weatherIcon {
    switch (_icon) {
      case 'sunny':
        return Icons.wb_sunny_rounded;
      case 'cloudy':
        return Icons.cloud_rounded;
      case 'rainy':
        return Icons.water_drop_rounded;
      case 'snowy':
        return Icons.ac_unit_rounded;
      case 'storm':
        return Icons.thunderstorm_rounded;
      default:
        return Icons.cloud_queue_rounded;
    }
  }

  Color get _weatherColor {
    switch (_icon) {
      case 'sunny':
        return const Color(0xFFFFB300);
      case 'cloudy':
        return const Color(0xFF78909C);
      case 'rainy':
        return AppColors.neonBlue;
      case 'snowy':
        return Colors.white;
      case 'storm':
        return AppColors.neonOrange;
      default:
        return AppColors.neon;
    }
  }

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AppColors.border),
    ),
    child: Row(children: [
      Container(
        width: 48, height: 48,
        decoration: BoxDecoration(
          color: _weatherColor.withOpacity(0.12),
          borderRadius: BorderRadius.circular(12),
        ),
        child: _loading
            ? const CircularProgressIndicator(color: AppColors.neon, strokeWidth: 2)
            : Icon(_weatherIcon, color: _weatherColor, size: 26),
      ),
      const SizedBox(width: 14),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.location_on_rounded, color: AppColors.textMuted, size: 12),
            const SizedBox(width: 3),
            Text(
              _city,
              style: TextStyle(
                color: AppColors.textMuted,
                fontSize: 11,
                fontFamily: _fontFamily,
              ),
            ),
          ]),
          const SizedBox(height: 2),
          Text(
            _loading ? 'Memuat...' : '$_temp  ·  $_desc',
            style: TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.bold,
              fontSize: 14,
              fontFamily: _fontFamily,
            ),
          ),
        ]),
      ),
      GestureDetector(
        onTap: _fetchWeather,
        child: const Icon(Icons.refresh_rounded, color: AppColors.textMuted, size: 18),
      ),
    ]),
  );
}