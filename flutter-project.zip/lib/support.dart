import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:ui'; // Diperlukan untuk ImageFilter

class SupportPage extends StatefulWidget {
  const SupportPage({super.key});

  @override
  State<SupportPage> createState() => _SupportPageState();
}

class _SupportPageState extends State<SupportPage> {
  // --- COLOR PALETTE (Tema Pink / Sakura Neon) ---
  final Color bgBlack = const Color(0xFF080C15);
  final Color cardBlack = const Color(0xFF161F30);
  
  // MODIFIKASI WARNA DI SINI
  final Color neonPink = const Color(0xFFFF0080); // Primary (Hot Pink)
  final Color neonSoft = const Color(0xFFFF80AB); // Accent (Soft Pink)

  // --- 1. DATA MEMBER (Updated: 20 Members) ---
  final List<Map<String, String>> members = [
    // Original 4
    {
      "name": "Mizuki",
      "role": "Developer",
      "image": "https://a.top4top.io/p_36798lzjs1.jpg", 
      "link": "https://t.me/mizukisnji", 
    },
    {
      "name": "Wolf",
      "role": "Friends",
      "image": "https://d.top4top.io/p_3679htls91.jpg",
      "link": "https://t.me/Gabrieltzyproooool", 
    },
    {
      "name": "Xatanical", 
      "role": "Friends",
      "image": "",
      "link": "https://t.me/Xatanicvxii", 
    },
    {
      "name": "Tama",
      "role": "Friends",
      "image": "https://f.top4top.io/p_36792v63g1.jpg",
      "link": "https://t.me/Tamaa13", 
    },
    // Added 16 New Members
    {
      "name": "Otax",
      "role": "Friends",
      "image": "https://h.top4top.io/p_3679ug7m61.jpg",
      "link": "https://t.me/Otapengenkawin", 
    },
    {
      "name": "Zeppeli",
      "role": "Friends",
      "image": "https://l.top4top.io/p_3679jhqp01.jpg",
      "link": "https://t.me/ZeppeliPdf", 
    },
    {
      "name": "Zyrex",
      "role": "Friends",
      "image": "",
      "link": "https://t.me/Zyrexoffc3", 
    },
    {
      "name": "Takashi",
      "role": "Friends",
      "image": "https://e.top4top.io/p_36795653o1.jpg",
      "link": "https://t.me/TakaReal", 
    },
    {
      "name": "Pixz Aurora",
      "role": "Friends",
      "image": "https://g.top4top.io/p_3679430961.jpg",
      "link": "https://t.me/impixz", 
    },
    {
      "name": "Denis",
      "role": "Friends",
      "image": "",
      "link": "https://t.me/Deniss_erorr", 
    },
    {
      "name": "Zenn",
      "role": "Friends",
      "image": "",
      "link": "https://t.me/zeinx121", 
    },
    {
      "name": "Zanszi",
      "role": "Friends",
      "image": "",
      "link": "https://t.me/zanzsi", 
    },
    {
      "name": "Eldsz",
      "role": "Friends",
      "image": "",
      "link": "https://t.me/elkyowo", 
    },
    {
      "name": "fantzy",
      "role": "Friends",
      "image": "",
      "link": "https://t.me/fantzy_reals13", 
    },
    {
      "name": "Nando Official",
      "role": "Friends",
      "image": "",
      "link": "https://t.me/NandoOfficiali", 
    },
    {
      "name": "Aii Sigma",
      "role": "Friends",
      "image": "",
      "link": "https://t.me/AiiSigma", 
    },
  ];

  // --- 2. FUNCTION LAUNCH TELEGRAM ---
  Future<void> _launchTelegram(String urlString) async {
    final Uri url = Uri.parse(urlString); 
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text("Support Center", style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          // --- BACKGROUND GLOW EFFECT (PINK) ---
          Positioned(
            top: -100,
            left: -100,
            child: ImageFiltered( // Menggunakan ImageFiltered untuk efek blur
              imageFilter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  color: neonPink.withOpacity(0.2), // Ubah ke Pink
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ),
          
          // --- MAIN CONTENT ---
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  
                  // HEADER TEXT
                  Text(
                    "Credits & Thanks To",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.5,
                      fontFamily: 'Courier',
                      shadows: [
                        Shadow(color: neonPink, blurRadius: 15), // Ubah ke Pink
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "Meet the brilliant minds behind this project",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.grey.shade400,
                      fontSize: 14,
                      letterSpacing: 1.0,
                    ),
                  ),
                  const SizedBox(height: 40),

                  // GRID CARDS
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, 
                      crossAxisSpacing: 15,
                      mainAxisSpacing: 15,
                      childAspectRatio: 0.75, 
                    ),
                    itemCount: members.length,
                    itemBuilder: (context, index) {
                      final member = members[index];
                      return _buildMemberCard(
                        name: member['name']!,
                        role: member['role']!,
                        telegramUrl: member['link']!, 
                      );
                    },
                  ),

                  const SizedBox(height: 40),
                  
                  // FOOTER
                  Text(
                    "© 2024 Narukami Project",
                    style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- WIDGET CARD ---
  Widget _buildMemberCard({
    required String name, 
    required String role, 
    required String telegramUrl
  }) {
    return Container(
      decoration: BoxDecoration(
        color: cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: neonPink.withOpacity(0.3), // Ubah ke Pink
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Avatar Circle
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: neonSoft, // Ubah ke Soft Pink
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: neonSoft.withOpacity(0.4), // Ubah ke Soft Pink
                  blurRadius: 15,
                  spreadRadius: 2,
                )
              ],
            ),
            child: const Center(
              child: Icon(Icons.person, color: Colors.transparent, size: 40), 
            ),
          ),
          
          const SizedBox(height: 15),

          // Name
          Text(
            name,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Courier',
            ),
          ),

          const SizedBox(height: 5),

          // Role
          Text(
            role.toUpperCase(),
            textAlign: TextAlign.center,
            style: TextStyle(
              color: neonPink, // Ubah ke Pink
              fontSize: 10,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.0,
            ),
          ),

          const SizedBox(height: 15),

          // Contact Button
          GestureDetector(
            onTap: () => _launchTelegram(telegramUrl),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFF1F2937),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: Colors.grey.shade700),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(FontAwesomeIcons.telegram, color: Color(0xFFFF4081), size: 14), // Ubah icon jadi Pink
                  const SizedBox(width: 8),
                  Text(
                    "Contact",
                    style: TextStyle(
                      color: Colors.grey.shade300,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}