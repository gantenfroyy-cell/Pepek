import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';

class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({super.key, required this.sessionKey});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> with SingleTickerProviderStateMixin {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  final List<String> roleOptions = ['reseller', 'reseller1', 'owner', 'member'];
  String selectedRole = 'member';
  int currentPage = 1;
  int itemsPerPage = 10;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String newUserRole = 'member';
  bool isLoading = false;

  late AnimationController _animController;
  late Animation<double> _fadeAnimation;

  // ─── PALET WARNA BIRU GELAP MODERN ──────────────────────────────────────
  static const Color bgDark = Color(0xFF0A0E1A);
  static const Color cardDark = Color(0xFF111827);
  static const Color cardAlt = Color(0xFF1A2332);
  static const Color borderDark = Color(0xFF1F2A40);
  static const Color borderLight = Color(0xFF2D3B5A);
  static const Color neonBlue = Color(0xFF00E5FF);
  static const Color neonBlueGlow = Color(0xFF60A5FA);
  static const Color neonBlueDeep = Color(0xFF006064);
  static const Color neonGreen = Color(0xFF00E676);
  static const Color neonPink = Color(0xFFE91E8C);
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFF94A3B8);
  static const Color textMuted = Color(0xFF64748B);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnimation = CurvedAnimation(parent: _animController, curve: Curves.easeOut);

    _fetchUsers();
  }

  @override
  void dispose() {
    _animController.dispose();
    deleteController.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://publikserverpanzzid.sano.biz.id:11014/listUsers?key=$sessionKey'),
      );
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['authorized'] == true) {
          setState(() {
            fullUserList = data['users'] ?? [];
            _filterAndPaginate();
          });
        } else {
          _showSnack("Error: ${data['message'] ?? 'Akses ditolak.'}");
        }
      } else {
        _showSnack("Server error: ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("Gagal memuat data user: $e");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    if (start >= filteredList.length) return [];
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _showSnack("Masukkan username!");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://publikserverpanzzid.sano.biz.id:11014/deleteUser?key=$sessionKey&username=$username'),
      );
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['deleted'] == true) {
          _showSnack("User '${data['user']?['username'] ?? username}' dihapus!", isSuccess: true);
          deleteController.clear();
          _fetchUsers();
        } else {
          _showSnack("Gagal: ${data['message'] ?? 'Unknown error'}");
        }
      } else {
        _showSnack("Server error: ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("Error koneksi: $e");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _showSnack("Semua field wajib diisi!");
      return;
    }

    if (int.tryParse(day) == null) {
      _showSnack("Days harus berupa angka!");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://publikserverpanzzid.sano.biz.id:11014/userAdd?key=$sessionKey&username=$username&password=$password&day=$day&role=$newUserRole',
      );
      final res = await http.get(url);
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);

        if (data['created'] == true) {
          _showSnack("Akun '${data['user']?['username'] ?? username}' berhasil dibuat!", isSuccess: true);
          createUsernameController.clear();
          createPasswordController.clear();
          createDayController.clear();
          newUserRole = 'member';
          _fetchUsers();
        } else {
          _showSnack("Gagal: ${data['message'] ?? 'Unknown error'}");
        }
      } else {
        _showSnack("Server error: ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("Error koneksi: $e");
    }
    setState(() => isLoading = false);
  }

  void _showSnack(String msg, {bool isSuccess = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: isSuccess ? neonGreen : neonPink,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  // ─── BUILD ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Stack(
        children: [
          // Background glow
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [neonBlue.withOpacity(0.08), Colors.transparent]),
              ),
            ),
          ),
          
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    _buildHeader(),
                    const SizedBox(height: 25),

                    _buildSectionTitle("Create New User", Icons.person_add),
                    const SizedBox(height: 10),
                    _buildCreateUserCard(),

                    const SizedBox(height: 30),

                    _buildDeleteUserCard(),

                    const SizedBox(height: 30),

                    _buildSectionTitle("Database Users", Icons.storage),
                    const SizedBox(height: 10),
                    _buildUserListSection(),
                    
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
          
          if (isLoading)
            Container(
              color: bgDark.withOpacity(0.6),
              child: Center(child: CircularProgressIndicator(color: neonBlue)),
            ),
        ],
      ),
    );
  }

  // ─── WIDGET COMPONENTS ──────────────────────────────────────────────────

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardDark, cardAlt],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: neonBlue.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 5))
        ],
        border: Border.all(color: borderDark),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: neonBlue.withOpacity(0.12),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: neonBlue.withOpacity(0.4)),
            ),
            child: const Icon(Icons.admin_panel_settings, color: neonBlue, size: 32),
          ),
          const SizedBox(width: 15),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "ADMIN PANEL",
                style: TextStyle(
                  color: textPrimary,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Rajdhani',
                  letterSpacing: 1.5,
                ),
              ),
              Text(
                "Manage Access & Users",
                style: TextStyle(color: textSecondary, fontSize: 12, fontFamily: 'Rajdhani'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: neonBlue, size: 18),
        const SizedBox(width: 8),
        Text(
          title.toUpperCase(),
          style: TextStyle(
            color: neonBlue,
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1,
            fontFamily: 'Rajdhani',
          ),
        ),
        const SizedBox(width: 10),
        Expanded(child: Container(height: 1, color: borderDark)),
      ],
    );
  }

  Widget _buildCreateUserCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderDark),
      ),
      child: Column(
        children: [
          _buildInput(createUsernameController, "Username", Icons.person_outline),
          const SizedBox(height: 15),
          _buildInput(createPasswordController, "Password", Icons.lock_outline),
          const SizedBox(height: 15),
          Row(
            children: [
              Expanded(
                flex: 1,
                child: _buildInput(createDayController, "Days", Icons.calendar_today, isNumber: true),
              ),
              const SizedBox(width: 15),
              Expanded(
                flex: 2,
                child: _buildDropdown(newUserRole, (val) => setState(() => newUserRole = val!)),
              ),
            ],
          ),
          const SizedBox(height: 20),
          _buildGradientButton("CREATE ACCOUNT", Icons.add_circle, _createAccount),
        ],
      ),
    );
  }

  Widget _buildDeleteUserCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: BoxDecoration(
        color: neonPink.withOpacity(0.05),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: neonPink.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: neonPink, size: 20),
              const SizedBox(width: 10),
              Text("Danger Zone", style: TextStyle(color: neonPink, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani')),
            ],
          ),
          const SizedBox(height: 15),
          Row(
            children: [
              Expanded(
                child: _buildInput(deleteController, "Username to Delete", Icons.delete_outline),
              ),
              const SizedBox(width: 10),
              Container(
                decoration: BoxDecoration(
                  color: neonPink,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: IconButton(
                  onPressed: _deleteUser,
                  icon: const Icon(Icons.delete_forever, color: Colors.white),
                ),
              )
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildUserListSection() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: cardDark,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: borderDark),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              dropdownColor: cardAlt,
              value: selectedRole,
              isExpanded: true,
              icon: Icon(Icons.filter_list, color: neonBlue),
              items: roleOptions.map((role) {
                return DropdownMenuItem(
                  value: role,
                  child: Text(
                    "Filter: ${role.toUpperCase()}",
                    style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold, fontFamily: 'Rajdhani'),
                  ),
                );
              }).toList(),
              onChanged: (val) {
                setState(() {
                  selectedRole = val!;
                  _filterAndPaginate();
                });
              },
            ),
          ),
        ),
        const SizedBox(height: 15),

        if (filteredList.isEmpty)
          Container(
            padding: const EdgeInsets.all(30),
            child: Column(
              children: [
                const Icon(Icons.person_off, color: textMuted, size: 40),
                const SizedBox(height: 10),
                Text("No users found for '$selectedRole'", style: TextStyle(color: textSecondary, fontFamily: 'Rajdhani')),
              ],
            ),
          )
        else
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _getCurrentPageData().length,
            itemBuilder: (context, index) {
              final user = _getCurrentPageData()[index];
              return _buildUserItem(user);
            },
          ),
        
        const SizedBox(height: 20),
        
        if (totalPages > 1) _buildPagination(),
      ],
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cardAlt,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: borderDark),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 5, offset: const Offset(0, 2))
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: neonBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: neonBlue.withOpacity(0.3)),
            ),
            child: Icon(Icons.person, color: neonBlue, size: 20),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username']?.toString() ?? 'Unknown',
                  style: const TextStyle(
                    color: textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    fontFamily: 'Rajdhani',
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _buildMiniBadge(user['role']?.toString() ?? 'member', neonBlue),
                    const SizedBox(width: 8),
                    _buildMiniBadge("Exp: ${user['expiredDate']?.toString() ?? 'N/A'}", textMuted),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.delete_outline, color: textMuted),
            onPressed: () {
              deleteController.text = user['username']?.toString() ?? '';
              _showSnack("Tekan logo tempat sampah di 'Danger Zone' untuk menghapus user.", isSuccess: false);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                color: isActive ? neonBlue : Colors.transparent,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: isActive ? neonBlue : borderDark),
                boxShadow: isActive ? [BoxShadow(color: neonBlue.withOpacity(0.3), blurRadius: 10)] : [],
              ),
              child: Center(
                child: Text(
                  "$page",
                  style: TextStyle(
                    color: isActive ? Colors.white : textSecondary,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  // ─── Helper Widgets ─────────────────────────────────────────────────────

  Widget _buildInput(TextEditingController controller, String hint, IconData icon, {bool isNumber = false}) {
    return Container(
      decoration: BoxDecoration(
        color: cardAlt,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: borderDark),
      ),
      child: TextField(
        controller: controller,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: textPrimary, fontFamily: 'Rajdhani'),
        cursorColor: neonBlue,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: textMuted, fontFamily: 'Rajdhani'),
          prefixIcon: Icon(icon, color: neonBlue, size: 20),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        ),
      ),
    );
  }

  Widget _buildDropdown(String val, Function(String?) onChanged) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: cardAlt,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: borderDark),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          dropdownColor: cardAlt,
          value: val,
          isExpanded: true,
          icon: Icon(Icons.arrow_drop_down, color: neonBlue),
          items: roleOptions.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Text(
                role.toUpperCase(),
                style: TextStyle(color: textPrimary, fontSize: 13, fontFamily: 'Rajdhani'),
              ),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  Widget _buildGradientButton(String text, IconData icon, VoidCallback onTap) {
    return Container(
      width: double.infinity,
      height: 50,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [neonBlue, neonBlueDeep]),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(color: neonBlue.withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 4))
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(15),
          onTap: onTap,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white, size: 20),
              const SizedBox(width: 10),
              Text(
                text,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  letterSpacing: 1,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMiniBadge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.4), width: 0.5),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
          fontFamily: 'Rajdhani',
        ),
      ),
    );
  }
}