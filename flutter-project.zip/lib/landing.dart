// landing_page.dart
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'login_page.dart';

class LandingColors {
  static const bg          = Color(0xFF0A0E27);
  static const surface     = Color(0xFF141A3A);
  static const surface2    = Color(0xFF1E2650);
  static const border      = Color(0xFF2A3A7A);
  static const borderLight = Color(0xFF4A6AFA);
  static const neon        = Color(0xFF00E5FF);
  static const textPrimary = Color(0xFFFFFFFF);
  static const textSec     = Color(0xFFB0C4FF);
  static const textMuted   = Color(0xFF7A8AB0);
  static const green       = Color(0xFF00E676);
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> fadeAnimation;
  late Animation<Offset> slideAnimation;
  late VideoPlayerController _videoController;

  final Color glassColor = Colors.white.withOpacity(0.06);
  final Color glassBorder = Colors.white.withOpacity(0.15);

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );
    fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
    slideAnimation = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();

    _videoController = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
        setState(() {});
      }).catchError((_) {});
  }

  @override
  void dispose() {
    _controller.dispose();
    _videoController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Widget _buildGlassContainer({
    required Widget child,
    double borderRadius = 20,
    EdgeInsetsGeometry? padding,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassColor,
            borderRadius: BorderRadius.circular(borderRadius),
            border: Border.all(color: glassBorder, width: 1.2),
            boxShadow: [
              BoxShadow(
                color: LandingColors.bg.withOpacity(0.4),
                blurRadius: 20,
                spreadRadius: -5,
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _glassButton({
    required VoidCallback onPressed,
    required IconData icon,
    required String label,
    Color? iconColor,
    Color? textColor,
    Color? borderColor,
    double? height,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          height: height ?? 56,
          decoration: BoxDecoration(
            color: LandingColors.surface2.withOpacity(0.3),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: borderColor ?? glassBorder, width: 1.2),
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
            ),
            onPressed: onPressed,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FaIcon(icon, color: iconColor ?? LandingColors.textSec, size: 18),
                const SizedBox(width: 12),
                Text(
                  label,
                  style: TextStyle(
                    color: textColor ?? LandingColors.textSec,
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LandingColors.bg,
      body: Stack(
        children: [
          Positioned(
            top: -100,
            left: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: LandingColors.neon.withOpacity(0.08),
                boxShadow: [
                  BoxShadow(
                    color: LandingColors.neon.withOpacity(0.05),
                    blurRadius: 100,
                    spreadRadius: 50,
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: -50,
            right: -50,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: LandingColors.borderLight.withOpacity(0.08),
                boxShadow: [
                  BoxShadow(
                    color: LandingColors.borderLight.withOpacity(0.05),
                    blurRadius: 100,
                    spreadRadius: 50,
                  ),
                ],
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: fadeAnimation,
              child: SlideTransition(
                position: slideAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      _buildGlassContainer(
                        padding: const EdgeInsets.all(6),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: double.infinity,
                            height: 200,
                            color: LandingColors.surface2,
                            child: _videoController.value.isInitialized
                                ? AspectRatio(
                                    aspectRatio: _videoController.value.aspectRatio,
                                    child: VideoPlayer(_videoController),
                                  )
                                : const Center(
                                    child: CircularProgressIndicator(
                                      color: LandingColors.neon,
                                      strokeWidth: 2,
                                    ),
                                  ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),
                      const Text(
                        'PHANTOM BUG',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 4,
                          color: LandingColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Modern Neon Edition',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          letterSpacing: 2,
                          color: LandingColors.textSec,
                        ),
                      ),
                      const SizedBox(height: 25),
                      const FaIcon(
                        FontAwesomeIcons.handshake,
                        color: LandingColors.neon,
                        size: 42,
                      ),
                      const SizedBox(height: 30),
                      _buildGlassContainer(
                        padding: const EdgeInsets.all(24),
                        child: const Text(
                          'Selamat Datang di PHANTOM BUG 🚀\n'
                          'Aplikasi dengan tampilan modern dan performa optimal yang terus berkembang menghadirkan inovasi terbaru. '
                          'Dirancang untuk memberikan pengalaman penggunaan yang lebih cepat, stabil, dan responsif bagi seluruh pengguna.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: LandingColors.textSec,
                            fontSize: 14,
                            height: 1.6,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        '- PHANTOM BUG -',
                        style: TextStyle(
                          color: LandingColors.textMuted,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 3,
                        ),
                      ),
                      const SizedBox(height: 30),
                      _glassButton(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const LoginPage()),
                        ),
                        icon: FontAwesomeIcons.rocket,
                        label: 'Sign In',
                        iconColor: LandingColors.textPrimary,
                        textColor: LandingColors.textPrimary,
                        borderColor: LandingColors.borderLight,
                      ),
                      const SizedBox(height: 14),
                      _glassButton(
                        onPressed: () => _openUrl('https://t.me/superiorstardev'),
                        icon: FontAwesomeIcons.cartShopping,
                        label: 'Buy Access',
                        iconColor: LandingColors.green,
                        textColor: LandingColors.textPrimary,
                        borderColor: LandingColors.green,
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: _glassButton(
                              onPressed: () => _openUrl('https://t.me/testisuperiorstar'),
                              icon: FontAwesomeIcons.headset,
                              label: 'Join Channel',
                              iconColor: LandingColors.textSec,
                              textColor: LandingColors.textSec,
                              borderColor: LandingColors.border,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _glassButton(
                              onPressed: () => _openUrl('https://t.me/superiorstardev'),
                              icon: FontAwesomeIcons.telegram,
                              label: 'Telegram',
                              iconColor: LandingColors.neon,
                              textColor: LandingColors.textSec,
                              borderColor: LandingColors.border,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      _glassButton(
                        onPressed: () => _openUrl('https://wa.me/6282315916026'),
                        icon: FontAwesomeIcons.whatsapp,
                        label: 'WhatsApp',
                        iconColor: LandingColors.green,
                        textColor: LandingColors.textSec,
                        borderColor: LandingColors.border,
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}