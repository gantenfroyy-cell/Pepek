import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'splash.dart';

const String baseUrl = "http://bandar-panel.astralmarket.my.id:2415";

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKeyUser = GlobalKey<FormState>();
  final _formKeyPass = GlobalKey<FormState>();

  // Step: 0 = username, 1 = password
  int _step = 0;

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;

  // Tema Warna Merah Gelap + Background Hitam
  final Color bgDark = const Color(0xFF000000);
  final Color bgSecondary = const Color(0xFF1A0A0A);
  final Color primaryCyan = const Color(0xFF8B0000);
  final Color accentCyan = const Color(0xFFCC2222);
  final Color whiteText = Colors.white;
  final Color grayText = Colors.white70;

  @override
  void initState() {
    super.initState();
    _initAnim();
    initLogin();
  }

  void _initAnim() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
  }

  void _restartAnim() {
    _controller.reset();
    _controller.forward();
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true) {
          if (mounted) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) => SplashScreen(
                  username: savedUser,
                  password: savedPass,
                  role: data['role'],
                  sessionKey: data['key'],
                  expiredDate: data['expiredDate'],
                  listBug: (data['listBug'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                  listDoos: (data['listDDoS'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                  news: (data['news'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                ),
              ),
            );
          }
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    if (!_formKeyPass.currentState!.validate()) return;

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showPopup(
          title: "⏳ Access Expired",
          message: "Masa akses Anda telah habis.\nSilakan perpanjang akses.",
          color: Colors.orange,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        final String errorMsg = (validData['message'] ?? "").toLowerCase();

        if (errorMsg.contains("perangkat") ||
            errorMsg.contains("device") ||
            errorMsg.contains("another")) {
          _showPopup(
            title: "⚠️ Sesi Aktif",
            message:
                "Akun ini sedang login di perangkat lain.\nSilakan logout terlebih dahulu di perangkat lama.",
            color: Colors.orangeAccent,
          );
        } else {
          _showPopup(
            title: "❌ Login Gagal",
            message: "Username atau password salah.",
            color: Colors.redAccent,
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: username,
                password: password,
                role: validData['role'],
                sessionKey: validData['key'],
                expiredDate: validData['expiredDate'],
                listBug: (validData['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                listDoos: (validData['listDDoS'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                news: (validData['news'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
              ),
            ),
          );
        }
      }
    } catch (e) {
      _showPopup(
        title: "⚠️ Connection Error",
        message: "Gagal terhubung ke server.\nPeriksa koneksi internet Anda.",
        color: Colors.red,
      );
    }

    setState(() => isLoading = false);
  }

  void _showPopup({
    required String title,
    required String message,
    Color color = Colors.redAccent,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A0A0A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          title,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 20),
        ),
        content: Text(
          message,
          style: const TextStyle(color: Colors.white70, fontSize: 15),
        ),
        actions: [
          if (showContact)
            TextButton(
              onPressed: () async {
                await launchUrl(Uri.parse("https://t.me/"),
                    mode: LaunchMode.externalApplication);
              },
              child: const Text(
                "Contact Admin",
                style: TextStyle(
                    color: Color(0xFFCC2222), fontWeight: FontWeight.bold),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "Close",
              style: TextStyle(color: Colors.white54),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnim,
          child: Column(
            children: [
              // ── SPACER — dorong konten ke bawah ──
              const Spacer(),

              // ── BOTTOM AREA: karakter + input + tombol ──
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 400),
                transitionBuilder: (child, anim) => SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0.15, 0),
                    end: Offset.zero,
                  ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOut)),
                  child: FadeTransition(opacity: anim, child: child),
                ),
                child: _step == 0
                    ? _buildUsernameStep()
                    : _buildPasswordStep(),
              ),

              // ── FOOTER ──
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(
                      color: primaryCyan.withOpacity(0.15),
                      width: 1,
                    ),
                  ),
                ),
                child: Text(
                  "© Vynex",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: primaryCyan.withOpacity(0.5),
                    fontSize: 11,
                    letterSpacing: 1.2,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Step dot indicator ──
  Widget _buildStepDot({required bool active}) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: active ? 28 : 10,
      height: 10,
      decoration: BoxDecoration(
        color: active ? accentCyan : primaryCyan.withOpacity(0.3),
        borderRadius: BorderRadius.circular(6),
      ),
    );
  }

  // ── STEP 1: Username ──
  Widget _buildUsernameStep() {
    return Container(
      key: const ValueKey('username_step'),
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Karakter + input dalam satu baris
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              // Foto karakter 1
              Image.asset(
                'assets/images/1.png',
                height: 80,
                fit: BoxFit.contain,
              ),
              const SizedBox(width: 12),
              // Input username
              Expanded(
                child: Form(
                  key: _formKeyUser,
                  child: _buildInput(
                    userController,
                    "Username",
                    Icons.person_outline,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Tombol NEXT
          _buildNextButton(),
        ],
      ),
    );
  }

  // ── STEP 2: Password ──
  Widget _buildPasswordStep() {
    return Container(
      key: const ValueKey('password_step'),
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Karakter + input dalam satu baris
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              // Foto karakter 2
              Image.asset(
                'assets/images/2.png',
                height: 80,
                fit: BoxFit.contain,
              ),
              const SizedBox(width: 12),
              // Input password
              Expanded(
                child: Form(
                  key: _formKeyPass,
                  child: _buildInput(
                    passController,
                    "Password",
                    Icons.lock_outline,
                    true,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Tombol back kecil + Sign In
          Row(
            children: [
              // Tombol back
              GestureDetector(
                onTap: () {
                  setState(() => _step = 0);
                  _restartAnim();
                },
                child: Container(
                  width: 48,
                  height: 55,
                  decoration: BoxDecoration(
                    color: bgSecondary,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                        color: primaryCyan.withOpacity(0.4), width: 1.5),
                  ),
                  child: Icon(Icons.arrow_back_ios_new,
                      color: accentCyan, size: 18),
                ),
              ),
              const SizedBox(width: 10),
              // Tombol SIGN IN
              Expanded(child: _buildSignInButton()),
            ],
          ),
        ],
      ),
    );
  }

  // ── Input Field ──
  Widget _buildInput(
    TextEditingController controller,
    String label,
    IconData icon, [
    bool isPassword = false,
  ]) {
    return Container(
      height: 55,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: bgSecondary,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: primaryCyan.withOpacity(0.5), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: accentCyan.withOpacity(0.08),
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword ? _obscurePassword : false,
        style: const TextStyle(color: Colors.white, fontSize: 15),
        decoration: InputDecoration(
          labelText: null,
          hintText: isPassword ? "Password" : "Username",
          hintStyle: TextStyle(color: primaryCyan.withOpacity(0.5), fontSize: 13),
          prefixIcon: Icon(icon, color: accentCyan, size: 20),
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: primaryCyan.withOpacity(0.7),
                    size: 20,
                  ),
                  onPressed: () {
                    setState(() => _obscurePassword = !_obscurePassword);
                  },
                )
              : null,
          border: InputBorder.none,
          contentPadding: EdgeInsets.zero,
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return "$label tidak boleh kosong";
          }
          return null;
        },
      ),
    );
  }

  // ── Teks Buy Here ──
  Widget _buildBuyHereText() {
    return RichText(
      text: TextSpan(
        text: "Tidak Memiliki Akses? ",
        style: TextStyle(color: grayText, fontSize: 13),
        children: [
          WidgetSpan(
            alignment: PlaceholderAlignment.middle,
            child: GestureDetector(
              onTap: () async {
                await launchUrl(
                  Uri.parse("https://t.me/"),
                  mode: LaunchMode.externalApplication,
                );
              },
              child: Text(
                "Buy Here",
                style: TextStyle(
                  color: accentCyan,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.underline,
                  decorationColor: accentCyan,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Tombol NEXT ──
  Widget _buildNextButton() {
    return SizedBox(
      width: double.infinity,
      height: 55,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            if (_formKeyUser.currentState!.validate()) {
              setState(() => _step = 1);
              _restartAnim();
            }
          },
          borderRadius: BorderRadius.circular(16),
          child: Ink(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primaryCyan, accentCyan]),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: accentCyan.withOpacity(0.4),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: const Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "Next",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                  SizedBox(width: 8),
                  Icon(Icons.arrow_forward_ios, color: Colors.white, size: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Tombol SIGN IN ──
  Widget _buildSignInButton() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: isLoading ? 60 : double.infinity,
      height: 55,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [primaryCyan, accentCyan]),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: accentCyan.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isLoading ? null : login,
          borderRadius: BorderRadius.circular(16),
          child: Center(
            child: isLoading
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      strokeWidth: 3,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : const Text(
                    "Sign In",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
