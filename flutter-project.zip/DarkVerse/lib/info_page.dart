import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> {
  Map<String, dynamic>? serverInfo;
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.grey;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  // Track which rule card is expanded
  int? _expandedIndex;

  // --- TEMA UNGU TUA ---
  final Color bgDark = const Color(0xFF0A0610);
  final Color primaryPurple = const Color(0xFF4A148C);
  final Color accentPurple = const Color(0xFF7B1FA2);
  final Color neonPurple = const Color(0xFFCE93D8);
  final Color lightPurple = const Color(0xFFAB47BC);
  final Color dimPurple = const Color(0xFF2A1040);
  final Color primaryWhite = const Color(0xFFE8E0F0);
  final Color textGrey = const Color(0xFF7A6A8A);
  final Color cardGlass = const Color(0xFF120D1A);
  final Color borderGlass = const Color(0xFF2A1A3A);

  @override
  void initState() {
    super.initState();
    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(
        Uri.parse('http://kentodnyabu.panelptero.web.id:30003/getServerInfo?key=${widget.sessionKey}'),
      );
      if (res.statusCode == 200) {
        setState(() {
          serverInfo = jsonDecode(res.body);
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(
        Uri.parse('http://kentodnyabu.panelptero.web.id:30003/ping?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 3));

      final end = DateTime.now();
      final duration = end.difference(start).inMilliseconds;

      if (res.statusCode == 200) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          if (duration < 200) {
            apiStatusColor = Colors.greenAccent;
          } else if (duration < 500) {
            apiStatusColor = Colors.amber;
          } else {
            apiStatusColor = Colors.orangeAccent;
          }
          apiStatusText = "SYS.ONLINE :: ${duration}ms";
        });
      } else {
        throw Exception("Failed");
      }
    } catch (e) {
      setState(() {
        isApiOnline = false;
        apiPingMs = 0;
        apiStatusColor = Colors.redAccent;
        apiStatusText = "SYS.OFFLINE";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: bgDark,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          automaticallyImplyLeading: false,
          title: const Text("INFO", style: TextStyle(color: Color(0xFFE8E0F0), fontFamily: 'Orbitron')),
        ),
        body: Center(child: CircularProgressIndicator(color: neonPurple)),
      );
    }

    final List<Map<String, dynamic>> rulesList = [
      {
        "icon": Icons.swap_horiz_outlined,
        "code": "001",
        "title": "NO ACCOUNT BARTERING",
        "desc": "Akun eksklusif Sylent tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran log akan terpantau.",
        "penalty": "Akun akan DIHAPUS permanen tanpa kompensasi. Aktivitas barter tercatat di log sistem dan dapat dilaporkan.",
      },
      {
        "icon": Icons.person_off_outlined,
        "code": "002",
        "title": "STRICTLY PERSONAL USE",
        "desc": "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID).",
        "penalty": "Deteksi multi-device akan memicu suspend otomatis. Akun dibekukan dan tidak dapat dipulihkan.",
      },
      {
        "icon": Icons.money_off_outlined,
        "code": "003",
        "title": "RESELLING PROHIBITED",
        "desc": "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif milik role berwenang (Partner, Owner, atau Reseller).",
        "penalty": "Hak akses dicabut sepenuhnya. Akun penjual dan pembeli akan dihapus dari sistem.",
      },
      {
        "icon": Icons.timer_off_outlined,
        "code": "004",
        "title": "ILLEGAL DURATION SALES",
        "desc": "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi.",
        "penalty": "Akun langsung di-terminate. Tidak ada pemulihan atau refund untuk pelanggaran jenis ini.",
      },
      {
        "icon": Icons.trending_down_outlined,
        "code": "005",
        "title": "PRICE DUMPING BAN",
        "desc": "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami.",
        "penalty": "Sanksi berupa pembekuan akun reseller dan penghapusan hak distribusi secara permanen.",
      },
    ];

    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        centerTitle: false,
        titleSpacing: 16,
        title: Row(
          children: [
            Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                color: neonPurple,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: neonPurple.withOpacity(0.7), blurRadius: 8, spreadRadius: 2)],
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              "EULA & SYSTEM INFO",
              style: TextStyle(
                color: Color(0xFFE8E0F0),
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                fontSize: 16,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCompactApiStatus(),
            const SizedBox(height: 24),

            // Section header
            Row(
              children: [
                Container(
                  width: 3,
                  height: 20,
                  decoration: BoxDecoration(
                    color: neonPurple,
                    boxShadow: [BoxShadow(color: neonPurple.withOpacity(0.8), blurRadius: 6)],
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  "USER PROTOCOLS",
                  style: TextStyle(
                    color: neonPurple,
                    fontSize: 13,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    letterSpacing: 3,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Rules list
            ...rulesList.asMap().entries.map((entry) {
              final int index = entry.key;
              final Map<String, dynamic> rule = entry.value;
              final bool isExpanded = _expandedIndex == index;

              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      _expandedIndex = isExpanded ? null : index;
                    });
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    curve: Curves.easeInOut,
                    decoration: BoxDecoration(
                      color: cardGlass,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isExpanded ? neonPurple.withOpacity(0.6) : borderGlass,
                        width: isExpanded ? 1.2 : 1,
                      ),
                      boxShadow: isExpanded
                          ? [BoxShadow(color: neonPurple.withOpacity(0.08), blurRadius: 12, spreadRadius: 1)]
                          : [],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Rule header row
                        Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Icon box
                              Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1A0A2A),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: dimPurple.withOpacity(0.5)),
                                ),
                                child: Icon(rule['icon'] as IconData, color: neonPurple, size: 22),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          rule['code'] as String,
                                          style: TextStyle(
                                            color: dimPurple,
                                            fontSize: 11,
                                            fontFamily: 'Orbitron',
                                            letterSpacing: 1,
                                          ),
                                        ),
                                        const Spacer(),
                                        AnimatedRotation(
                                          turns: isExpanded ? 0.5 : 0,
                                          duration: const Duration(milliseconds: 250),
                                          child: Icon(Icons.keyboard_arrow_down, color: dimPurple, size: 18),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      rule['title'] as String,
                                      style: const TextStyle(
                                        color: Color(0xFFE8E0F0),
                                        fontFamily: 'Orbitron',
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                        letterSpacing: 1,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      rule['desc'] as String,
                                      style: TextStyle(color: textGrey, fontSize: 12, height: 1.5, fontFamily: 'ShareTechMono'),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Expandable penalty section
                        AnimatedCrossFade(
                          duration: const Duration(milliseconds: 250),
                          crossFadeState: isExpanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
                          firstChild: const SizedBox.shrink(),
                          secondChild: Column(
                            children: [
                              Container(
                                height: 1,
                                margin: const EdgeInsets.symmetric(horizontal: 14),
                                color: neonPurple.withOpacity(0.25),
                              ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(Icons.warning_amber_rounded, color: neonPurple, size: 16),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "SANKSI",
                                            style: TextStyle(
                                              color: neonPurple,
                                              fontFamily: 'Orbitron',
                                              fontSize: 11,
                                              fontWeight: FontWeight.bold,
                                              letterSpacing: 2,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            rule['penalty'] as String,
                                            style: TextStyle(
                                              color: lightPurple,
                                              fontSize: 12,
                                              height: 1.5,
                                              fontFamily: 'ShareTechMono',
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),

            const SizedBox(height: 8),

            // Footer disclaimer
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Column(
                  children: [
                    Icon(Icons.shield_outlined, color: dimPurple, size: 24),
                    const SizedBox(height: 10),
                    Text(
                      "Dengan menggunakan aplikasi ini, pengguna dianggap telah menyetujui seluruh peraturan di atas.",
                      style: TextStyle(color: textGrey, fontSize: 11, fontStyle: FontStyle.italic, height: 1.6),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    Container(
                      height: 2,
                      width: 80,
                      decoration: BoxDecoration(
                        color: dimPurple,
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: [BoxShadow(color: neonPurple.withOpacity(0.4), blurRadius: 6)],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCompactApiStatus() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: apiStatusColor,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: apiStatusColor.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            apiStatusText.toUpperCase(),
            style: const TextStyle(
              color: Color(0xFF7A6A8A),
              fontSize: 12,
              fontFamily: 'ShareTechMono',
              letterSpacing: 1,
            ),
          ),
          const Spacer(),
          Icon(Icons.settings_outlined, color: dimPurple, size: 18),
        ],
      ),
    );
  }
}