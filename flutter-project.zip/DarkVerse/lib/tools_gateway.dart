import 'dart:ui';
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  String? _expandedCategory;

  // === TEMA UNGU TUA ===
  static const Color primaryDark   = Color(0xFF0A0610);
  static const Color primaryPurple = Color(0xFF4A148C);
  static const Color accentPurple  = Color(0xFF7B1FA2);
  static const Color neonPurple    = Color(0xFFCE93D8);
  static const Color cardDark      = Color(0xFF120D1A);
  static const Color cardBorder    = Color(0xFF2A1A3A);
  static const Color primaryWhite  = Color(0xFFE8E0F0);

  final Map<String, AnimationController> _controllers = {};
  final Map<String, Animation<double>> _animations   = {};

  final List<_CategoryItem> _categories = [];

  @override
  void initState() {
    super.initState();
    _initCategories();
    for (final cat in _categories) {
      final controller = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 300),
      );
      _controllers[cat.key] = controller;
      _animations[cat.key]  = CurvedAnimation(
        parent: controller,
        curve: Curves.easeInOut,
      );
    }
  }

  void _initCategories() {
    _categories.addAll([
      _CategoryItem(
        key: 'ddos',
        icon: Icons.flash_on,
        title: 'DDoS Tools',
        subtitle: 'Attack & Server',
        children: [],
      ),
      _CategoryItem(
        key: 'network',
        icon: Icons.wifi,
        title: 'Network',
        subtitle: 'WiFi & Spam',
        children: [],
      ),
      _CategoryItem(
        key: 'osint',
        icon: Icons.search,
        title: 'OSINT',
        subtitle: 'Investigation',
        children: [],
      ),
      _CategoryItem(
        key: 'downloader',
        icon: Icons.download,
        title: 'Downloader',
        subtitle: 'Social Media',
        children: [],
      ),
      _CategoryItem(
        key: 'utilities',
        icon: Icons.build,
        title: 'Utilities',
        subtitle: 'Extra Tools',
        children: [],
      ),
      _CategoryItem(
        key: 'watch',
        icon: Icons.video_library,
        title: 'Watch',
        subtitle: 'Entertainment & Media',
        children: [],
      ),
      _CategoryItem(
        key: 'quick',
        icon: Icons.rocket_launch,
        title: 'Quick Access',
        subtitle: 'Favorites',
        children: [],
      ),
    ]);
  }

  @override
  void dispose() {
    for (final c in _controllers.values) c.dispose();
    super.dispose();
  }

  void _toggleCategory(String key) {
    setState(() {
      if (_expandedCategory == key) {
        _controllers[key]?.reverse();
        _expandedCategory = null;
      } else {
        if (_expandedCategory != null) {
          _controllers[_expandedCategory!]?.reverse();
        }
        _expandedCategory = key;
        _controllers[key]?.forward();
      }
    });
  }

  List<_ToolOption> _getChildren(String key) {
    switch (key) {
      case 'ddos':
        return [
          _ToolOption(
            icon: Icons.flash_on,
            label: 'Attack Panel',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AttackPanel(
                  sessionKey: widget.sessionKey,
                  listDoos: widget.listDoos,
                ),
              ),
            ),
          ),
          _ToolOption(
            icon: Icons.dns,
            label: 'Manage Server',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ManageServerPage(keyToken: widget.sessionKey),
              ),
            ),
          ),
        ];
      case 'network':
        return [
          _ToolOption(
            icon: Icons.newspaper_outlined,
            label: 'Spam NGL',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => NglPage()),
            ),
          ),
          _ToolOption(
            icon: Icons.wifi_off,
            label: 'WiFi Killer (Internal)',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => WifiKillerPage()),
            ),
          ),
          if (widget.userRole == 'vip' || widget.userRole == 'owner')
            _ToolOption(
              icon: Icons.router,
              label: 'WiFi Killer (External)',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WifiInternalPage(sessionKey: widget.sessionKey),
                ),
              ),
            ),
        ];
      case 'osint':
        return [
          _ToolOption(
            icon: Icons.badge,
            label: 'NIK Detail',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NikCheckerPage()),
            ),
          ),
          _ToolOption(
            icon: Icons.domain,
            label: 'Domain OSINT',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const DomainOsintPage()),
            ),
          ),
          _ToolOption(
            icon: Icons.person_search,
            label: 'Phone Lookup',
            onTap: () => _showComingSoon(),
          ),
          _ToolOption(
            icon: Icons.email,
            label: 'Email OSINT',
            onTap: () => _showComingSoon(),
          ),
        ];
      case 'downloader':
        return [
          _ToolOption(
            icon: Icons.video_library,
            label: 'TikTok Downloader',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()),
            ),
          ),
          _ToolOption(
            icon: Icons.camera_alt,
            label: 'Instagram Downloader',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()),
            ),
          ),
        ];
      case 'utilities':
        return [
          _ToolOption(
            icon: Icons.qr_code,
            label: 'QR Generator',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const QrGeneratorPage()),
            ),
          ),
          _ToolOption(
            icon: Icons.security,
            label: 'IP Scanner',
            onTap: () => _showComingSoon(),
          ),
          _ToolOption(
            icon: Icons.network_check,
            label: 'Port Scanner',
            onTap: () => _showComingSoon(),
          ),
        ];
      case 'watch':
        return [
          _ToolOption(
            icon: Icons.live_tv,
            label: 'Live Streams',
            onTap: () => _showComingSoon(),
          ),
          _ToolOption(
            icon: Icons.movie,
            label: 'Media Library',
            onTap: () => _showComingSoon(),
          ),
        ];
      case 'quick':
        return [
          _ToolOption(
            icon: Icons.star,
            label: 'Favorites',
            onTap: () => _showComingSoon(),
          ),
        ];
      default:
        return [];
    }
  }

  void _showComingSoon() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.hourglass_top, color: primaryWhite),
            const SizedBox(width: 8),
            const Text(
              'Feature Coming Soon!',
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                color: primaryWhite,
              ),
            ),
          ],
        ),
        backgroundColor: primaryPurple,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // Hitung total metode dari semua kategori
  int get _totalMethods {
    int total = 0;
    for (final cat in _categories) {
      total += _getChildren(cat.key).length;
    }
    return total;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      body: SafeArea(
        child: Column(
          children: [
            // ======== HEADER ========
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
              decoration: BoxDecoration(
                color: cardDark,
                border: Border(
                  bottom: BorderSide(color: primaryPurple.withOpacity(0.35), width: 1),
                ),
              ),
              child: Row(
                children: [
                  // Shield icon
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: primaryPurple.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: primaryPurple.withOpacity(0.5),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: primaryPurple.withOpacity(0.2),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.shield,
                      color: neonPurple,
                      size: 26,
                    ),
                  ),
                  const SizedBox(width: 14),
                  // Title + subtitle
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ShaderMask(
                          shaderCallback: (bounds) => LinearGradient(
                            colors: [neonPurple, primaryPurple],
                          ).createShader(bounds),
                          child: const Text(
                            'TOOLS DASHBOARD',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          'Advanced Security & OSINT Tools',
                          style: TextStyle(
                            color: primaryWhite.withOpacity(0.4),
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // ADMIN badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: primaryPurple.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: primaryPurple.withOpacity(0.6),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      widget.userRole.toUpperCase(),
                      style: const TextStyle(
                        color: neonPurple,
                        fontSize: 12,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ======== STATS BAR ========
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              child: Row(
                children: [
                  _StatChip(
                    icon: Icons.flash_on,
                    label: '$_totalMethods Methods',
                    accentPurple: neonPurple,
                    primaryPurple: primaryPurple,
                    cardDark: cardDark,
                  ),
                  const SizedBox(width: 10),
                  _StatChip(
                    icon: Icons.category,
                    label: '${_categories.length} Categories',
                    accentPurple: neonPurple,
                    primaryPurple: primaryPurple,
                    cardDark: cardDark,
                  ),
                  const SizedBox(width: 10),
                  _StatChip(
                    icon: Icons.lock,
                    label: widget.userRole.toUpperCase(),
                    accentPurple: neonPurple,
                    primaryPurple: primaryPurple,
                    cardDark: cardDark,
                  ),
                ],
              ),
            ),

            // ======== CATEGORY LIST ========
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                itemCount: _categories.length,
                itemBuilder: (context, index) {
                  final cat      = _categories[index];
                  final isExpanded = _expandedCategory == cat.key;
                  final children = _getChildren(cat.key);

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Column(
                      children: [
                        // ---- CATEGORY ROW ----
                        GestureDetector(
                          onTap: () => _toggleCategory(cat.key),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            decoration: BoxDecoration(
                              color: isExpanded
                                  ? primaryPurple.withOpacity(0.12)
                                  : cardDark,
                              borderRadius: BorderRadius.only(
                                topLeft: const Radius.circular(14),
                                topRight: const Radius.circular(14),
                                bottomLeft: Radius.circular(isExpanded ? 0 : 14),
                                bottomRight: Radius.circular(isExpanded ? 0 : 14),
                              ),
                              border: Border.all(
                                color: isExpanded
                                    ? primaryPurple.withOpacity(0.7)
                                    : primaryPurple.withOpacity(0.2),
                                width: 1,
                              ),
                              boxShadow: isExpanded
                                  ? [
                                      BoxShadow(
                                        color: primaryPurple.withOpacity(0.15),
                                        blurRadius: 12,
                                        offset: const Offset(0, 2),
                                      ),
                                    ]
                                  : [],
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 14,
                            ),
                            child: Row(
                              children: [
                                // Icon box
                                Container(
                                  width: 44,
                                  height: 44,
                                  decoration: BoxDecoration(
                                    color: primaryPurple.withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      color: primaryPurple.withOpacity(0.4),
                                    ),
                                  ),
                                  child: Icon(
                                    cat.icon,
                                    color: neonPurple,
                                    size: 22,
                                  ),
                                ),
                                const SizedBox(width: 14),
                                // Title + subtitle
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        cat.title,
                                        style: TextStyle(
                                          color: isExpanded ? neonPurple : primaryWhite,
                                          fontSize: 15,
                                          fontFamily: 'Orbitron',
                                          fontWeight: FontWeight.bold,
                                          shadows: isExpanded
                                              ? [
                                                  Shadow(
                                                    color: neonPurple.withOpacity(0.6),
                                                    blurRadius: 8,
                                                  ),
                                                ]
                                              : [],
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        cat.subtitle,
                                        style: TextStyle(
                                          color: primaryWhite.withOpacity(0.4),
                                          fontSize: 12,
                                          fontFamily: 'ShareTechMono',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // Chevron
                                AnimatedRotation(
                                  turns: isExpanded ? 0.5 : 0,
                                  duration: const Duration(milliseconds: 300),
                                  child: Icon(
                                    Icons.keyboard_arrow_down,
                                    color: isExpanded
                                        ? neonPurple
                                        : primaryWhite.withOpacity(0.35),
                                    size: 22,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        // ---- EXPANDED SUBMENU ----
                        SizeTransition(
                          sizeFactor: _animations[cat.key]!,
                          axisAlignment: -1,
                          child: Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFF0D0618),
                              borderRadius: const BorderRadius.only(
                                bottomLeft: Radius.circular(14),
                                bottomRight: Radius.circular(14),
                              ),
                              border: Border(
                                left: BorderSide(
                                    color: primaryPurple.withOpacity(0.5), width: 1),
                                right: BorderSide(
                                    color: primaryPurple.withOpacity(0.5), width: 1),
                                bottom: BorderSide(
                                    color: primaryPurple.withOpacity(0.5), width: 1),
                              ),
                            ),
                            child: Column(
                              children: children.map((option) {
                                final isLast = option == children.last;
                                return Column(
                                  children: [
                                    if (children.indexOf(option) == 0)
                                      Divider(
                                        height: 1,
                                        color: primaryPurple.withOpacity(0.2),
                                      ),
                                    InkWell(
                                      onTap: option.onTap,
                                      splashColor: primaryPurple.withOpacity(0.1),
                                      highlightColor: primaryPurple.withOpacity(0.05),
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 16,
                                          vertical: 13,
                                        ),
                                        child: Row(
                                          children: [
                                            const SizedBox(width: 6),
                                            Container(
                                              width: 34,
                                              height: 34,
                                              decoration: BoxDecoration(
                                                color: primaryPurple.withOpacity(0.1),
                                                borderRadius:
                                                    BorderRadius.circular(8),
                                                border: Border.all(
                                                  color: primaryPurple.withOpacity(0.25),
                                                ),
                                              ),
                                              child: Icon(
                                                option.icon,
                                                color: neonPurple,
                                                size: 17,
                                              ),
                                            ),
                                            const SizedBox(width: 14),
                                            Expanded(
                                              child: Text(
                                                option.label,
                                                style: const TextStyle(
                                                  color: primaryWhite,
                                                  fontSize: 13,
                                                  fontFamily: 'Orbitron',
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ),
                                            Icon(
                                              Icons.arrow_forward_ios,
                                              color: neonPurple.withOpacity(0.6),
                                              size: 13,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    if (!isLast)
                                      Divider(
                                        height: 1,
                                        indent: 70,
                                        color: primaryPurple.withOpacity(0.1),
                                      ),
                                  ],
                                );
                              }).toList(),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ======== STAT CHIP WIDGET ========
class _StatChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color accentPurple;
  final Color primaryPurple;
  final Color cardDark;

  const _StatChip({
    required this.icon,
    required this.label,
    required this.accentPurple,
    required this.primaryPurple,
    required this.cardDark,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        decoration: BoxDecoration(
          color: cardDark,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: primaryPurple.withOpacity(0.25), width: 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: accentPurple, size: 15),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: const Color(0xFFE8E0F0).withOpacity(0.75),
                  fontSize: 11,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ======== DATA CLASSES ========
class _CategoryItem {
  final String key;
  final IconData icon;
  final String title;
  final String subtitle;
  final List<_ToolOption> children;

  _CategoryItem({
    required this.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.children,
  });
}

class _ToolOption {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  _ToolOption({
    required this.icon,
    required this.label,
    required this.onTap,
  });
}