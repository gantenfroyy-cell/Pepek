import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  // --- TEMA RED/DARK ---
  static const Color bgLight = Color(0xFFFFFFFF);
  static const Color primaryPurple = Color(0xFF4A148C);
  static const Color accentPurple = Color(0xFF8E24AA);
  static const Color cardGlass = Color(0xFFF1E6FF);
  static const Color borderGlass = Color(0xFF6A1B9A);

  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: accentRed),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "Customer Service",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, primaryRed.withOpacity(0.1), bgDark],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: primaryRed.withOpacity(0.2),
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: primaryRed.withOpacity(0.4), blurRadius: 20)],
                  ),
                  child: Icon(Icons.support_agent_rounded, size: 60, color: accentRed),
                ),
                SizedBox(height: 24),
                Text(
                  "Need Help?",
                  style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  "Contact us through our social media platforms below.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white60, fontSize: 14),
                ),
                SizedBox(height: 40),
                Column(
                  children: [
                    _buildContactButton(label: "Telegram", icon: FontAwesomeIcons.telegram, color: Colors.blue, url: "https://t.me/IdoxxIsHere"),
                    SizedBox(height: 16),
                    _buildContactButton(label: "WhatsApp", icon: FontAwesomeIcons.whatsapp, color: Colors.green, url: "https://wa.me/6285668867705"),
                    SizedBox(height: 16),
                    _buildContactButton(label: "TikTok", icon: FontAwesomeIcons.tiktok, color: Colors.white, url: "https://www.tiktok.com/@imidoxxx?_r=1&_t=ZS-97t1kWERzT6"),
                    SizedBox(height: 16),
                    _buildContactButton(label: "Instagram", icon: FontAwesomeIcons.instagram, color: Colors.pinkAccent, url: "https://www.instagram.com/rido_ananda_putra?igsh=MTE5dW5iMXg3MjNyeg=="),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactButton({
    required String label,
    required IconData icon,
    required Color color,
    required String url,
  }) {
    return InkWell(
      onTap: () => _launchUrl(url),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderGlass),
          boxShadow: [BoxShadow(color: primaryRed.withOpacity(0.1), blurRadius: 10, offset: Offset(0, 4))],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(color: color.withOpacity(0.2), shape: BoxShape.circle),
                  child: FaIcon(icon, color: color, size: 24),
                ),
                SizedBox(width: 20),
                Text(label, style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
              ],
            ),
            Icon(Icons.arrow_forward_ios, color: Colors.white54, size: 16),
          ],
        ),
      ),
    );
  }
}