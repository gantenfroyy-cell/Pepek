import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:video_player/video_player.dart';
import 'package:just_audio/just_audio.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';

// ============================================================
// DEPENDENCY (tambahkan ke pubspec.yaml):
//   image_picker: ^1.0.7
//   just_audio: ^0.9.36
//   flutter_sound: ^9.2.13
//   permission_handler: ^11.3.1
//   path_provider: ^2.1.2
//   http: ^1.2.0
//   http_parser: ^4.0.2
//   mime: ^1.0.5
//
// android/app/src/main/AndroidManifest.xml — tambahkan:
//   <uses-permission android:name="android.permission.RECORD_AUDIO"/>
//   <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
// ============================================================

class GlobalChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const GlobalChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<GlobalChatPage> createState() => _GlobalChatPageState();
}

class _GlobalChatPageState extends State<GlobalChatPage>
    with TickerProviderStateMixin {
  late WebSocketChannel _channel;
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();
  final List<Map<String, dynamic>> _messages = [];
  bool _isConnected = false;
  bool _showEmoji = false;
  bool _isRecording = false;
  Duration _recordDuration = Duration.zero;
  late AnimationController _pulseController;

  // flutter_sound recorder
  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  bool _recorderReady = false;
  String? _recordingPath;
  Timer? _recordTimer;

  // Tema
  static const Color _bgDark    = Color(0xFF000000);
  static const Color _primaryRed = Color(0xFFB71C1C);
  static const Color _accentRed  = Color(0xFFFF1744);
  static const Color _borderRed  = Color(0xFF3A1A1A);

  // Emoji list
  final List<String> _emojiList = [
    '😀','😂','🤣','😍','🥰','😎','🤩','😏','😒','😢',
    '😡','🤬','💀','👻','🔥','💯','✅','❌','⚡','💥',
    '🎉','🎮','👑','💎','🚀','💪','🙏','👍','👎','❤️',
    '💔','🖤','💣','🗡️','⚔️','🛡️','🎯','🎲','🃏','🏆',
    '😈','👿','🤡','💩','🤖','👾','🎃','🦊','🐉','🦁',
  ];

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
    _initRecorder();
    _connectWebSocket();
  }

  Future<void> _initRecorder() async {
    await _recorder.openRecorder();
    setState(() => _recorderReady = true);
  }

  void _connectWebSocket() {
    try {
      _channel = WebSocketChannel.connect(
        Uri.parse('ws://fourzprivat.servervoidvitality.my.id:3371'),
      );

      _channel.sink.add(jsonEncode({
        'type': 'globalAuth',
        'key': widget.sessionKey,
        'username': widget.username,
      }));

      _channel.sink.add(jsonEncode({'type': 'globalHistory'}));

      setState(() => _isConnected = true);

      _channel.stream.listen(
        (event) {
          try {
            final data = jsonDecode(event);
            if (data['type'] == 'globalMessage' ||
                data['type'] == 'globalHistory') {
              setState(() {
                if (data['type'] == 'globalHistory') {
                  _messages.clear();
                  for (final m in (data['messages'] as List)) {
                    _messages.add(Map<String, dynamic>.from(m));
                  }
                } else {
                  _messages.add(Map<String, dynamic>.from(data['message']));
                }
              });
              _scrollToBottom();
            }
          } catch (_) {}
        },
        onDone: () => setState(() => _isConnected = false),
        onError: (_) => setState(() => _isConnected = false),
      );
    } catch (_) {
      setState(() => _isConnected = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent + 100,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ─── Kirim teks / emoji ───────────────────────────────────
  void _sendText() {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty) return;
    if (!_isConnected) {
      _showSnack('Tidak terhubung ke server');
      return;
    }
    _channel.sink.add(jsonEncode({
      'type': 'globalMessage',
      'key': widget.sessionKey,
      'username': widget.username,
      'msgType': 'text',
      'content': text,
    }));
    _msgCtrl.clear();
    setState(() => _showEmoji = false);
  }

  // ─── Upload media ke server lalu kirim URL ────────────────
  Future<void> _sendMedia(File file, String msgType) async {
    try {
      final mimeType =
          lookupMimeType(file.path) ?? 'application/octet-stream';
      final mime = mimeType.split('/');
      final req = http.MultipartRequest(
        'POST',
        Uri.parse('http://bandar-panel.astralmarket.my.id:2415/uploadGlobalMedia'),
      );
      req.headers['x-session-key'] = widget.sessionKey;
      req.files.add(await http.MultipartFile.fromPath(
        'file',
        file.path,
        contentType: MediaType(mime[0], mime[1]),
      ));
      final resp = await req.send();
      if (resp.statusCode == 200) {
        final body = jsonDecode(await resp.stream.bytesToString());
        _channel.sink.add(jsonEncode({
          'type': 'globalMessage',
          'key': widget.sessionKey,
          'username': widget.username,
          'msgType': msgType,
          'content': body['url'],
        }));
      } else {
        _showSnack('Upload gagal (${resp.statusCode})');
      }
    } catch (e) {
      _showSnack('Upload error: $e');
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final xfile =
        await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (xfile != null) await _sendMedia(File(xfile.path), 'image');
  }

  Future<void> _pickVideo() async {
    final picker = ImagePicker();
    final xfile = await picker.pickVideo(source: ImageSource.gallery);
    if (xfile != null) await _sendMedia(File(xfile.path), 'video');
  }

  // ─── Record audio (flutter_sound) ────────────────────────
  Future<void> _toggleRecord() async {
    if (!_recorderReady) {
      _showSnack('Recorder belum siap');
      return;
    }

    if (_isRecording) {
      // Stop recording
      _recordTimer?.cancel();
      await _recorder.stopRecorder();
      setState(() {
        _isRecording = false;
        _recordDuration = Duration.zero;
      });
      if (_recordingPath != null) {
        await _sendMedia(File(_recordingPath!), 'audio');
      }
    } else {
      // Request permission
      final micStatus = await Permission.microphone.request();
      if (!micStatus.isGranted) {
        _showSnack('Izin mikrofon ditolak');
        return;
      }

      final dir = await getTemporaryDirectory();
      _recordingPath =
          '${dir.path}/rec_${DateTime.now().millisecondsSinceEpoch}.aac';

      await _recorder.startRecorder(
        toFile: _recordingPath,
        codec: Codec.aacADTS,
      );

      setState(() {
        _isRecording = true;
        _recordDuration = Duration.zero;
      });

      // Timer hitung durasi
      _recordTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => _recordDuration += const Duration(seconds: 1));
      });
    }
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: _primaryRed),
    );
  }

  // ─── Build pesan bubble ───────────────────────────────────
  Widget _buildBubble(Map<String, dynamic> msg) {
    final isMine = msg['username'] == widget.username;
    final username = msg['username'] ?? 'unknown';
    final msgType = msg['msgType'] ?? 'text';
    final content = msg['content'] ?? '';
    final time =
        msg['time'] != null ? _formatTime(msg['time']) : '';

    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.78,
        ),
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Column(
          crossAxisAlignment:
              isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (!isMine)
              Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 3),
                child: Text(
                  username,
                  style: const TextStyle(
                    color: Color(0xFFFF5252),
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
            Container(
              padding: EdgeInsets.all(msgType == 'text' ? 12 : 6),
              decoration: BoxDecoration(
                color: isMine
                    ? const Color(0xFF2A0505)
                    : const Color(0xFF111111),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(isMine ? 16 : 4),
                  bottomRight: Radius.circular(isMine ? 4 : 16),
                ),
                border: Border.all(
                  color: isMine
                      ? const Color(0xFFFF1744).withOpacity(0.4)
                      : const Color(0xFF3A1A1A),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: isMine
                        ? const Color(0xFFFF1744).withOpacity(0.08)
                        : Colors.black26,
                    blurRadius: 8,
                  ),
                ],
              ),
              child: _buildContent(msgType, content),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 3, left: 4, right: 4),
              child: Text(
                time,
                style: const TextStyle(
                  color: Colors.white24,
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(String msgType, String content) {
    switch (msgType) {
      case 'image':
        return ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.network(
            content,
            width: 220,
            height: 180,
            fit: BoxFit.cover,
            loadingBuilder: (_, child, prog) => prog == null
                ? child
                : SizedBox(
                    width: 220,
                    height: 180,
                    child: Center(
                      child: CircularProgressIndicator(
                        value: prog.expectedTotalBytes != null
                            ? prog.cumulativeBytesLoaded /
                                prog.expectedTotalBytes!
                            : null,
                        color: _accentRed,
                        strokeWidth: 2,
                      ),
                    ),
                  ),
            errorBuilder: (_, __, ___) => Container(
              width: 220,
              height: 100,
              color: _borderRed,
              child: const Icon(Icons.broken_image, color: Colors.white30),
            ),
          ),
        );
      case 'video':
        return _VideoMessage(url: content);
      case 'audio':
        return _AudioMessage(url: content);
      default:
        return Text(
          content,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontFamily: 'ShareTechMono',
            height: 1.4,
          ),
        );
    }
  }

  String _formatTime(String iso) {
    try {
      final dt = DateTime.parse(iso).toLocal();
      final h = dt.hour.toString().padLeft(2, '0');
      final m = dt.minute.toString().padLeft(2, '0');
      return '$h:$m';
    } catch (_) {
      return '';
    }
  }

  // ─── Emoji Picker ─────────────────────────────────────────
  Widget _buildEmojiPanel() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      height: _showEmoji ? 220 : 0,
      color: const Color(0xFF0A0A0A),
      child: _showEmoji
          ? GridView.builder(
              padding: const EdgeInsets.all(8),
              gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 10,
                mainAxisSpacing: 6,
                crossAxisSpacing: 6,
              ),
              itemCount: _emojiList.length,
              itemBuilder: (_, i) => GestureDetector(
                onTap: () {
                  final cursor = _msgCtrl.selection.base.offset;
                  final text = _msgCtrl.text;
                  final newText = cursor >= 0
                      ? text.substring(0, cursor) +
                          _emojiList[i] +
                          text.substring(cursor)
                      : text + _emojiList[i];
                  _msgCtrl.text = newText;
                  _msgCtrl.selection = TextSelection.collapsed(
                    offset: (cursor >= 0 ? cursor : text.length) +
                        _emojiList[i].length,
                  );
                },
                child: Center(
                  child: Text(_emojiList[i],
                      style: const TextStyle(fontSize: 22)),
                ),
              ),
            )
          : const SizedBox.shrink(),
    );
  }

  // ─── Input bar ────────────────────────────────────────────
  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
      decoration: BoxDecoration(
        color: const Color(0xFF080808),
        border: Border(
          top: BorderSide(color: _accentRed.withOpacity(0.2)),
        ),
      ),
      child: _isRecording ? _buildRecordingBar() : _buildNormalInput(),
    );
  }

  Widget _buildRecordingBar() {
    return Row(
      children: [
        AnimatedBuilder(
          animation: _pulseController,
          builder: (_, __) => Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _accentRed
                  .withOpacity(0.5 + _pulseController.value * 0.5),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            '🎙 Merekam... ${_recordDuration.inSeconds}s',
            style: const TextStyle(
              color: Colors.white70,
              fontFamily: 'ShareTechMono',
              fontSize: 13,
            ),
          ),
        ),
        GestureDetector(
          onTap: _toggleRecord,
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: _primaryRed,
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.stop_rounded, color: Colors.white, size: 18),
                SizedBox(width: 6),
                Text('Stop',
                    style: TextStyle(color: Colors.white, fontSize: 13)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildNormalInput() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        // Emoji toggle
        _iconBtn(
          icon: Icons.emoji_emotions_outlined,
          color: _showEmoji ? _accentRed : Colors.white38,
          onTap: () => setState(() => _showEmoji = !_showEmoji),
        ),
        // Lampiran foto/video
        _iconBtn(
          icon: Icons.attach_file_rounded,
          onTap: _showAttachMenu,
        ),
        // Rekam suara
        _iconBtn(
          icon: Icons.mic_none_rounded,
          onTap: _toggleRecord,
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Container(
            constraints:
                const BoxConstraints(minHeight: 40, maxHeight: 120),
            decoration: BoxDecoration(
              color: const Color(0xFF111111),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _borderRed),
            ),
            child: TextField(
              controller: _msgCtrl,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontFamily: 'ShareTechMono',
              ),
              maxLines: null,
              keyboardType: TextInputType.multiline,
              textInputAction: TextInputAction.newline,
              onTap: () => setState(() => _showEmoji = false),
              decoration: const InputDecoration(
                hintText: 'Ketik pesan...',
                hintStyle:
                    TextStyle(color: Colors.white24, fontSize: 13),
                border: InputBorder.none,
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              ),
            ),
          ),
        ),
        const SizedBox(width: 6),
        // Tombol kirim
        GestureDetector(
          onTap: _sendText,
          child: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFFFF1744), Color(0xFFB71C1C)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: _accentRed.withOpacity(0.4),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: const Icon(Icons.send_rounded,
                color: Colors.white, size: 20),
          ),
        ),
      ],
    );
  }

  Widget _iconBtn({
    required IconData icon,
    Color color = Colors.white38,
    required VoidCallback onTap,
  }) {
    return IconButton(
      icon: Icon(icon, color: color, size: 22),
      onPressed: onTap,
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
    );
  }

  void _showAttachMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0D0D0D),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding:
            const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _attachItem(
              icon: Icons.image_rounded,
              label: 'Foto',
              color: const Color(0xFF4CAF50),
              onTap: () {
                Navigator.pop(context);
                _pickImage();
              },
            ),
            _attachItem(
              icon: Icons.videocam_rounded,
              label: 'Video',
              color: const Color(0xFF2196F3),
              onTap: () {
                Navigator.pop(context);
                _pickVideo();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _attachItem({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.15),
              border: Border.all(color: color.withOpacity(0.5)),
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(height: 8),
          Text(label,
              style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 12,
                  fontFamily: 'ShareTechMono')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      appBar: AppBar(
        backgroundColor: _bgDark,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: _accentRed),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _primaryRed.withOpacity(0.15),
                border:
                    Border.all(color: _accentRed.withOpacity(0.4)),
              ),
              child: const Icon(Icons.public_rounded,
                  color: _accentRed, size: 18),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'GLOBAL CHAT',
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    letterSpacing: 1.5,
                  ),
                ),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _isConnected
                            ? Colors.greenAccent
                            : Colors.red,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      _isConnected ? 'Online' : 'Offline',
                      style: TextStyle(
                        color: _isConnected
                            ? Colors.greenAccent
                            : Colors.red,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  Color(0xFFFF1744),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _messages.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    itemCount: _messages.length,
                    itemBuilder: (_, i) => _buildBubble(_messages[i]),
                  ),
          ),
          _buildEmojiPanel(),
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.chat_bubble_outline_rounded,
              color: _accentRed.withOpacity(0.3), size: 64),
          const SizedBox(height: 16),
          const Text(
            'Belum ada pesan',
            style: TextStyle(
              color: Colors.white38,
              fontFamily: 'Orbitron',
              fontSize: 14,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Jadilah yang pertama mengirim pesan!',
            style: TextStyle(
              color: Colors.white24,
              fontFamily: 'ShareTechMono',
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _recordTimer?.cancel();
    _recorder.closeRecorder();
    _channel.sink.close(status.goingAway);
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    _pulseController.dispose();
    super.dispose();
  }
}

// ─── Widget Video Message ─────────────────────────────────────
class _VideoMessage extends StatefulWidget {
  final String url;
  const _VideoMessage({required this.url});

  @override
  State<_VideoMessage> createState() => _VideoMessageState();
}

class _VideoMessageState extends State<_VideoMessage> {
  VideoPlayerController? _ctrl;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (mounted) setState(() => _initialized = true);
      });
  }

  @override
  void dispose() {
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialized) {
      return const SizedBox(
        width: 220,
        height: 140,
        child: Center(
          child: CircularProgressIndicator(
              color: Color(0xFFFF1744), strokeWidth: 2),
        ),
      );
    }
    return GestureDetector(
      onTap: () {
        setState(() {
          _ctrl!.value.isPlaying ? _ctrl!.pause() : _ctrl!.play();
        });
      },
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Stack(
          alignment: Alignment.center,
          children: [
            AspectRatio(
              aspectRatio: _ctrl!.value.aspectRatio,
              child: VideoPlayer(_ctrl!),
            ),
            if (!_ctrl!.value.isPlaying)
              Container(
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.black54,
                ),
                padding: const EdgeInsets.all(12),
                child: const Icon(Icons.play_arrow_rounded,
                    color: Colors.white, size: 30),
              ),
          ],
        ),
      ),
    );
  }
}

// ─── Widget Audio Message ─────────────────────────────────────
class _AudioMessage extends StatefulWidget {
  final String url;
  const _AudioMessage({required this.url});

  @override
  State<_AudioMessage> createState() => _AudioMessageState();
}

class _AudioMessageState extends State<_AudioMessage> {
  final AudioPlayer _player = AudioPlayer();
  bool _playing = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  @override
  void initState() {
    super.initState();
    _player.setUrl(widget.url).then((_) {
      if (mounted) {
        setState(() => _duration = _player.duration ?? Duration.zero);
      }
    });
    _player.positionStream.listen((pos) {
      if (mounted) setState(() => _position = pos);
    });
    _player.playerStateStream.listen((state) {
      if (mounted) setState(() => _playing = state.playing);
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final progress = _duration.inMilliseconds > 0
        ? _position.inMilliseconds / _duration.inMilliseconds
        : 0.0;

    return SizedBox(
      width: 220,
      child: Row(
        children: [
          GestureDetector(
            onTap: () =>
                _playing ? _player.pause() : _player.play(),
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color:
                    const Color(0xFFFF1744).withOpacity(0.15),
                border: Border.all(
                    color:
                        const Color(0xFFFF1744).withOpacity(0.5)),
              ),
              child: Icon(
                _playing
                    ? Icons.pause_rounded
                    : Icons.play_arrow_rounded,
                color: const Color(0xFFFF1744),
                size: 22,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: progress.toDouble(),
                    backgroundColor: Colors.white12,
                    valueColor: const AlwaysStoppedAnimation(
                        Color(0xFFFF1744)),
                    minHeight: 3,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${_fmt(_position)} / ${_fmt(_duration)}',
                  style: const TextStyle(
                    color: Colors.white38,
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
