package com.familyguard.child.service

import android.accessibilityservice.AccessibilityService
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.familyguard.child.data.FirestoreRepo
import com.familyguard.child.data.RuleData
import com.familyguard.child.ui.BlockOverlayActivity
import java.text.SimpleDateFormat
import java.util.*

/**
 * Layanan ini HANYA mendengarkan event "jendela/app berpindah" (lihat
 * accessibility_service_config.xml: canRetrieveWindowContent="false").
 * Tidak membaca isi layar, tidak mencatat ketikan.
 *
 * Saat app baru dibuka: cek apakah app itu diblokir, atau apakah
 * pemakaian hari ini sudah melewati batas -> tampilkan BlockOverlayActivity.
 */
class BlockerAccessibilityService : AccessibilityService() {

    private lateinit var repo: FirestoreRepo
    private var rulesCache: Map<String, RuleData> = emptyMap()
    private var lastBlockedPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        repo = FirestoreRepo(this)
        repo.listenRules { rules -> rulesCache = rules }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return // jangan blokir app Family Guard sendiri
        if (pkg == lastBlockedPackage) return // sudah ditangani

        val rule = rulesCache[pkg] ?: return

        if (rule.blocked) {
            showBlockOverlay(rule.appName, reason = "blocked")
            lastBlockedPackage = pkg
            return
        }

        if (rule.dailyLimitMinutes > 0) {
            val usedToday = getUsedMinutesToday(pkg)
            if (usedToday >= rule.dailyLimitMinutes) {
                showBlockOverlay(rule.appName, reason = "limit")
                lastBlockedPackage = pkg
                return
            }
        }

        lastBlockedPackage = null
    }

    private fun getUsedMinutesToday(pkg: String): Int {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY, cal.timeInMillis, System.currentTimeMillis()
        )
        val totalMs = stats.filter { it.packageName == pkg }.sumOf { it.totalTimeInForeground }
        return (totalMs / 60000L).toInt()
    }

    private fun showBlockOverlay(appName: String, reason: String) {
        val intent = Intent(this, BlockOverlayActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra(BlockOverlayActivity.EXTRA_APP_NAME, appName)
            putExtra(BlockOverlayActivity.EXTRA_REASON, reason)
        }
        startActivity(intent)
    }

    override fun onInterrupt() {}
}
