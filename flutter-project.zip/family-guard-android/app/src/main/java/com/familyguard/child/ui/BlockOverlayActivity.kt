package com.familyguard.child.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.familyguard.child.databinding.ActivityBlockOverlayBinding

/**
 * Layar ini ditampilkan saat anak membuka aplikasi yang diblokir orang tua,
 * atau saat batas waktu harian habis. Pesannya ramah anak, jelas, dan
 * TIDAK berpura-pura jadi error sistem atau pesan yang menakutkan —
 * beda total dari "ransomware-style" overlay yang pernah diminta sebelumnya.
 */
class BlockOverlayActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBlockOverlayBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBlockOverlayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val appName = intent.getStringExtra(EXTRA_APP_NAME) ?: "Aplikasi ini"
        val reason = intent.getStringExtra(EXTRA_REASON) ?: "blocked"

        binding.titleText.text = if (reason == "limit") "Waktu habis" else "Aplikasi dibatasi"
        binding.messageText.text = if (reason == "limit")
            "Kamu sudah mencapai batas waktu harian untuk $appName. Coba lagi besok, atau minta orang tua menambah waktunya."
        else
            "$appName saat ini dibatasi oleh orang tuamu."

        binding.closeButton.setOnClickListener {
            // kembali ke layar utama (home), bukan menutup app tertentu secara paksa
            val homeIntent = android.content.Intent(android.content.Intent.ACTION_MAIN)
            homeIntent.addCategory(android.content.Intent.CATEGORY_HOME)
            homeIntent.flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(homeIntent)
            finish()
        }
    }

    override fun onBackPressed() {
        // sengaja tidak melakukan apa-apa selain kembali ke home,
        // supaya anak tidak "kembali" ke app yang diblokir
        binding.closeButton.performClick()
    }

    companion object {
        const val EXTRA_APP_NAME = "extra_app_name"
        const val EXTRA_REASON = "extra_reason"
    }
}
