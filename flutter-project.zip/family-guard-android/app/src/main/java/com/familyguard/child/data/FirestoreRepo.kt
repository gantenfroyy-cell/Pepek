package com.familyguard.child.data

import android.content.Context
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

/**
 * Lapisan akses data ke Firestore untuk sisi anak.
 *
 * Model data (sama dengan dashboard orang tua):
 *  families/{familyId}/children/{childId}
 *  families/{familyId}/children/{childId}/rules/{packageName} -> {appName, dailyLimitMinutes, blocked}
 *  families/{familyId}/children/{childId}/usage/{yyyy-MM-dd}  -> {perApp: {pkg: minutes}, hourly: {hour: pkg}}
 *
 * CATATAN KEAMANAN: di produksi sebaiknya childId+familyId disimpan lewat proses
 * pairing yang menghasilkan token unik per perangkat (bukan cuma kode 6 digit statis),
 * dan Firestore rules memverifikasi token tersebut alih-alih "allow write: if true".
 * Kode ini adalah titik awal, bukan hardened production build.
 */
class FirestoreRepo(context: Context) {

    private val db = FirebaseFirestore.getInstance()
    private val prefs = context.getSharedPreferences("family_guard_prefs", Context.MODE_PRIVATE)

    var familyId: String?
        get() = prefs.getString("familyId", null)
        set(value) { prefs.edit().putString("familyId", value).apply() }

    var childId: String?
        get() = prefs.getString("childId", null)
        set(value) { prefs.edit().putString("childId", value).apply() }

    val isPaired: Boolean get() = familyId != null && childId != null

    /** Cari anak berdasarkan kode pairing yang ditampilkan di dashboard orang tua. */
    fun findChildByPairingCode(
        code: String,
        onResult: (familyId: String, childId: String, childName: String) -> Unit,
        onNotFound: () -> Unit
    ) {
        db.collectionGroup("children")
            .whereEqualTo("pairingCode", code)
            .whereEqualTo("paired", false)
            .limit(1)
            .get()
            .addOnSuccessListener { snap ->
                val doc = snap.documents.firstOrNull()
                if (doc == null) {
                    onNotFound()
                    return@addOnSuccessListener
                }
                val famId = doc.reference.parent.parent?.id
                if (famId == null) { onNotFound(); return@addOnSuccessListener }
                onResult(famId, doc.id, doc.getString("name") ?: "Anak")
            }
            .addOnFailureListener { onNotFound() }
    }

    fun completePairing(familyId: String, childId: String, deviceModel: String, androidVersion: String, onDone: () -> Unit) {
        this.familyId = familyId
        this.childId = childId
        db.collection("families").document(familyId)
            .collection("children").document(childId)
            .update(
                mapOf(
                    "paired" to true,
                    "deviceModel" to deviceModel,
                    "androidVersion" to androidVersion
                )
            )
            .addOnCompleteListener { onDone() }
    }

    fun listenRules(onChange: (Map<String, RuleData>) -> Unit): ListenerRegistration? {
        val fid = familyId ?: return null
        val cid = childId ?: return null
        return db.collection("families").document(fid)
            .collection("children").document(cid)
            .collection("rules")
            .addSnapshotListener { snap, _ ->
                val map = mutableMapOf<String, RuleData>()
                snap?.documents?.forEach { d ->
                    map[d.id] = RuleData(
                        appName = d.getString("appName") ?: d.id,
                        dailyLimitMinutes = (d.getLong("dailyLimitMinutes") ?: 0L).toInt(),
                        blocked = d.getBoolean("blocked") ?: false
                    )
                }
                onChange(map)
            }
    }

    fun pushUsage(dateKey: String, perApp: Map<String, Int>, hourly: Map<String, String>) {
        val fid = familyId ?: return
        val cid = childId ?: return
        db.collection("families").document(fid)
            .collection("children").document(cid)
            .collection("usage").document(dateKey)
            .set(mapOf("perApp" to perApp, "hourly" to hourly))
    }
}

data class RuleData(
    val appName: String,
    val dailyLimitMinutes: Int,
    val blocked: Boolean
)
