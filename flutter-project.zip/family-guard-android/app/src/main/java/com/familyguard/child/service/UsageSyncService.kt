package com.familyguard.child.service

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.familyguard.child.MainActivity
import com.familyguard.child.R
import com.familyguard.child.data.FirestoreRepo
import java.text.SimpleDateFormat
import java.util.*

/**
 * Foreground service yang berjalan selama Family Guard aktif.
 * Notifikasi TIDAK BISA disembunyikan/dibisukan permanen — ini disengaja,
 * supaya anak selalu tahu kapan aplikasi ini sedang aktif memantau.
 *
 * Setiap 60 detik: membaca UsageStatsManager untuk total menit pemakaian
 * tiap app hari ini, lalu mengunggahnya ke Firestore agar dashboard
 * orang tua ter-update.
 */
class UsageSyncService : Service() {

    private lateinit var repo: FirestoreRepo
    private val handler = Handler(Looper.getMainLooper())
    private val syncInterval = 60_000L

    private val syncRunnable = object : Runnable {
        override fun run() {
            syncUsageNow()
            handler.postDelayed(this, syncInterval)
        }
    }

    override fun onCreate() {
        super.onCreate()
        repo = FirestoreRepo(this)
        startForeground(NOTIF_ID, buildNotification())
        handler.post(syncRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(syncRunnable)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun syncUsageNow() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val startOfDay = cal.timeInMillis
        val now = System.currentTimeMillis()

        val perAppMs = mutableMapOf<String, Long>()
        val hourlyDominant = mutableMapOf<Int, MutableMap<String, Long>>()

        val events = usm.queryEvents(startOfDay, now)
        val event = UsageEvents.Event()
        var lastForegroundPkg: String? = null
        var lastForegroundTime = startOfDay

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                if (lastForegroundPkg != null) {
                    accumulate(perAppMs, hourlyDominant, lastForegroundPkg!!, lastForegroundTime, event.timeStamp)
                }
                lastForegroundPkg = event.packageName
                lastForegroundTime = event.timeStamp
            } else if (event.eventType == UsageEvents.Event.ACTIVITY_PAUSED) {
                if (lastForegroundPkg == event.packageName) {
                    accumulate(perAppMs, hourlyDominant, lastForegroundPkg!!, lastForegroundTime, event.timeStamp)
                    lastForegroundPkg = null
                }
            }
        }
        // app masih di foreground sampai sekarang
        if (lastForegroundPkg != null) {
            accumulate(perAppMs, hourlyDominant, lastForegroundPkg!!, lastForegroundTime, now)
        }

        val perAppMinutes = perAppMs.mapValues { (it.value / 60000L).toInt() }
            .filterValues { it > 0 }

        val hourlyPkg = hourlyDominant.mapValues { (_, pkgMap) ->
            pkgMap.maxByOrNull { it.value }?.key ?: ""
        }.mapKeys { it.key.toString() }

        val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        repo.pushUsage(dateKey, perAppMinutes, hourlyPkg)
    }

    private fun accumulate(
        perAppMs: MutableMap<String, Long>,
        hourlyDominant: MutableMap<Int, MutableMap<String, Long>>,
        pkg: String,
        from: Long,
        to: Long
    ) {
        if (to <= from) return
        perAppMs[pkg] = (perAppMs[pkg] ?: 0L) + (to - from)

        // distribusikan durasi ke jam-jam yang relevan (untuk linimasa)
        val cal = Calendar.getInstance()
        var cursor = from
        while (cursor < to) {
            cal.timeInMillis = cursor
            val hour = cal.get(Calendar.HOUR_OF_DAY)
            cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59); cal.set(Calendar.MILLISECOND, 999)
            val hourEnd = minOf(cal.timeInMillis, to)
            val dur = hourEnd - cursor
            val hourMap = hourlyDominant.getOrPut(hour) { mutableMapOf() }
            hourMap[pkg] = (hourMap[pkg] ?: 0L) + dur
            cursor = hourEnd + 1
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "family_guard_active"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle(getString(R.string.notif_active_title))
            .setContentText(getString(R.string.notif_active_text))
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIF_ID = 1001
        fun start(context: Context) {
            val intent = Intent(context, UsageSyncService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
