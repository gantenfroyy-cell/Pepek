package com.familyguard.child

import android.app.AppOpsManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.familyguard.child.data.FirestoreRepo
import com.familyguard.child.databinding.ActivityMainBinding
import com.familyguard.child.service.UsageSyncService

/**
 * Layar ini SELALU bisa dibuka anak kapan saja untuk melihat status
 * ("Family Guard aktif, dipasang oleh orang tua"). Ini bukan aplikasi
 * yang bersembunyi dari app drawer.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repo: FirestoreRepo

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repo = FirestoreRepo(this)

        binding.pairButton.setOnClickListener { attemptPairing() }
        binding.grantUsageAccessButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        binding.grantAccessibilityButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun refreshUi() {
        val paired = repo.isPaired
        val usageGranted = hasUsageAccess()
        val accessibilityGranted = isAccessibilityServiceEnabled()

        binding.pairingSection.visibility = if (!paired) android.view.View.VISIBLE else android.view.View.GONE
        binding.statusSection.visibility = if (paired) android.view.View.VISIBLE else android.view.View.GONE

        binding.statusText.text = buildString {
            append("Terhubung ke akun orang tua.\n\n")
            append(if (usageGranted) "✅ Izin akses penggunaan: aktif\n" else "⚠️ Izin akses penggunaan: belum aktif\n")
            append(if (accessibilityGranted) "✅ Layanan pembatas aplikasi: aktif\n" else "⚠️ Layanan pembatas aplikasi: belum aktif\n")
        }

        binding.grantUsageAccessButton.visibility = if (!usageGranted) android.view.View.VISIBLE else android.view.View.GONE
        binding.grantAccessibilityButton.visibility = if (!accessibilityGranted) android.view.View.VISIBLE else android.view.View.GONE

        if (paired && usageGranted) {
            UsageSyncService.start(this)
        }
    }

    private fun attemptPairing() {
        val code = binding.pairingCodeInput.text.toString().trim()
        if (code.length != 6) {
            Toast.makeText(this, "Masukkan kode 6 digit dari dashboard orang tua", Toast.LENGTH_SHORT).show()
            return
        }
        binding.pairButton.isEnabled = false
        repo.findChildByPairingCode(
            code,
            onResult = { familyId, childId, childName ->
                repo.completePairing(
                    familyId, childId,
                    deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
                    androidVersion = Build.VERSION.RELEASE
                ) {
                    Toast.makeText(this, "Terhubung sebagai $childName", Toast.LENGTH_LONG).show()
                    refreshUi()
                }
            },
            onNotFound = {
                binding.pairButton.isEnabled = true
                Toast.makeText(this, "Kode tidak ditemukan atau sudah dipakai", Toast.LENGTH_SHORT).show()
            }
        )
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/.service.BlockerAccessibilityService"
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }
}
