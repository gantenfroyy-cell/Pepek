# Family Guard — Android App (Anak)

Aplikasi parental control yang **transparan**: ikon jelas terlihat di HP anak, ada notifikasi permanen saat aktif, dan tidak menyembunyikan diri.

## Fitur
- Melihat izin batas waktu & blokir aplikasi dari orang tua (via Firestore)
- Melacak waktu pemakaian per-aplikasi (Usage Stats API)
- Menampilkan layar "Waktu Habis" saat anak melebihi batas atau membuka app yang diblokir
- Notifikasi permanen "Family Guard aktif" (wajib untuk Accessibility Service, dan supaya transparan ke anak)

## Yang SENGAJA TIDAK ada
Tidak ada keylogger, akses SMS/kontak/Gmail, kamera/mic tersembunyi, anti-uninstall, atau fitur yang menyembunyikan aplikasi ini dari anak. Parental control yang sah tidak butuh itu semua.

## Cara build
1. Buka folder ini di **Android Studio**.
2. Buat proyek Firebase di [Firebase Console](https://console.firebase.google.com), aktifkan **Authentication (Email/Password)** dan **Cloud Firestore**.
3. Daftarkan aplikasi Android dengan package name `com.familyguard.child`, download `google-services.json`, taruh di `app/google-services.json`.
4. Sync Gradle, lalu Build > Build APK.
5. Install APK ke HP anak, buka app, ikuti langkah setup (izin Usage Access + Accessibility + kode pairing dari dashboard orang tua).

## Struktur
```
app/src/main/java/com/familyguard/child/
  MainActivity.kt              -> layar setup & status, pairing dengan kode dari dashboard
  ui/BlockOverlayActivity.kt    -> layar "waktu habis / diblokir"
  service/UsageSyncService.kt   -> foreground service, kirim data pemakaian ke Firestore tiap menit
  service/BlockerAccessibilityService.kt -> cek app yang sedang dibuka, blokir jika perlu
  data/FirestoreRepo.kt         -> helper akses Firestore
```

## Firestore security rules (contoh dasar)
Terapkan lewat Firebase Console > Firestore > Rules, supaya hanya orang tua pemilik keluarga yang bisa mengubah aturan, dan anak (anonim/paired) hanya bisa menulis data pemakaiannya sendiri:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /families/{familyId} {
      allow read, write: if request.auth != null && request.auth.uid == familyId;
      match /children/{childId} {
        allow read, write: if request.auth != null && request.auth.uid == familyId;
        match /usage/{doc} {
          allow write: if true; // idealnya ganti dengan token pairing device, lihat catatan di FirestoreRepo.kt
          allow read: if request.auth != null && request.auth.uid == familyId;
        }
        match /rules/{doc} {
          allow read: if true; // anak butuh baca aturan
          allow write: if request.auth != null && request.auth.uid == familyId;
        }
      }
    }
  }
}
```
