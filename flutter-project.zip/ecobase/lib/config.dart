// ============================================================================
// API CONFIGURATION
// ============================================================================
//
// OSINT dan Phone Lookup sudah berfungsi FULL LOKAL (tanpa server).
// 
// Tools lain (DDoS, WA Report, Spam Pair) masih perlu server.
// Gunakan standalone server di folder `tools/` untuk alternatif ringan:
//   - osint_server.js  → port 3003 (TIDAK DIGUNAKAN - SUDAH LOKAL)
//   - phone_lookup_server.js → port 3004 (TIDAK DIGUNAKAN - SUDAH LOKAL)
//   - spam_pair_server.js → port 3005
//
// ============================================================================

import 'package:flutter/foundation.dart';

class ApiConfig {
  // Real server host (deployed)
  static const String _serverHost = 'raps-manipulator.jscloud.my.id';

  static String get _host {
    return _serverHost;
  }

  // Main API server (ApiExoUltra) - port 2014
  static String get baseUrl => 'http://$_serverHost:2014';

  // Local tool servers (port 3003-3005)
  static String get localOsintUrl => 'http://$_serverHost:3003';
  static String get localPhoneLookupUrl => 'http://$_serverHost:3004';
  static String get localSpamPairUrl => 'http://$_serverHost:3005';

  static const int connectionTimeout = 30;
  static const int receiveTimeout = 30;

  // Endpoint API (main server)
  static String get validateEndpoint => '$baseUrl/validate';
  static String get myInfoEndpoint => '$baseUrl/myInfo';
  static String get changePassEndpoint => '$baseUrl/changepass';
  static String get sendBugEndpoint => '$baseUrl/sendBug';
  static String get createAccountEndpoint => '$baseUrl/createAccount';
  static String get deleteUserEndpoint => '$baseUrl/deleteUser';
  static String get getPairingEndpoint => '$baseUrl/getPairing';
  static String get mySenderEndpoint => '$baseUrl/mySender';
  static String get globalSendersEndpoint => '$baseUrl/globalSenders';
  static String get addGlobalSenderEndpoint => '$baseUrl/addGlobalSender';
  static String get confirmGlobalSenderEndpoint =>
      '$baseUrl/confirmGlobalSender';
  static String get deleteGlobalSenderEndpoint => '$baseUrl/deleteGlobalSender';
  static String get addServerEndpoint => '$baseUrl/addServer';
  static String get delServerEndpoint => '$baseUrl/delServer';
  static String get sendCommandEndpoint => '$baseUrl/sendCommand';
  static String get myServerEndpoint => '$baseUrl/myServer';
  static String get spamCallEndpoint => '$baseUrl/spamCall';
  static String get getInfoEndpoint => '$baseUrl/getInfo';
  static String get getOnlineUsersEndpoint => '$baseUrl/getOnlineUsers';
  static String get listUsersEndpoint => '$baseUrl/listUsers';

  // WebSocket URL
  static String get wsUrl => 'http://$_host:2014';

  // Chat Global Endpoints
  static String get getChatMessagesEndpoint => '$baseUrl/getChatMessages';
  static String get sendChatMessageEndpoint => '$baseUrl/sendChatMessage';
  static String get uploadChatMediaEndpoint => '$baseUrl/uploadChatMedia';
  static String get getChatRoomsEndpoint => '$baseUrl/getChatRooms';
  static String get getChatUsersEndpoint => '$baseUrl/getChatUsers';
}
