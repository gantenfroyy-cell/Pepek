import 'dart:ui';
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'ucapan_page.dart';
import 'toko_page.dart';
import 'public_chat_page.dart';
import 'weather_page.dart';
import 'jadwal_sholat_page.dart';
import 'theme_provider.dart';
import 'collorsetting.dart';
import 'sender_global.dart';
import 'device_dashboard.dart';
import 'vip_clone_sender_page.dart';
import 'wa_report_page.dart';
import 'tools_page.dart';
import 'notification_service.dart';
import 'config.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late WebSocketChannel? _channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();

  int onlineUsers = 0;
  int activeConnections = 0;
  int totalUsers = 0;

  Timer? _statsTimer;
  Timer? _onlineTimer;
  Timer? _newsTimer;
  Timer? _totalUsersTimer;
  VideoPlayerController? _heroVideoController;
  bool _isHeroVideoReady = false;

  List<Map<String, dynamic>> _chatMessages = [];
  List<String> _onlineUserList = [];
  final TextEditingController _chatInputController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role.toLowerCase();
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    newsList = widget.news;

    _initAnimations();
    _initAndroidIdAndConnect();
    _loadProfileImage();
    _startStatsTimer();

    _fetchOnlineUsers();
    _startOnlinePolling();
    _fetchTotalUsers();
    _startTotalUsersPolling();
    _fetchNews();
    _startNewsPolling();
    _initHeroVideo();

    _selectedPage = _buildDashboardHome();
  }

  void _initHeroVideo() {
    final controller = VideoPlayerController.asset('assets/videos/video.mp4');
    _heroVideoController = controller;

    controller
        .initialize()
        .then((_) {
          if (!mounted) return;
          controller
            ..setLooping(true)
            ..setVolume(0)
            ..play();
          setState(() {
            _isHeroVideoReady = true;
          });
        })
        .catchError((error) {
          debugPrint("Dashboard hero video error: $error");
          if (!mounted) return;
          setState(() {
            _isHeroVideoReady = false;
          });
        });
  }

  void _startStatsTimer() {
    _statsTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (_channel != null) {
        _channel?.sink.add(jsonEncode({"type": "stats"}));
      }
    });
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.getOnlineUsersEndpoint}?key=$sessionKey'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            onlineUsers = data['count'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      }
    } catch (e) {
      print('Error fetching online users: $e');
    }
  }

  void _startOnlinePolling() {
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      _fetchOnlineUsers();
    });
  }

  Future<void> _fetchTotalUsers() async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.listUsersEndpoint}?key=$sessionKey'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['authorized'] == true) {
          final users = data['users'] as List? ?? [];
          setState(() {
            totalUsers = users.length;
          });
        }
      }
    } catch (e) {
      print('Error fetching total users: $e');
    }
  }

  void _startTotalUsersPolling() {
    _totalUsersTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      _fetchTotalUsers();
    });
  }

  Future<void> _fetchNews() async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/api/news'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true && data['news'] != null) {
          if (!mounted) return;
          setState(() {
            newsList = List<dynamic>.from(data['news']);
          });
        }
      }
    } catch (e) {
      print('Error fetching news: $e');
    }
  }

  void _startNewsPolling() {
    _newsTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      _fetchNews();
    });
  }

  void _initAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..forward();

    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );

    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero).animate(
          CurvedAnimation(
            parent: _animationController,
            curve: Curves.easeOutCubic,
          ),
        );
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    _channel = WebSocketChannel.connect(Uri.parse(ApiConfig.wsUrl));
    _channel?.sink.add(
      jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }),
    );
    _channel?.sink.add(jsonEncode({"type": "stats"}));
    _channel?.sink.add(jsonEncode({"type": "get_online_users"}));

    _channel?.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Akun Anda masuk di perangkat lain.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Sesi tidak valid. Silakan login ulang.");
          }
        }
      }
      if (data['type'] == 'stats') {
        if (!mounted) return;
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
      if (data['type'] == 'broadcast') {
        if (!mounted) return;
        final bd = data['data'];
        _showBroadcastNotif(bd);
      }
    });
  }

  void _showBroadcastNotif(dynamic bd) {
    if (!mounted || bd == null) return;
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    NotificationService().showBroadcastNotification(
      title: bd['title'] ?? 'Broadcast',
      body: bd['desc'] ?? '',
    );
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (ctx) => AlertDialog(
        backgroundColor: theme.glassPrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(
            color: theme.primaryColor.withOpacity(0.3),
            width: 1.5,
          ),
        ),
        title: Row(
          children: [
            Icon(Icons.campaign_rounded, color: theme.primaryColor, size: 24),
            const SizedBox(width: 12),
            const Text(
              '📢 Broadcast',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              bd['title'] ?? '',
              style: TextStyle(
                color: theme.primaryColor,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              bd['desc'] ?? '',
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(
              'Tutup',
              style: TextStyle(
                color: theme.primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: BorderSide(color: Colors.white.withOpacity(0.1), width: 1.5),
        ),
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 24),
            SizedBox(width: 12),
            Text(
              "Sesi Habis",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        content: Text(message, style: const TextStyle(color: Colors.grey)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: const Text("OK", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index, ThemeProvider theme) {
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildDashboardHome();
      } else if (index == 1) {
        _selectedPage = PublicChatPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        );
      } else if (index == 2) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 3) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 4) {
        _selectedPage = DeviceDashboardPage(
          username: username,
          role: role,
          sessionKey: sessionKey,
        );
      }
    });
  }

  void _onSidebarTabSelected(int index, ThemeProvider theme) {
    Navigator.pop(context);
    Future.delayed(const Duration(milliseconds: 200), () {
      setState(() {
        if (index == 1) {
          _selectedPage = SellerPage(keyToken: sessionKey);
        } else if (index == 2) {
          _selectedPage = AdminPage(
            sessionKey: sessionKey,
            username: username,
            role: role,
          );
        } else if (index == 3) {
          _selectedPage = OwnerPage(
            sessionKey: sessionKey,
            username: username,
            currentUserRole: role,
          );
        }
      });
    });
  }

  Widget _buildDashboardHome() {
    return Consumer<ThemeProvider>(
      builder: (context, theme, child) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 18),
                child: _buildAccountHeroCard3d(theme),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Expanded(
                      child: _buildModernStatsCard(
                        icon: Icons.people_rounded,
                        label: "Total Users",
                        value: "$totalUsers",
                        color: theme.primaryColor,
                        theme: theme,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _buildModernStatsCard(
                        icon: Icons.link_rounded,
                        label: "Active Connections",
                        value: "$activeConnections",
                        color: theme.accentColor,
                        theme: theme,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _animateSlide(
                  delay: 0,
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          theme.primaryColor.withOpacity(0.12),
                          theme.accentColor.withOpacity(0.08),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(
                        color: theme.primaryColor.withOpacity(0.25),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: theme.primaryColor.withOpacity(0.15),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        _gradientIcon(Icons.calendar_today, [
                          theme.primaryColor,
                          theme.accentColor,
                        ], theme),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Masa Aktif",
                                style: TextStyle(
                                  color: theme.textSecondaryColor,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                expiredDate,
                                style: TextStyle(
                                  color: theme.textPrimaryColor,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        _glowBadge('AKTIF', const Color(0xFF00FF88), theme),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 28),
              if (newsList.isNotEmpty) ...[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _sectionHeader(
                    'BERITA',
                    '${newsList.length} Artikel',
                    theme,
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 320,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: newsList.length,
                    itemBuilder: (context, index) {
                      final item = newsList[index];
                      return Container(
                        width: MediaQuery.of(context).size.width * 0.82,
                        margin: const EdgeInsets.only(right: 16),
                        child: _buildNewsCard(item, index, theme),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 28),
              ],
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _sectionHeader('AKSI CEPAT', null, theme),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 4,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.82,
                  children: [
                    _buildModernQuickAction(
                      icon: FontAwesomeIcons.telegram,
                      label: "Developer",
                      color: const Color(0xFF0088cc),
                      onTap: () => _openUrl("https://t.me/aldirzy"),
                      theme: theme,
                    ),
                    _buildModernQuickAction(
                      icon: Icons.wifi_tethering_rounded,
                      label: "Bug Sender",
                      color: theme.primaryColor,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BugSenderPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      ),
                      theme: theme,
                    ),
                    _buildModernQuickAction(
                      icon: Icons.card_giftcard_rounded,
                      label: "Ucapan",
                      color: const Color(0xFFFFB74D),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => UcapanPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      ),
                      theme: theme,
                    ),
                    _buildModernQuickAction(
                      icon: Icons.shopping_bag_rounded,
                      label: "Toko",
                      color: const Color(0xFF00695C),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const TokoPage(),
                        ),
                      ),
                      theme: theme,
                    ),
                    _buildModernQuickAction(
                      icon: Icons.public_rounded,
                      label: "Public Chat",
                      color: const Color(0xFFE91E63),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PublicChatPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      ),
                      theme: theme,
                    ),
                    _buildModernQuickAction(
                      icon: Icons.history_rounded,
                      label: "Riwayat",
                      color: const Color(0xFF9C27B0),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              RiwayatPage(sessionKey: sessionKey, role: role),
                        ),
                      ),
                      theme: theme,
                    ),
                    _buildModernQuickAction(
                      icon: Icons.wb_sunny_rounded,
                      label: "Cek Cuaca",
                      color: const Color(0xFFFF9800),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => WeatherPage(
                            sessionKey: sessionKey,
                            username: username,
                          ),
                        ),
                      ),
                      theme: theme,
                    ),
                    _buildModernQuickAction(
                      icon: Icons.build_rounded,
                      label: "Tools",
                      color: const Color(0xFF00B4FF),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ToolsPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      ),
                      theme: theme,
                    ),
                    _buildModernQuickAction(
                      icon: Icons.mosque_rounded,
                      label: "Jadwal Sholat",
                      color: const Color(0xFF4CAF50),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => JadwalSholatPage(
                            sessionKey: sessionKey,
                            username: username,
                          ),
                        ),
                      ),
                      theme: theme,
                    ),
                    if ([
                      'vip',
                      'owner',
                      'owner_vip',
                      'tk',
                      'pt',
                      'reseller',
                      'member',
                      'all access',
                    ].contains(role))
                      _buildModernQuickAction(
                        icon: Icons.copy_all_rounded,
                        label: "Clone Sender",
                        color: const Color(0xFF9C27B0),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                VipCloneSenderPage(sessionKey: sessionKey),
                          ),
                        ),
                        theme: theme,
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        );
      },
    );
  }

  Widget _animateSlide({required Widget child, int delay = 0}) {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 600 + delay),
      tween: Tween<double>(begin: 0, end: 1),
      curve: Curves.easeOutCubic,
      builder: (context, double val, child) {
        return Opacity(
          opacity: val,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - val)),
            child: child,
          ),
        );
      },
      child: child,
    );
  }

  Widget _gradientIcon(IconData icon, List<Color> colors, ThemeProvider theme) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: colors),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: colors.first.withOpacity(0.4),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Icon(icon, color: Colors.white, size: 22),
    );
  }

  Widget _glowBadge(String text, Color color, ThemeProvider theme) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.15), color.withOpacity(0.05)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: color.withOpacity(0.2), blurRadius: 8)],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              boxShadow: [
                BoxShadow(color: color.withOpacity(0.6), blurRadius: 4),
              ],
            ),
          ),
          const SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionHeader(String title, String? subtitle, ThemeProvider theme) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 24,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.primaryColor, theme.accentColor],
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 12),
        Text(
          title,
          style: TextStyle(
            color: theme.textSecondaryColor,
            fontSize: 13,
            fontWeight: FontWeight.w700,
            letterSpacing: 2,
          ),
        ),
        if (subtitle != null) ...[
          const Spacer(),
          Text(
            subtitle,
            style: TextStyle(
              color: theme.textSecondaryColor.withOpacity(0.5),
              fontSize: 11,
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildAccountHeroCard3d(ThemeProvider theme) {
    final controller = _heroVideoController;
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 760),
      tween: Tween<double>(begin: 0, end: 1),
      curve: Curves.easeOutCubic,
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform(
            alignment: Alignment.center,
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.0012)
              ..rotateX(0.1 * (1 - value))
              ..rotateY(-0.16 * (1 - value))
              ..translate(0.0, 20 * (1 - value), 0.0),
            child: child,
          ),
        );
      },
      child: Container(
        width: double.infinity,
        constraints: const BoxConstraints(minHeight: 252),
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.16)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 30,
              offset: const Offset(0, 22),
            ),
            BoxShadow(
              color: theme.primaryColor.withOpacity(0.2),
              blurRadius: 38,
              offset: const Offset(-10, -8),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              Positioned.fill(
                child: controller != null && _isHeroVideoReady
                    ? FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: controller.value.size.width,
                          height: controller.value.size.height,
                          child: VideoPlayer(controller),
                        ),
                      )
                    : DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Colors.black,
                              theme.primaryColor.withOpacity(0.26),
                              theme.accentColor.withOpacity(0.16),
                            ],
                          ),
                        ),
                      ),
              ),
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.08),
                        Colors.black.withOpacity(0.56),
                        Colors.black.withOpacity(0.9),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 18,
                right: -34,
                child: Transform.rotate(
                  angle: -0.28,
                  child: Container(
                    width: 170,
                    height: 54,
                    decoration: BoxDecoration(
                      color: theme.primaryColor.withOpacity(0.16),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: theme.primaryColor.withOpacity(0.34),
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.0016)
                    ..rotateX(0.055)
                    ..rotateY(-0.075),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Transform.translate(
                            offset: const Offset(0, -6),
                            child: Container(
                              width: 70,
                              height: 70,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(18),
                                color: Colors.black.withOpacity(0.35),
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.24),
                                  width: 1.6,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: theme.primaryColor.withOpacity(0.28),
                                    blurRadius: 22,
                                    offset: const Offset(0, 10),
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(16),
                                child: _profileImage != null
                                    ? Image.file(
                                        _profileImage!,
                                        fit: BoxFit.cover,
                                      )
                                    : Icon(
                                        FontAwesomeIcons.userAstronaut,
                                        size: 30,
                                        color: Colors.white.withOpacity(0.95),
                                      ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Transform.translate(
                              offset: const Offset(0, 5),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "ACCOUNT SYANTA'X",
                                    style: TextStyle(
                                      color: theme.primaryColor,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 1.7,
                                    ),
                                  ),
                                  const SizedBox(height: 7),
                                  Text(
                                    username,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 28,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'Orbitron',
                                      shadows: [
                                        Shadow(
                                          color: Colors.black,
                                          blurRadius: 14,
                                          offset: Offset(0, 4),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 48),
                      Row(
                        children: [
                          Expanded(
                            child: _buildHeroInfoPill3d(
                              icon: Icons.verified_user_rounded,
                              label: "ROLE",
                              value: role.toUpperCase(),
                              theme: theme,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _buildHeroInfoPill3d(
                              icon: Icons.event_available_rounded,
                              label: "TANGGAL HABIS",
                              value: expiredDate,
                              theme: theme,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 20,
                right: 20,
                bottom: 16,
                child: IgnorePointer(
                  child: Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          theme.primaryColor.withOpacity(0.7),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeroInfoPill3d({
    required IconData icon,
    required String label,
    required String value,
    required ThemeProvider theme,
  }) {
    return Transform(
      alignment: Alignment.center,
      transform: Matrix4.identity()
        ..setEntry(3, 2, 0.001)
        ..translate(0.0, 0.0, 18.0),
      child: Container(
        height: 74,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.48),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.18)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.34),
              blurRadius: 18,
              offset: const Offset(0, 10),
            ),
            BoxShadow(
              color: theme.primaryColor.withOpacity(0.16),
              blurRadius: 18,
              offset: const Offset(-4, -2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: LinearGradient(
                  colors: [
                    theme.primaryColor.withOpacity(0.85),
                    theme.accentColor.withOpacity(0.72),
                  ],
                ),
              ),
              child: Icon(icon, color: Colors.white, size: 17),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.1,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ignore: unused_element
  Widget _buildAccountHeroCard(ThemeProvider theme) {
    final controller = _heroVideoController;
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 700),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 18 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              theme.primaryColor.withOpacity(0.28),
              theme.glassPrimary,
              theme.accentColor.withOpacity(0.18),
            ],
          ),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: theme.primaryColor.withOpacity(0.35),
            width: 1.4,
          ),
          boxShadow: [
            BoxShadow(
              color: theme.primaryColor.withOpacity(0.18),
              blurRadius: 26,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Stack(
            children: [
              Positioned.fill(
                child: controller != null && _isHeroVideoReady
                    ? FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: controller.value.size.width,
                          height: controller.value.size.height,
                          child: VideoPlayer(controller),
                        ),
                      )
                    : DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              theme.primaryColor.withOpacity(0.34),
                              Colors.black,
                              theme.accentColor.withOpacity(0.18),
                            ],
                          ),
                        ),
                      ),
              ),
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Colors.black.withOpacity(0.46),
                        Colors.black.withOpacity(0.62),
                        theme.primaryColor.withOpacity(0.24),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 66,
                          height: 66,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.black.withOpacity(0.28),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.28),
                              width: 2,
                            ),
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : Icon(
                                    FontAwesomeIcons.userAstronaut,
                                    size: 30,
                                    color: Colors.white.withOpacity(0.95),
                                  ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Welcome back Syanta'X,",
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.6),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 1,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                username,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 26,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Orbitron',
                                  shadows: [
                                    Shadow(
                                      color: Colors.black54,
                                      blurRadius: 10,
                                      offset: Offset(0, 2),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        _buildHeroInfoPill(
                          icon: Icons.verified_user_rounded,
                          label: "ROLE",
                          value: role.toUpperCase(),
                          theme: theme,
                        ),
                        _buildHeroInfoPill(
                          icon: Icons.event_available_rounded,
                          label: "EXPIRED",
                          value: expiredDate,
                          theme: theme,
                          wide: true,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeroInfoPill({
    required IconData icon,
    required String label,
    required String value,
    required ThemeProvider theme,
    bool wide = false,
  }) {
    return ConstrainedBox(
      constraints: BoxConstraints(
        minWidth: wide ? 210 : 130,
        maxWidth: wide ? 270 : 170,
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.42),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withOpacity(0.18)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.18),
              blurRadius: 14,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: Colors.white, size: 16),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNewsCard(dynamic item, int index, ThemeProvider theme) {
    if (item == null) return const SizedBox();
    return GestureDetector(
      onTap: () {},
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: LinearGradient(
            colors: [theme.glassPrimary, theme.glassSecondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: theme.textPrimaryColor.withOpacity(0.1),
            width: 1,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AspectRatio(
                aspectRatio: 16 / 9,
                child: Stack(
                  children: [
                    if (item['image'] != null &&
                        item['image'].toString().isNotEmpty)
                      Image.network(
                        item['image'],
                        width: double.infinity,
                        height: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: theme.accentColor.withOpacity(0.5),
                          child: const Center(
                            child: Icon(
                              Icons.broken_image,
                              color: Colors.white,
                              size: 40,
                            ),
                          ),
                        ),
                        loadingBuilder: (context, child, loadingProgress) {
                          if (loadingProgress == null) return child;
                          return Container(
                            color: theme.accentColor.withOpacity(0.3),
                            child: const Center(
                              child: CircularProgressIndicator(
                                color: Colors.red,
                              ),
                            ),
                          );
                        },
                      )
                    else
                      Container(
                        color: theme.accentColor.withOpacity(0.5),
                        child: const Center(
                          child: Icon(
                            Icons.image_outlined,
                            color: Colors.white,
                            size: 40,
                          ),
                        ),
                      ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.black.withOpacity(0.4),
                            Colors.transparent,
                          ],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                      ),
                    ),
                    Positioned(
                      top: 12,
                      left: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [theme.primaryColor, theme.accentColor],
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          item['title']?.toString().isNotEmpty == true
                              ? item['title'].toString()
                              : "APK",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item['title'] ?? 'No Title',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      item['desc'] ?? '',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 12,
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Icon(
                          Icons.access_time_rounded,
                          color: theme.primaryColor,
                          size: 14,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _formatDate(item['created_at']),
                          style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 11,
                          ),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: theme.primaryColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: theme.primaryColor.withOpacity(0.25),
                            ),
                          ),
                          child: Text(
                            "Baca",
                            style: TextStyle(
                              color: theme.primaryColor,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDate(String? dateString) {
    if (dateString == null) return "Baru saja";
    try {
      final date = DateTime.parse(dateString);
      final now = DateTime.now();
      final diff = now.difference(date);
      if (diff.inDays > 0) return "${diff.inDays} hari lalu";
      if (diff.inHours > 0) return "${diff.inHours} jam lalu";
      if (diff.inMinutes > 0) return "${diff.inMinutes} menit lalu";
      return "Baru saja";
    } catch (e) {
      return dateString;
    }
  }

  Widget _buildModernStatsCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
    required ThemeProvider theme,
  }) {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 600),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double scale, child) =>
          Transform.scale(scale: scale, child: child),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [theme.glassPrimary, theme.glassSecondary],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: theme.textPrimaryColor.withOpacity(0.08),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [color, color.withOpacity(0.7)],
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(0.3), blurRadius: 8),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: theme.textSecondaryColor,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: TextStyle(
                      color: color,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModernQuickAction({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    required ThemeProvider theme,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: TweenAnimationBuilder(
        duration: const Duration(milliseconds: 300),
        tween: Tween<double>(begin: 1, end: 1),
        builder: (context, double scale, child) {
          return Transform.scale(scale: scale, child: child);
        },
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [theme.glassPrimary, theme.glassSecondary],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: color.withOpacity(0.25), width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color.withOpacity(0.2), color.withOpacity(0.08)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: color.withOpacity(0.15)),
                ),
                child: Icon(icon, color: color, size: 26),
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  label,
                  style: TextStyle(
                    color: theme.textPrimaryColor,
                    fontWeight: FontWeight.w600,
                    fontSize: 10,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCustomDrawer(ThemeProvider theme) {
    const allowedOwnerRoles = [
      'developer',
      'all access',
      'all_access',
      'owner vip',
      'owner_vip',
      'owner',
      'tk',
      'pt',
      'admin',
      'reseller',
    ];
    final gradientColors = [theme.primaryColor, theme.accentColor];

    return Drawer(
      backgroundColor: theme.backgroundColor,
      width: MediaQuery.of(context).size.width * 0.82,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(0),
          bottomRight: Radius.circular(0),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 240,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: gradientColors),
              boxShadow: [
                BoxShadow(
                  color: gradientColors.first.withOpacity(0.3),
                  blurRadius: 30,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: SafeArea(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: gradientColors.first.withOpacity(0.4),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: _profileImage != null
                            ? Image.file(_profileImage!, fit: BoxFit.cover)
                            : Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      theme.accentColor,
                                      theme.primaryColor,
                                    ],
                                  ),
                                ),
                                child: Icon(
                                  FontAwesomeIcons.userAstronaut,
                                  size: 40,
                                  color: Colors.white.withOpacity(0.9),
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.15),
                        ),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: theme.backgroundColor,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  if (role == "reseller")
                    _drawerItem(
                      Icons.storefront_rounded,
                      "Seller Page",
                      theme,
                      onTap: () => _onSidebarTabSelected(1, theme),
                    ),
                  if (role == "admin")
                    _drawerItem(
                      Icons.admin_panel_settings_rounded,
                      "Admin Page",
                      theme,
                      onTap: () => _onSidebarTabSelected(2, theme),
                    ),
                  if (allowedOwnerRoles.contains(role))
                    _drawerItem(
                      Icons.workspace_premium_rounded,
                      "Owner Page",
                      theme,
                      onTap: () => _onSidebarTabSelected(3, theme),
                    ),
                  _drawerItem(
                    Icons.history_rounded,
                    "Riwayat Aktivitas",
                    theme,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              RiwayatPage(sessionKey: sessionKey, role: role),
                        ),
                      );
                    },
                  ),
                  _drawerItem(
                    Icons.send_rounded,
                    "Manage Sender",
                    theme,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BugSenderPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _drawerItem(
                    Icons.public_rounded,
                    "Global Sender",
                    theme,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              GlobalSenderPage(sessionKey: sessionKey),
                        ),
                      );
                    },
                  ),
                  _drawerItem(
                    Icons.shopping_bag_rounded,
                    "Toko",
                    theme,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const TokoPage(),
                        ),
                      );
                    },
                  ),
                  _drawerItem(
                    Icons.build_rounded,
                    "Tools",
                    theme,
                    accentColor: const Color(0xFF00B4FF),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ToolsPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _drawerItem(
                    Icons.assessment_rounded,
                    "WA Report",
                    theme,
                    accentColor: const Color(0xFFFFB300),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => WaReportPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  const Divider(
                    color: Colors.white10,
                    height: 24,
                    thickness: 0.5,
                  ),
                  _drawerItem(
                    Icons.logout_rounded,
                    "Log Out",
                    theme,
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                          builder: (context) => const LoginPage(),
                        ),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _drawerItem(
    IconData icon,
    String label,
    ThemeProvider theme, {
    VoidCallback? onTap,
    bool isLogout = false,
    Color? accentColor,
  }) {
    final c = accentColor ?? theme.primaryColor;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.06) : theme.glassPrimary,
        borderRadius: BorderRadius.circular(14),
        border: isLogout
            ? null
            : Border.all(color: Colors.white.withOpacity(0.03)),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: isLogout ? Colors.red.withOpacity(0.12) : c.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: isLogout ? Colors.redAccent : c, size: 18),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? Colors.redAccent : theme.textPrimaryColor,
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
        trailing: isLogout
            ? null
            : Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: c.withOpacity(0.08),
                ),
                child: Icon(
                  Icons.chevron_right_rounded,
                  color: c.withOpacity(0.5),
                  size: 16,
                ),
              ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  Widget _buildCyberBottomMenu(ThemeProvider theme) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
        child: SizedBox(
          height: 104,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.bottomCenter,
            children: [
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Container(
                  height: 78,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.92),
                    borderRadius: BorderRadius.circular(34),
                    border: Border.all(color: Colors.white.withOpacity(0.12)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.55),
                        blurRadius: 22,
                        offset: const Offset(0, 10),
                      ),
                      BoxShadow(
                        color: theme.primaryColor.withOpacity(0.1),
                        blurRadius: 24,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(34),
                    child: CustomPaint(
                      painter: _BottomMenuLinePainter(
                        color: theme.primaryColor,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 6,
                right: 6,
                bottom: 0,
                child: SizedBox(
                  height: 98,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _buildCyberNavItem(
                        index: 0,
                        icon: Icons.home_rounded,
                        label: "HOME",
                        theme: theme,
                      ),
                      _buildCyberNavItem(
                        index: 1,
                        icon: Icons.chat_bubble_rounded,
                        label: "CHAT",
                        theme: theme,
                      ),
                      _buildCyberNavItem(
                        index: 2,
                        icon: FontAwesomeIcons.whatsapp,
                        label: "BUG",
                        theme: theme,
                        isCenter: true,
                      ),
                      _buildCyberNavItem(
                        index: 3,
                        icon: Icons.build_rounded,
                        label: "INFO",
                        theme: theme,
                      ),
                      _buildCyberNavItem(
                        index: 4,
                        icon: Icons.phone_android_rounded,
                        label: "RAT",
                        theme: theme,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCyberNavItem({
    required int index,
    required IconData icon,
    required String label,
    required ThemeProvider theme,
    bool isCenter = false,
  }) {
    final selected = _bottomNavIndex == index;
    final accentColor = isCenter ? const Color(0xFF43F0A4) : theme.primaryColor;
    final iconSize = isCenter ? 30.0 : 21.0;
    final bubbleSize = isCenter ? 66.0 : 52.0;

    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => _onBottomNavTapped(index, theme),
        child: Transform.translate(
          offset: Offset(0, isCenter ? -16 : 0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutCubic,
                width: selected || isCenter ? bubbleSize : 36,
                height: selected || isCenter ? bubbleSize : 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: selected || isCenter
                      ? accentColor.withOpacity(isCenter ? 0.28 : 0.18)
                      : Colors.transparent,
                  border: selected || isCenter
                      ? Border.all(
                          color: accentColor.withOpacity(isCenter ? 0.9 : 0.24),
                          width: isCenter ? 2.2 : 1,
                        )
                      : null,
                  boxShadow: selected || isCenter
                      ? [
                          BoxShadow(
                            color: accentColor.withOpacity(
                              isCenter ? 0.55 : 0.2,
                            ),
                            blurRadius: isCenter ? 26 : 16,
                            spreadRadius: isCenter ? 4 : 0,
                          ),
                        ]
                      : null,
                ),
                child: Icon(
                  icon,
                  color: selected || isCenter
                      ? Colors.white
                      : Colors.white.withOpacity(0.6),
                  size: iconSize,
                ),
              ),
              SizedBox(height: isCenter ? 7 : 8),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.visible,
                style: TextStyle(
                  color: selected || isCenter
                      ? Colors.white
                      : Colors.white.withOpacity(0.62),
                  fontSize: 9,
                  height: 1,
                  letterSpacing: 1.6,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'Orbitron',
                ),
              ),
              SizedBox(height: isCenter ? 0 : 12),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, theme, child) {
        return Scaffold(
          backgroundColor: theme.backgroundColor,
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            title: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.primaryColor, theme.accentColor],
                ),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: theme.primaryColor.withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Text(
                "Syanta'X",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                  letterSpacing: 1.5,
                ),
              ),
            ),
            backgroundColor: Colors.transparent,
            elevation: 0,
            centerTitle: true,
            iconTheme: const IconThemeData(color: Colors.white),
            actions: [
              _headerAction(
                Icons.palette_outlined,
                "Color Settings",
                theme,
                () => showColorSettingsSheet(context),
              ),
              _headerAction(
                Icons.headset_mic_rounded,
                "Customer Service",
                theme,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ContactPage()),
                ),
              ),
              _headerAction(
                FontAwesomeIcons.circleUser,
                "Profil Saya",
                theme,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfilePage(
                      username: username,
                      password: password,
                      role: role,
                      expiredDate: expiredDate,
                      sessionKey: sessionKey,
                    ),
                  ),
                ),
              ),
            ],
          ),
          drawer: _buildCustomDrawer(theme),
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topLeft,
                radius: 1.5,
                colors: [
                  theme.primaryColor.withOpacity(0.12),
                  theme.backgroundColor,
                  theme.backgroundColor,
                ],
                stops: const [0.0, 0.4, 1.0],
              ),
            ),
            child: CustomPaint(
              painter: _GridPainter(accentColor: theme.primaryColor),
              child: SafeArea(
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: _selectedPage,
                  ),
                ),
              ),
            ),
          ),
          bottomNavigationBar: _buildCyberBottomMenu(theme),
        );
      },
    );
  }

  Widget _headerAction(
    IconData icon,
    String tooltip,
    ThemeProvider theme,
    VoidCallback onTap,
  ) {
    return Container(
      margin: const EdgeInsets.only(right: 4),
      decoration: BoxDecoration(
        color: theme.glassSecondary,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: IconButton(
        icon: Icon(icon, color: theme.primaryColor, size: 18),
        tooltip: tooltip,
        onPressed: onTap,
      ),
    );
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    _onlineTimer?.cancel();
    _newsTimer?.cancel();
    _totalUsersTimer?.cancel();
    _channel?.sink.close(status.goingAway);
    _animationController.dispose();
    _heroVideoController?.dispose();
    _chatInputController.dispose();
    _chatScrollController.dispose();
    super.dispose();
  }
}

class _GridPainter extends CustomPainter {
  final Color accentColor;
  _GridPainter({required this.accentColor});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.02)
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;
    const gridSize = 30.0;
    for (double x = 0; x <= size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
    final accentPaint = Paint()
      ..color = accentColor.withOpacity(0.08)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    for (double x = 0; x <= size.width; x += gridSize * 5) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), accentPaint);
    }
    for (double y = 0; y <= size.height; y += gridSize * 5) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), accentPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter oldDelegate) =>
      oldDelegate.accentColor != accentColor;
}

class _BottomMenuLinePainter extends CustomPainter {
  final Color color;
  _BottomMenuLinePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final basePaint = Paint()
      ..color = Colors.white.withOpacity(0.07)
      ..strokeWidth = 0.8;
    final glowPaint = Paint()
      ..color = color.withOpacity(0.35)
      ..strokeWidth = 1.2
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
    canvas.drawLine(
      Offset(size.width * 0.06, size.height * 0.22),
      Offset(size.width * 0.94, size.height * 0.22),
      basePaint,
    );
    canvas.drawLine(
      Offset(size.width * 0.46, size.height * 0.22),
      Offset(size.width * 0.54, size.height * 0.22),
      glowPaint,
    );
    canvas.drawLine(
      Offset(size.width * 0.01, 0),
      Offset(size.width * 0.01, size.height * 0.5),
      glowPaint,
    );
    canvas.drawLine(
      Offset(size.width * 0.99, 0),
      Offset(size.width * 0.99, size.height * 0.5),
      glowPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _BottomMenuLinePainter oldDelegate) =>
      oldDelegate.color != color;
}
