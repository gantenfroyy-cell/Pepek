import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

class WaReportPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const WaReportPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<WaReportPage> createState() => _WaReportPageState();
}

class _WaReportPageState extends State<WaReportPage> {
  final _formKey = GlobalKey<FormState>();
  final _targetCtrl = TextEditingController();
  final _reasonCtrl = TextEditingController();
  final _evidenceCtrl = TextEditingController();

  bool _sending = false;
  String? _result;

  Future<void> _sendReport() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() { _sending = true; _result = null; });

    try {
      final res = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/wa-report/report'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'target': _targetCtrl.text.trim(),
          'reason': _reasonCtrl.text.trim(),
          'evidence': _evidenceCtrl.text.trim(),
        }),
      );

      final data = json.decode(res.body);
      if (data['success'] == true) {
        setState(() {
          _result = '✅ Report sent to ${data['sent']}/${data['total']} abuse channels';
        });
      } else {
        setState(() { _result = '❌ Failed: ${data['error']}'; });
      }
    } catch (e) {
      setState(() { _result = '❌ Error: $e'; });
    } finally {
      setState(() { _sending = false; });
    }
  }

  @override
  void dispose() {
    _targetCtrl.dispose();
    _reasonCtrl.dispose();
    _evidenceCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('WA Report')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Report WhatsApp Number', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Send abuse report to WhatsApp to get target banned', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 24),
              TextFormField(
                controller: _targetCtrl,
                decoration: const InputDecoration(
                  labelText: 'Target Number',
                  hintText: '6281234567890',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.phone),
                ),
                keyboardType: TextInputType.phone,
                validator: (v) => v == null || v.trim().isEmpty ? 'Enter target number' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _reasonCtrl,
                decoration: const InputDecoration(
                  labelText: 'Reason',
                  hintText: 'Spam, scam, harassment...',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.report),
                ),
                maxLines: 2,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _evidenceCtrl,
                decoration: const InputDecoration(
                  labelText: 'Evidence (optional)',
                  hintText: 'Screenshots, chat logs, etc.',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.description),
                ),
                maxLines: 4,
              ),
              const SizedBox(height: 24),
              SizedBox(
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: _sending ? null : _sendReport,
                  icon: _sending
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.send),
                  label: Text(_sending ? 'Sending...' : 'Send Report to WhatsApp'),
                ),
              ),
              if (_result != null) ...[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _result!.startsWith('✅') ? Colors.green.withOpacity(0.1) : Colors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(_result!, textAlign: TextAlign.center),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
