#!/bin/bash

echo "========================================"
echo "   MEMBANGUN APK XXO25"
echo "========================================"

echo "[1/3] Cleaning project..."
flutter clean

echo "[2/3] Getting dependencies..."
flutter pub get

echo "[3/3] Building APK release..."
flutter build apk --release

if [ $? -eq 0 ]; then
    echo "========================================"
    echo "✅ BUILD SUCCESS! ✅"
    echo "========================================"
    echo "📱 APK Location:"
    echo "  build/app/outputs/flutter-apk/app-release.apk"
    echo "========================================"
else
    echo "========================================"
    echo "❌ BUILD FAILED! ❌"
    echo "========================================"
fi