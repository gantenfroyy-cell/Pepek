import 'dart:convert';
import 'package:http/http.dart' as http;
import 'models/chat.dart';
import 'models/message.dart';
import 'models/stats.dart';

class WhatsAppApi {
  final String baseUrl;

  WhatsAppApi(this.baseUrl);

  Future<List<Chat>> getChats() async {
    final uri = Uri.parse('$baseUrl/chats');
    final res = await http.get(uri).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200)
      throw Exception('Failed to load chats: ${res.statusCode}');
    final body = json.decode(res.body) as Map<String, dynamic>;
    final list = body['data'] as List;
    return list.map((e) => Chat.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<List<Message>> getChatMessages(String chatId, {int limit = 50}) async {
    final uri =
        Uri.parse('$baseUrl/chat/${Uri.encodeComponent(chatId)}?limit=$limit');
    final res = await http.get(uri).timeout(const Duration(seconds: 20));
    if (res.statusCode != 200)
      throw Exception('Failed to load messages: ${res.statusCode}');
    final body = json.decode(res.body) as Map<String, dynamic>;
    final list = body['data'] as List;
    return list
        .map((e) => Message.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<Stats> getStats() async {
    final uri = Uri.parse('$baseUrl/stats');
    final res = await http.get(uri).timeout(const Duration(seconds: 30));
    if (res.statusCode != 200)
      throw Exception('Failed to load stats: ${res.statusCode}');
    final body = json.decode(res.body) as Map<String, dynamic>;
    return Stats.fromJson(body);
  }

  Future<String> exportChat(String chatId, String format) async {
    final uri = Uri.parse('$baseUrl/export');
    final res = await http
        .post(
          uri,
          headers: {'Content-Type': 'application/json'},
          body: json.encode({'chatId': chatId, 'format': format}),
        )
        .timeout(const Duration(seconds: 30));
    if (res.statusCode != 200)
      throw Exception('Export failed: ${res.statusCode}');
    final body = json.decode(res.body) as Map<String, dynamic>;
    return '$baseUrl${body['downloadUrl']}';
  }
}
