import 'package:flutter/material.dart';
import 'api_service.dart';
import 'models/chat.dart';
import 'models/stats.dart';

void main() => runApp(const WaReporterApp());

class WaReporterApp extends StatelessWidget {
  const WaReporterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WA Reporter',
      theme: ThemeData.dark(useMaterial3: true),
      home: const ChatListPage(),
    );
  }
}

class ChatListPage extends StatefulWidget {
  const ChatListPage({super.key});

  @override
  State<ChatListPage> createState() => _ChatListPageState();
}

class _ChatListPageState extends State<ChatListPage> {
  // Change baseUrl to your deployed backend address
  final api = WhatsAppApi('http://10.0.2.2:3000');
  List<Chat> _chats = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadChats();
  }

  Future<void> _loadChats() async {
    setState(() => _loading = true);
    try {
      final chats = await api.getChats();
      setState(() {
        _chats = chats;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  void _exportChat(Chat chat) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Export ${chat.name}'),
        content: const Text('Choose format:'),
        actions: [
          TextButton(onPressed: () => _doExport(chat.id, 'json'), child: const Text('JSON')),
          TextButton(onPressed: () => _doExport(chat.id, 'txt'), child: const Text('TXT')),
          TextButton(onPressed: () => _doExport(chat.id, 'csv'), child: const Text('CSV')),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        ],
      ),
    );
  }

  Future<void> _doExport(String chatId, String format) async {
    Navigator.pop(context); // close dialog
    try {
      final url = await api.exportChat(chatId, format);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Report ready: $url')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Export failed: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('WhatsApp Chats'),
        actions: [
          IconButton(onPressed: _loadChats, icon: const Icon(Icons.refresh)),
          IconButton(
            icon: const Icon(Icons.bar_chart),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StatsPage(api: null))).then((_) => _loadChats()),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text('Error: $_error'))
              : _chats.isEmpty
                  ? const Center(child: Text('No chats found'))
                  : ListView.builder(
                      itemCount: _chats.length,
                      itemBuilder: (ctx, i) {
                        final chat = _chats[i];
                        return ListTile(
                          leading: CircleAvatar(child: Text(chat.name[0].toUpperCase())),
                          title: Text(chat.name),
                          subtitle: Text(chat.lastMessagePreview, maxLines: 1, overflow: TextOverflow.ellipsis),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (chat.unreadCount > 0)
                                Badge(label: Text('${chat.unreadCount}')),
                              IconButton(
                                icon: const Icon(Icons.download),
                                onPressed: () => _exportChat(chat),
                              ),
                            ],
                          ),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => MessagePage(chatId: chat.id, chatName: chat.name, api: api),
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}

// ---------------------------------------------------------------------------
// Message Page
// ---------------------------------------------------------------------------
class MessagePage extends StatelessWidget {
  final String chatId;
  final String chatName;
  final WhatsAppApi api;
  const MessagePage({super.key, required this.chatId, required this.chatName, required this.api});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(chatName)),
      body: FutureBuilder(
        future: api.getChatMessages(chatId),
        builder: (ctx, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
          final msgs = snap.data as List;
          return ListView.builder(
            itemCount: msgs.length,
            itemBuilder: (ctx, i) {
              final m = msgs[i];
              return ListTile(
                dense: true,
                leading: Text(m.isMe ? '👤' : '👥'),
                title: Text(m.body, style: const TextStyle(fontSize: 14)),
                subtitle: Text('${m.from} • ${DateTime.fromMillisecondsSinceEpoch(m.timestamp * 1000)}'),
              );
            },
          );
        },
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Stats Page
// ---------------------------------------------------------------------------
class StatsPage extends StatelessWidget {
  final WhatsAppApi? api;
  const StatsPage({super.key, required this.api});

  @override
  Widget build(BuildContext context) {
    final waApi = api ?? WhatsAppApi('http://10.0.2.2:3000');
    return Scaffold(
      appBar: AppBar(title: const Text('Statistics')),
      body: FutureBuilder(
        future: waApi.getStats(),
        builder: (ctx, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
          final stats = snap.data as Stats;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Total Chats: ${stats.totalChats}', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 8),
              Text('Total Messages: ${stats.totalMessages}', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 16),
              Text('Messages per day:', style: Theme.of(context).textTheme.titleMedium),
              ...stats.messagesPerDay.entries.take(10).map(
                    (e) => Text('  ${e.key}: ${e.value}'),
                  ),
              const SizedBox(height: 16),
              Text('Most active contacts:', style: Theme.of(context).textTheme.titleMedium),
              ...stats.mostActiveContacts.map((c) => Text('  ${c['contact']}: ${c['count']}')),
            ],
          );
        },
      ),
    );
  }
}
