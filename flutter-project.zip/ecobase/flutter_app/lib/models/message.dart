class Message {
  final String id;
  final String from;
  final String body;
  final String type;
  final int timestamp;
  final bool isMe;

  Message({
    required this.id,
    required this.from,
    required this.body,
    required this.type,
    required this.timestamp,
    required this.isMe,
  });

  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: json['id'] as String,
      from: json['from'] as String,
      body: json['body'] as String? ?? '',
      type: json['type'] as String? ?? '',
      timestamp: json['timestamp'] as int,
      isMe: json['isMe'] as bool? ?? false,
    );
  }
}
