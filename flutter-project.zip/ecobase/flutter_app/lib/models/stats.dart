class Stats {
  final int totalChats;
  final int totalMessages;
  final Map<String, int> messagesPerDay;
  final List<Map<String, dynamic>> mostActiveContacts;

  Stats({
    required this.totalChats,
    required this.totalMessages,
    required this.messagesPerDay,
    required this.mostActiveContacts,
  });

  factory Stats.fromJson(Map<String, dynamic> json) {
    final data = json['data'] as Map<String, dynamic>;
    return Stats(
      totalChats: data['totalChats'] as int,
      totalMessages: data['totalMessages'] as int,
      messagesPerDay: (data['messagesPerDay'] as Map<String, dynamic>)
          .map((k, v) => MapEntry(k, v as int)),
      mostActiveContacts: (data['mostActiveContacts'] as List)
          .cast<Map<String, dynamic>>(),
    );
  }
}
