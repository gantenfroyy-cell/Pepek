class Chat {
  final String id;
  final String name;
  final int unreadCount;
  final String lastMessagePreview;
  final int timestamp;

  Chat({
    required this.id,
    required this.name,
    required this.unreadCount,
    required this.lastMessagePreview,
    required this.timestamp,
  });

  factory Chat.fromJson(Map<String, dynamic> json) {
    return Chat(
      id: json['id'] as String,
      name: json['name'] as String,
      unreadCount: json['unreadCount'] as int,
      lastMessagePreview: json['lastMessagePreview'] as String? ?? '',
      timestamp: json['timestamp'] as int? ?? 0,
    );
  }
}
