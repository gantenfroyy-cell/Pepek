@echo off
title apiExoUltra RAT Server
cd /d "%~dp0backend"
echo ====================================
echo   apiExoUltra RAT Server v2.0
echo   Starting server on port 2014...
echo ====================================
node index.js
pause
